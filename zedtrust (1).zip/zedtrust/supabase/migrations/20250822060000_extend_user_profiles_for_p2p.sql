-- Location: supabase/migrations/20250822060000_extend_user_profiles_for_p2p.sql
-- Schema Analysis: Building upon existing ZedTrust P2P trading platform with user_profiles table
-- Integration Type: Extension - Adding profile fields for P2P trading functionality
-- Dependencies: public.user_profiles (existing table)

-- Extend the existing user_profiles table with required P2P fields
ALTER TABLE public.user_profiles 
ADD COLUMN IF NOT EXISTS display_name TEXT,
ADD COLUMN IF NOT EXISTS mobile_number TEXT,
ADD COLUMN IF NOT EXISTS city TEXT,
ADD COLUMN IF NOT EXISTS is_mobile_verified BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS profile_completion_status TEXT DEFAULT 'incomplete',
ADD COLUMN IF NOT EXISTS average_completion_time INTERVAL,
ADD COLUMN IF NOT EXISTS successful_trades_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_trades_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS reliability_score DECIMAL(3,2) DEFAULT 0.0 CHECK (reliability_score >= 0.0 AND reliability_score <= 5.0),
ADD COLUMN IF NOT EXISTS is_online BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS last_seen TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS average_response_time INTERVAL;

-- Create indexes for efficient querying of P2P profile data
CREATE INDEX IF NOT EXISTS idx_user_profiles_display_name ON public.user_profiles(display_name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_city ON public.user_profiles(city);
CREATE INDEX IF NOT EXISTS idx_user_profiles_is_online ON public.user_profiles(is_online);
CREATE INDEX IF NOT EXISTS idx_user_profiles_reliability_score ON public.user_profiles(reliability_score);
CREATE INDEX IF NOT EXISTS idx_user_profiles_city_online ON public.user_profiles(city, is_online) WHERE is_online = true;

-- Create P2P ads table for buy/sell functionality
CREATE TABLE IF NOT EXISTS public.p2p_ads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    ad_type TEXT NOT NULL CHECK (ad_type IN ('buy', 'sell')),
    amount DECIMAL(15,2) NOT NULL CHECK (amount > 0),
    min_amount DECIMAL(15,2),
    max_amount DECIMAL(15,2),
    price_per_unit DECIMAL(15,2),
    currency TEXT NOT NULL DEFAULT 'INR',
    payment_methods TEXT[],
    trade_terms TEXT,
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMPTZ,
    agent_branch_preference UUID REFERENCES public.agent_locations(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for P2P ads
CREATE INDEX idx_p2p_ads_user_id ON public.p2p_ads(user_id);
CREATE INDEX idx_p2p_ads_type ON public.p2p_ads(ad_type);
CREATE INDEX idx_p2p_ads_is_active ON public.p2p_ads(is_active);
CREATE INDEX idx_p2p_ads_type_active ON public.p2p_ads(ad_type, is_active) WHERE is_active = true;

-- Enable RLS for P2P ads table
ALTER TABLE public.p2p_ads ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users can manage their own ads
CREATE POLICY "users_manage_own_p2p_ads"
ON public.p2p_ads
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- RLS Policy: Public can view active ads
CREATE POLICY "public_read_active_p2p_ads"
ON public.p2p_ads
FOR SELECT
TO authenticated
USING (is_active = true);

-- Function to update user profile completion status
CREATE OR REPLACE FUNCTION public.update_profile_completion_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Check if required fields are filled
    IF NEW.display_name IS NOT NULL AND NEW.city IS NOT NULL THEN
        NEW.profile_completion_status = 'complete';
    ELSE
        NEW.profile_completion_status = 'incomplete';
    END IF;
    
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Create trigger for profile completion status
DROP TRIGGER IF EXISTS trigger_update_profile_completion ON public.user_profiles;
CREATE TRIGGER trigger_update_profile_completion
    BEFORE UPDATE ON public.user_profiles
    FOR EACH ROW EXECUTE FUNCTION public.update_profile_completion_status();

-- Function to get nearby agent branches based on city
CREATE OR REPLACE FUNCTION public.get_nearby_agent_branches(user_city TEXT)
RETURNS TABLE(
    agent_branch_id UUID,
    agent_name TEXT,
    branch_alias TEXT,
    agent_rating DECIMAL,
    branch_area TEXT,
    distance_priority INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    al.id as agent_branch_id,
    a.name as agent_name,
    al.display_alias as branch_alias,
    a.rating as agent_rating,
    al.area as branch_area,
    CASE 
        WHEN al.city = user_city THEN 1
        ELSE 2
    END as distance_priority
FROM public.agent_locations al
JOIN public.agents a ON al.agent_id = a.id
WHERE al.is_active = true 
AND a.is_verified = true
AND (al.city = user_city OR al.city IN (
    -- Add logic for nearby cities if needed
    SELECT DISTINCT city FROM public.agent_locations WHERE city != user_city LIMIT 5
))
ORDER BY distance_priority, a.rating DESC, al.area;
$$;

-- Function to get user P2P profile information
CREATE OR REPLACE FUNCTION public.get_p2p_user_profile(profile_user_id UUID)
RETURNS TABLE(
    profile_id UUID,
    display_name TEXT,
    city TEXT,
    mobile_number TEXT,
    is_mobile_verified BOOLEAN,
    reliability_score DECIMAL,
    successful_trades INTEGER,
    total_trades INTEGER,
    completion_rate DECIMAL,
    is_online BOOLEAN,
    last_seen TIMESTAMPTZ,
    average_response_time INTERVAL,
    verification_badges TEXT[]
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    up.id as profile_id,
    up.display_name,
    up.city,
    CASE 
        WHEN up.id = auth.uid() THEN up.mobile_number
        WHEN up.mobile_number IS NOT NULL AND up.is_mobile_verified = true THEN 'Verified'
        ELSE NULL
    END as mobile_number,
    up.is_mobile_verified,
    up.reliability_score,
    up.successful_trades_count as successful_trades,
    up.total_trades_count as total_trades,
    CASE 
        WHEN up.total_trades_count > 0 THEN 
            ROUND((up.successful_trades_count::DECIMAL / up.total_trades_count::DECIMAL) * 100, 2)
        ELSE 0.0
    END as completion_rate,
    up.is_online,
    up.last_seen,
    up.average_response_time,
    ARRAY[
        CASE WHEN up.display_name IS NOT NULL THEN 'name_verified' ELSE NULL END,
        CASE WHEN up.city IS NOT NULL THEN 'city_verified' ELSE NULL END,
        CASE WHEN up.is_mobile_verified = true THEN 'mobile_verified' ELSE NULL END
    ]::TEXT[] as verification_badges
FROM public.user_profiles up
WHERE up.id = profile_user_id;
$$;

-- Mock data for P2P functionality
DO $$
DECLARE
    existing_user_id UUID;
    test_ad_id UUID := gen_random_uuid();
BEGIN
    -- Get existing user ID from user_profiles
    SELECT id INTO existing_user_id FROM public.user_profiles LIMIT 1;
    
    IF existing_user_id IS NOT NULL THEN
        -- Update existing user profile with P2P data
        UPDATE public.user_profiles 
        SET 
            display_name = 'Rajesh Kumar',
            mobile_number = '+91-9876543210',
            city = 'Mumbai',
            is_mobile_verified = true,
            profile_completion_status = 'complete',
            successful_trades_count = 25,
            total_trades_count = 28,
            reliability_score = 4.8,
            is_online = true,
            average_response_time = INTERVAL '15 minutes'
        WHERE id = existing_user_id;
        
        -- Create sample P2P ad
        INSERT INTO public.p2p_ads (
            id, user_id, ad_type, amount, min_amount, max_amount,
            price_per_unit, currency, payment_methods, trade_terms, is_active
        ) VALUES (
            test_ad_id, existing_user_id, 'sell', 50000.00, 5000.00, 100000.00,
            82.50, 'INR', ARRAY['UPI', 'Bank Transfer', 'Cash'], 
            'Fast and reliable transactions. Available 9 AM to 9 PM.', true
        );
        
        RAISE NOTICE 'P2P mock data created successfully for user: %', existing_user_id;
    ELSE
        RAISE NOTICE 'No existing users found. Please create users first.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error creating P2P mock data: %', SQLERRM;
END $$;

-- Add helpful comments
COMMENT ON COLUMN public.user_profiles.display_name IS 'User display name for P2P trading (required for profile completion)';
COMMENT ON COLUMN public.user_profiles.mobile_number IS 'Optional mobile number for enhanced trust';
COMMENT ON COLUMN public.user_profiles.city IS 'User city for agent branch matching (required for profile completion)';
COMMENT ON COLUMN public.user_profiles.reliability_score IS 'User reliability score based on trade history (0-5 scale)';
COMMENT ON TABLE public.p2p_ads IS 'P2P trading advertisements posted by users';
COMMENT ON FUNCTION public.get_nearby_agent_branches(TEXT) IS 'Returns agent branches near user city with priority ordering';
COMMENT ON FUNCTION public.get_p2p_user_profile(UUID) IS 'Returns comprehensive P2P user profile with privacy controls';