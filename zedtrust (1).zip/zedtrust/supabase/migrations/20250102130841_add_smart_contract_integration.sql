-- Location: supabase/migrations/20250102130841_add_smart_contract_integration.sql
-- Schema Analysis: Existing comprehensive escrow system with trades, escrow, escrow_audit_log tables
-- Integration Type: Enhancement - Adding smart contract fields and functions
-- Dependencies: trades, escrow, escrow_audit_log tables (existing)

-- Add smart contract specific columns to existing trades table
ALTER TABLE public.trades 
ADD COLUMN IF NOT EXISTS smart_contract_trade_id NUMERIC,
ADD COLUMN IF NOT EXISTS blockchain_network TEXT DEFAULT 'polygon_amoy',
ADD COLUMN IF NOT EXISTS counterparty_address TEXT,
ADD COLUMN IF NOT EXISTS ad_type INTEGER DEFAULT 0, -- 0 for BUY, 1 for SELL 
ADD COLUMN IF NOT EXISTS allowed_token_address TEXT DEFAULT '0x0000000000000000000000000000000000000000', -- ETH/MATIC default
ADD COLUMN IF NOT EXISTS expiry_time TIMESTAMPTZ;

-- Update existing escrow table with smart contract address field
UPDATE public.escrow 
SET smart_contract_address = '0xf3fcdaaE3320D32e2386B795FA4e3F93e22634f5' 
WHERE smart_contract_address IS NULL;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_trades_smart_contract_id ON public.trades(smart_contract_trade_id);
CREATE INDEX IF NOT EXISTS idx_trades_blockchain_network ON public.trades(blockchain_network);
CREATE INDEX IF NOT EXISTS idx_trades_counterparty_address ON public.trades(counterparty_address);

-- Enhanced smart contract integration function
CREATE OR REPLACE FUNCTION public.create_smart_contract_trade(
    p_seller_id UUID,
    p_buyer_id UUID,
    p_ad_type INTEGER,
    p_token_address TEXT,
    p_amount NUMERIC,
    p_counterparty_address TEXT,
    p_smart_contract_trade_id NUMERIC DEFAULT NULL,
    p_escrow_data JSONB DEFAULT '{}'::JSONB
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_trade_id UUID;
    v_escrow_id UUID;
    v_buyer_fee NUMERIC;
    v_seller_fee NUMERIC;
    v_total_escrow_amount NUMERIC;
BEGIN
    -- Extract escrow data
    v_buyer_fee := COALESCE((p_escrow_data->>'buyer_fee')::NUMERIC, 0);
    v_seller_fee := COALESCE((p_escrow_data->>'seller_fee')::NUMERIC, 0);
    v_total_escrow_amount := p_amount + v_buyer_fee + v_seller_fee;

    -- Insert trade record with smart contract data
    INSERT INTO public.trades (
        seller_id, buyer_id, ad_type, amount_usdc, 
        buyer_fee, seller_fee, escrow_amount, escrow_status,
        status, smart_contract_trade_id, blockchain_network,
        counterparty_address, allowed_token_address,
        buyer_wallet_address, seller_wallet_address,
        created_at, expiry_time
    ) VALUES (
        p_seller_id, p_buyer_id, p_ad_type, p_amount,
        v_buyer_fee, v_seller_fee, v_total_escrow_amount, 'CREATED',
        'CREATED', p_smart_contract_trade_id, 'polygon_amoy',
        p_counterparty_address, p_token_address,
        p_counterparty_address, -- Will be updated by actual wallet addresses
        p_counterparty_address, -- Will be updated by actual wallet addresses  
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '2 hours'
    ) RETURNING id INTO v_trade_id;

    -- Create corresponding escrow record
    INSERT INTO public.escrow (
        trade_id, locked_amount, buyer_fee, seller_fee,
        platform_fee_total, released, smart_contract_address, created_at
    ) VALUES (
        v_trade_id, v_total_escrow_amount, v_buyer_fee, v_seller_fee,
        v_buyer_fee + v_seller_fee, false, 
        '0xf3fcdaaE3320D32e2386B795FA4e3F93e22634f5', CURRENT_TIMESTAMP
    ) RETURNING id INTO v_escrow_id;

    RETURN v_trade_id;
END;
$$;

-- Function to sync smart contract events with database
CREATE OR REPLACE FUNCTION public.sync_smart_contract_event(
    p_event_type TEXT,
    p_smart_contract_trade_id NUMERIC,
    p_transaction_hash TEXT,
    p_event_data JSONB DEFAULT '{}'::JSONB
) RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_trade_id UUID;
    v_current_status TEXT;
BEGIN
    -- Find the trade by smart contract ID
    SELECT id, escrow_status INTO v_trade_id, v_current_status
    FROM public.trades 
    WHERE smart_contract_trade_id = p_smart_contract_trade_id;

    IF v_trade_id IS NULL THEN
        RAISE NOTICE 'Trade not found for smart contract ID: %', p_smart_contract_trade_id;
        RETURN FALSE;
    END IF;

    -- Handle different event types
    CASE p_event_type
        WHEN 'TradeCreated' THEN
            UPDATE public.trades 
            SET escrow_status = 'CREATED',
                status = 'CREATED'
            WHERE id = v_trade_id;

        WHEN 'FundsLocked' THEN
            UPDATE public.trades 
            SET escrow_status = 'LOCKED',
                status = 'LOCKED',
                lock_transaction_hash = p_transaction_hash,
                locked_at = CURRENT_TIMESTAMP
            WHERE id = v_trade_id;

            UPDATE public.escrow
            SET locked_at = CURRENT_TIMESTAMP
            WHERE trade_id = v_trade_id;

        WHEN 'Released' THEN
            UPDATE public.trades 
            SET escrow_status = 'RELEASED',
                status = 'RELEASED', 
                release_transaction_hash = p_transaction_hash,
                released_at = CURRENT_TIMESTAMP,
                seller_receives = (p_event_data->>'buyerReceive')::NUMERIC,
                platform_fee_collected = (p_event_data->>'adminFee')::NUMERIC
            WHERE id = v_trade_id;

            UPDATE public.escrow
            SET released = true,
                release_transaction_hash = p_transaction_hash,
                released_at = CURRENT_TIMESTAMP
            WHERE trade_id = v_trade_id;

        WHEN 'Cancelled' THEN
            UPDATE public.trades 
            SET escrow_status = 'CANCELLED',
                status = 'CANCELLED',
                release_transaction_hash = p_transaction_hash,
                cancelled_at = CURRENT_TIMESTAMP
            WHERE id = v_trade_id;

            UPDATE public.escrow
            SET released = true,
                release_transaction_hash = p_transaction_hash,
                released_at = CURRENT_TIMESTAMP
            WHERE trade_id = v_trade_id;

        ELSE
            RAISE NOTICE 'Unknown event type: %', p_event_type;
            RETURN FALSE;
    END CASE;

    -- Log the event in audit trail
    INSERT INTO public.escrow_audit_log (
        trade_id, action, transaction_hash,
        additional_data, performed_at
    ) VALUES (
        v_trade_id, p_event_type, p_transaction_hash,
        p_event_data, CURRENT_TIMESTAMP
    );

    RETURN TRUE;
END;
$$;

-- Function to check if token is allowed
CREATE OR REPLACE FUNCTION public.check_allowed_token(
    p_token_address TEXT
) RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.escrow
    WHERE smart_contract_address = '0xf3fcdaaE3320D32e2386B795FA4e3F93e22634f5'
    LIMIT 1
) OR p_token_address = '0x0000000000000000000000000000000000000000'; -- ETH/MATIC always allowed
$$;

-- Add smart contract admin functions access policy
CREATE POLICY "admin_can_manage_smart_contract_trades"
ON public.trades
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Sample data for testing (using existing user IDs if available)
DO $$
DECLARE
    v_admin_user_id UUID;
    v_regular_user_id UUID;
    v_sample_trade_id UUID;
BEGIN
    -- Get existing user IDs
    SELECT id INTO v_admin_user_id FROM auth.users LIMIT 1;
    SELECT id INTO v_regular_user_id FROM auth.users OFFSET 1 LIMIT 1;
    
    -- If users exist, create a sample smart contract trade
    IF v_admin_user_id IS NOT NULL AND v_regular_user_id IS NOT NULL THEN
        v_sample_trade_id := public.create_smart_contract_trade(
            v_admin_user_id,
            v_regular_user_id,
            0, -- BUY ad type
            '0x0000000000000000000000000000000000000000', -- ETH/MATIC
            100.0, -- 100 USDC equivalent
            '0x742d35Cc6634C0532925a3b8D4C20e02C2B9b5D2', -- Sample counterparty address
            1001, -- Sample smart contract trade ID
            '{"buyer_fee": 2.5, "seller_fee": 1.5}'::JSONB
        );
        
        RAISE NOTICE 'Sample smart contract trade created with ID: %', v_sample_trade_id;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Sample data creation skipped: %', SQLERRM;
END $$;