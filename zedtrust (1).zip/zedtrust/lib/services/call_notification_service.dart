import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

import './call_service.dart';

class CallNotificationService {
  static final CallNotificationService _instance =
      CallNotificationService._internal();
  factory CallNotificationService() => _instance;
  CallNotificationService._internal();

  final SupabaseClient _supabase = Supabase.instance.client;
  StreamSubscription? _incomingCallsSubscription;
  final CallService _callService = CallService();

  // Initialize notification service
  Future<void> initialize() async {
    await _setupIncomingCallsListener();
  }

  // Setup listener for incoming calls
  Future<void> _setupIncomingCallsListener() async {
    final currentUserId = _supabase.auth.currentUser?.id;
    if (currentUserId == null) return;

    _incomingCallsSubscription =
        _supabase
            .channel('incoming_calls')
            .onPostgresChanges(
              event: PostgresChangeEvent.insert,
              schema: 'public',
              table: 'calls',
              filter: PostgresChangeFilter(
                type: PostgresChangeFilterType.eq,
                column: 'callee_id',
                value: currentUserId,
              ),
              callback: (payload) async {
                final callData = payload.newRecord;

                // Only handle initiating calls
                if (callData['call_status'] == 'initiating') {
                  await _handleIncomingCall(callData);
                }
              },
            )
            .subscribe();
  }

  // Handle incoming call notification
  Future<void> _handleIncomingCall(Map<String, dynamic> callData) async {
    final callId = callData['id'];
    final callerId = callData['caller_id'];
    final callType = callData['call_type'];

    try {
      // Get caller information
      final callerInfo =
          await _supabase
              .from('user_profiles')
              .select('display_name, city')
              .eq('id', callerId)
              .single();

      final callerName = callerInfo['display_name'] ?? 'Unknown Caller';

      // Show incoming call notification
      await _showIncomingCallNotification(
        callId: callId,
        callerName: callerName,
        callType: callType,
      );
    } catch (e) {
      print('Error handling incoming call: $e');
    }
  }

  // Show incoming call notification/UI
  Future<void> _showIncomingCallNotification({
    required String callId,
    required String callerName,
    required String callType,
  }) async {
    // In a real app, this would show a system notification or overlay
    // For now, we'll print to console as a demo
    print('📞 Incoming ${callType} call from $callerName (Call ID: $callId)');

    // Here you would typically:
    // 1. Show a system notification
    // 2. Show a full-screen overlay
    // 3. Navigate to the call screen
    // 4. Ring/vibrate the device

    // Example: Navigate to call screen (implement based on your navigation setup)
    /*
    Navigator.pushNamed(
      context, // You'll need to access context appropriately
      '/webrtc_call',
      arguments: {
        'callId': callId,
        'callerName': callerName,
        'isIncoming': true,
      },
    );
    */
  }

  // Get missed calls count
  Future<int> getMissedCallsCount() async {
    try {
      final currentUserId = _supabase.auth.currentUser?.id;
      if (currentUserId == null) return 0;

      final response =
          await _supabase
              .from('calls')
              .select('id')
              .eq('callee_id', currentUserId)
              .eq('call_status', 'missed')
              .count();

      return response.count;
    } catch (e) {
      print('Error getting missed calls count: $e');
      return 0;
    }
  }

  // Get recent calls
  Future<List<Map<String, dynamic>>> getRecentCalls({int limit = 20}) async {
    try {
      final currentUserId = _supabase.auth.currentUser?.id;
      if (currentUserId == null) return [];

      final response = await _supabase
          .from('calls')
          .select('''
            id,
            call_type,
            call_status,
            started_at,
            ended_at,
            duration_seconds,
            caller:user_profiles!caller_id(display_name, city),
            callee:user_profiles!callee_id(display_name, city)
          ''')
          .or('caller_id.eq.$currentUserId,callee_id.eq.$currentUserId')
          .order('started_at', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error getting recent calls: $e');
      return [];
    }
  }

  // Mark missed calls as viewed
  Future<void> markMissedCallsAsViewed() async {
    try {
      final currentUserId = _supabase.auth.currentUser?.id;
      if (currentUserId == null) return;

      await _supabase
          .from('calls')
          .update({'call_status': 'ended'})
          .eq('callee_id', currentUserId)
          .eq('call_status', 'missed');
    } catch (e) {
      print('Error marking missed calls as viewed: $e');
    }
  }

  // Dispose service
  void dispose() {
    _incomingCallsSubscription?.cancel();
  }
}
