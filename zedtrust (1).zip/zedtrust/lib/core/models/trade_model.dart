class TradeModel {
  final String id;
  final String buyerId;
  final String sellerId;
  final String? agentId;
  final String? buyerLocationId;
  final String? sellerLocationId;
  final String buyerCity;
  final String sellerCity;
  final TradeStatus status;
  final DateTime createdAt;
  final DateTime updatedAt;

  // Additional fields from joined data
  final String? buyerName;
  final String? sellerName;
  final String? agentName;
  final String? agentAlias;
  final String? buyerLocation;
  final String? sellerLocation;

  TradeModel({
    required this.id,
    required this.buyerId,
    required this.sellerId,
    this.agentId,
    this.buyerLocationId,
    this.sellerLocationId,
    required this.buyerCity,
    required this.sellerCity,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.buyerName,
    this.sellerName,
    this.agentName,
    this.agentAlias,
    this.buyerLocation,
    this.sellerLocation,
  });

  factory TradeModel.fromJson(Map<String, dynamic> json) {
    return TradeModel(
      id: json['id'] ?? json['trade_id'] ?? '',
      buyerId: json['buyer_id'] ?? '',
      sellerId: json['seller_id'] ?? '',
      agentId: json['agent_id'],
      buyerLocationId: json['buyer_location_id'],
      sellerLocationId: json['seller_location_id'],
      buyerCity: json['buyer_city'] ?? '',
      sellerCity: json['seller_city'] ?? '',
      status: TradeStatusExtension.fromString(
        json['status'] ?? json['trade_status'] ?? 'CREATED',
      ),
      createdAt: DateTime.parse(
        json['created_at'] ?? DateTime.now().toIso8601String(),
      ),
      updatedAt: DateTime.parse(
        json['updated_at'] ?? DateTime.now().toIso8601String(),
      ),
      buyerName: json['buyer_name'],
      sellerName: json['seller_name'],
      agentName: json['agent_name'],
      agentAlias: json['agent_alias'],
      buyerLocation: json['buyer_location'],
      sellerLocation: json['seller_location'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'buyer_id': buyerId,
      'seller_id': sellerId,
      'agent_id': agentId,
      'buyer_location_id': buyerLocationId,
      'seller_location_id': sellerLocationId,
      'buyer_city': buyerCity,
      'seller_city': sellerCity,
      'status': status.value,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'buyer_name': buyerName,
      'seller_name': sellerName,
      'agent_name': agentName,
      'agent_alias': agentAlias,
      'buyer_location': buyerLocation,
      'seller_location': sellerLocation,
    };
  }

  TradeModel copyWith({
    String? id,
    String? buyerId,
    String? sellerId,
    String? agentId,
    String? buyerLocationId,
    String? sellerLocationId,
    String? buyerCity,
    String? sellerCity,
    TradeStatus? status,
    DateTime? createdAt,
    DateTime? updatedAt,
    String? buyerName,
    String? sellerName,
    String? agentName,
    String? agentAlias,
    String? buyerLocation,
    String? sellerLocation,
  }) {
    return TradeModel(
      id: id ?? this.id,
      buyerId: buyerId ?? this.buyerId,
      sellerId: sellerId ?? this.sellerId,
      agentId: agentId ?? this.agentId,
      buyerLocationId: buyerLocationId ?? this.buyerLocationId,
      sellerLocationId: sellerLocationId ?? this.sellerLocationId,
      buyerCity: buyerCity ?? this.buyerCity,
      sellerCity: sellerCity ?? this.sellerCity,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      buyerName: buyerName ?? this.buyerName,
      sellerName: sellerName ?? this.sellerName,
      agentName: agentName ?? this.agentName,
      agentAlias: agentAlias ?? this.agentAlias,
      buyerLocation: buyerLocation ?? this.buyerLocation,
      sellerLocation: sellerLocation ?? this.sellerLocation,
    );
  }

  // Helper methods
  bool get isBuyer => buyerId == getCurrentUserId();
  bool get isSeller => sellerId == getCurrentUserId();
  String get userRole => isBuyer ? 'buyer' : (isSeller ? 'seller' : 'unknown');
  String get counterpartyName =>
      isBuyer
          ? (sellerName ?? 'Unknown Seller')
          : (buyerName ?? 'Unknown Buyer');

  // Placeholder for getting current user ID - implement based on your auth system
  String getCurrentUserId() {
    // This should return the current authenticated user's ID
    // Implementation depends on your auth system
    return '';
  }
}

enum TradeStatus {
  created('CREATED'),
  agentMatched('AGENT_MATCHED'),
  otpPending('OTP_PENDING'),
  released('RELEASED'),
  cancelled('CANCELLED'),
  disputed('DISPUTED');

  const TradeStatus(this.value);
  final String value;
}

extension TradeStatusExtension on TradeStatus {
  static TradeStatus fromString(String status) {
    switch (status.toUpperCase()) {
      case 'CREATED':
        return TradeStatus.created;
      case 'AGENT_MATCHED':
        return TradeStatus.agentMatched;
      case 'OTP_PENDING':
        return TradeStatus.otpPending;
      case 'RELEASED':
        return TradeStatus.released;
      case 'CANCELLED':
        return TradeStatus.cancelled;
      case 'DISPUTED':
        return TradeStatus.disputed;
      default:
        return TradeStatus.created;
    }
  }

  String get displayName {
    switch (this) {
      case TradeStatus.created:
        return 'Created';
      case TradeStatus.agentMatched:
        return 'Agent Matched';
      case TradeStatus.otpPending:
        return 'OTP Pending';
      case TradeStatus.released:
        return 'Released';
      case TradeStatus.cancelled:
        return 'Cancelled';
      case TradeStatus.disputed:
        return 'Disputed';
    }
  }

  bool get isActive =>
      this != TradeStatus.released && this != TradeStatus.cancelled;
  bool get isCompleted => this == TradeStatus.released;
  bool get isCancelled => this == TradeStatus.cancelled;
}
