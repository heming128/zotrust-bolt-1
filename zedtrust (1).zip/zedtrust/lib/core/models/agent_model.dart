class AgentModel {
  final String id;
  final String name;
  final String alias;
  final double rating;
  final bool isVerified;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  // Location information (from joins)
  final List<AgentLocationModel> locations;

  AgentModel({
    required this.id,
    required this.name,
    required this.alias,
    required this.rating,
    required this.isVerified,
    this.notes,
    required this.createdAt,
    required this.updatedAt,
    this.locations = const [],
  });

  factory AgentModel.fromJson(Map<String, dynamic> json) {
    return AgentModel(
      id: json['id'] ?? json['agent_id'] ?? '',
      name: json['name'] ?? json['agent_name'] ?? '',
      alias: json['alias'] ?? json['agent_alias'] ?? '',
      rating: (json['rating'] ?? json['agent_rating'] ?? 0.0).toDouble(),
      isVerified: json['is_verified'] ?? false,
      notes: json['notes'],
      createdAt: DateTime.parse(
        json['created_at'] ?? DateTime.now().toIso8601String(),
      ),
      updatedAt: DateTime.parse(
        json['updated_at'] ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'alias': alias,
      'rating': rating,
      'is_verified': isVerified,
      'notes': notes,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'locations': locations.map((loc) => loc.toJson()).toList(),
    };
  }

  AgentModel copyWith({
    String? id,
    String? name,
    String? alias,
    double? rating,
    bool? isVerified,
    String? notes,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<AgentLocationModel>? locations,
  }) {
    return AgentModel(
      id: id ?? this.id,
      name: name ?? this.name,
      alias: alias ?? this.alias,
      rating: rating ?? this.rating,
      isVerified: isVerified ?? this.isVerified,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      locations: locations ?? this.locations,
    );
  }

  // Helper methods
  String get displayName => alias.isNotEmpty ? alias : name;
  String get ratingDisplay => rating.toStringAsFixed(1);
  bool get hasLocations => locations.isNotEmpty;

  List<String> get availableCities =>
      locations
          .where((loc) => loc.isActive)
          .map((loc) => loc.city)
          .toSet()
          .toList();

  List<AgentLocationModel> getLocationsByCity(String city) =>
      locations.where((loc) => loc.city == city && loc.isActive).toList();

  AgentLocationModel? getLocationById(String locationId) {
    try {
      return locations.firstWhere((loc) => loc.id == locationId);
    } catch (e) {
      return null;
    }
  }
}

class AgentLocationModel {
  final String id;
  final String agentId;
  final String city;
  final String area;
  final String displayAlias;
  final String addressLine;
  final double? geoLat;
  final double? geoLng;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  AgentLocationModel({
    required this.id,
    required this.agentId,
    required this.city,
    required this.area,
    required this.displayAlias,
    required this.addressLine,
    this.geoLat,
    this.geoLng,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AgentLocationModel.fromJson(Map<String, dynamic> json) {
    return AgentLocationModel(
      id: json['id'] ?? json['location_id'] ?? '',
      agentId: json['agent_id'] ?? '',
      city: json['city'] ?? json['location_city'] ?? '',
      area: json['area'] ?? '',
      displayAlias: json['display_alias'] ?? json['location_alias'] ?? '',
      addressLine: json['address_line'] ?? json['location_address'] ?? '',
      geoLat:
          json['geo_lat'] != null ? (json['geo_lat'] as num).toDouble() : null,
      geoLng:
          json['geo_lng'] != null ? (json['geo_lng'] as num).toDouble() : null,
      isActive: json['is_active'] ?? true,
      createdAt: DateTime.parse(
        json['created_at'] ?? DateTime.now().toIso8601String(),
      ),
      updatedAt: DateTime.parse(
        json['updated_at'] ?? DateTime.now().toIso8601String(),
      ),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'agent_id': agentId,
      'city': city,
      'area': area,
      'display_alias': displayAlias,
      'address_line': addressLine,
      'geo_lat': geoLat,
      'geo_lng': geoLng,
      'is_active': isActive,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  AgentLocationModel copyWith({
    String? id,
    String? agentId,
    String? city,
    String? area,
    String? displayAlias,
    String? addressLine,
    double? geoLat,
    double? geoLng,
    bool? isActive,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return AgentLocationModel(
      id: id ?? this.id,
      agentId: agentId ?? this.agentId,
      city: city ?? this.city,
      area: area ?? this.area,
      displayAlias: displayAlias ?? this.displayAlias,
      addressLine: addressLine ?? this.addressLine,
      geoLat: geoLat ?? this.geoLat,
      geoLng: geoLng ?? this.geoLng,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Helper methods
  String get fullAddress => '$displayAlias, $area, $addressLine';
  String get shortAddress => '$displayAlias, $area';
  bool get hasCoordinates => geoLat != null && geoLng != null;

  Map<String, double>? get coordinates {
    if (!hasCoordinates) return null;
    return {'lat': geoLat!, 'lng': geoLng!};
  }
}
