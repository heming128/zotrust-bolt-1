import 'package:flutter/foundation.dart';

import './enhanced_supabase_service.dart';

/// Agent service for handling agent operations with Supabase
class AgentService {
  static AgentService? _instance;
  static AgentService get instance => _instance ??= AgentService._();

  AgentService._();

  final _supabase = EnhancedSupabaseService.instance;

  /// Get all agents with filtering options
  Future<List<Map<String, dynamic>>> getAllAgents({
    bool? verifiedOnly,
    String? city,
  }) async {
    try {
      var agents = await _supabase.getAllAgents();

      // Filter by verification status
      if (verifiedOnly == true) {
        agents = agents.where((agent) => agent['verified'] == true).toList();
      }

      // Filter by city (if agent has locations in that city)
      if (city != null && city.isNotEmpty) {
        final filteredAgents = <Map<String, dynamic>>[];

        for (final agent in agents) {
          final locations = await _supabase.getAgentLocations(agent['id']);
          final hasLocationInCity = locations.any(
            (location) =>
                location['city']?.toString().toLowerCase() ==
                city.toLowerCase(),
          );

          if (hasLocationInCity) {
            filteredAgents.add(agent);
          }
        }

        return filteredAgents;
      }

      return agents;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agents: $e');
      }
      return [];
    }
  }

  /// Get verified agents only
  Future<List<Map<String, dynamic>>> getVerifiedAgents() async {
    try {
      final agents = await _supabase.getVerifiedAgents();
      return agents;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching verified agents: $e');
      }
      return [];
    }
  }

  /// Get agent details by ID
  Future<Map<String, dynamic>?> getAgentDetails(String agentId) async {
    try {
      final agents = await _supabase.getAllAgents();
      final agent = agents.firstWhere(
        (a) => a['id'] == agentId,
        orElse: () => <String, dynamic>{},
      );

      if (agent.isEmpty) return null;

      // Get agent locations
      final locations = await _supabase.getAgentLocations(agentId);
      agent['locations'] = locations;

      return agent;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent details: $e');
      }
      return null;
    }
  }

  /// Create new agent (Admin only)
  Future<Map<String, dynamic>> createAgent({
    required String name,
    bool verified = false,
  }) async {
    try {
      final agent = await _supabase.createAgent(name: name, verified: verified);

      if (agent != null) {
        if (kDebugMode) {
          print('✅ Agent created successfully: ${agent['id']}');
        }
        return {'success': true, 'agent': agent};
      } else {
        throw Exception('Failed to create agent');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating agent: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Update agent verification status (Admin only)
  Future<Map<String, dynamic>> updateAgentVerification({
    required String agentId,
    required bool verified,
  }) async {
    try {
      final agent = await _supabase.updateAgentVerification(
        agentId: agentId,
        verified: verified,
      );

      if (agent != null) {
        if (kDebugMode) {
          print('✅ Agent verification updated: ${agent['id']} -> $verified');
        }
        return {'success': true, 'agent': agent};
      } else {
        throw Exception('Failed to update agent verification');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating agent verification: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get agent locations
  Future<List<Map<String, dynamic>>> getAgentLocations(String agentId) async {
    try {
      final locations = await _supabase.getAgentLocations(agentId);
      return locations;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations: $e');
      }
      return [];
    }
  }

  /// Get agents by city
  Future<List<Map<String, dynamic>>> getAgentsByCity(String city) async {
    try {
      final locations = await _supabase.getAgentLocationsByCity(city: city);

      // Extract unique agents from locations
      final agentIds = <String>{};
      final agents = <Map<String, dynamic>>[];

      for (final location in locations) {
        final agentId = location['agent_id'];
        if (!agentIds.contains(agentId)) {
          agentIds.add(agentId);

          // Get agent details
          final agent = location['agents'];
          if (agent != null) {
            agents.add({...agent, 'location_info': location});
          }
        }
      }

      return agents;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agents by city: $e');
      }
      return [];
    }
  }

  /// Create agent location
  Future<Map<String, dynamic>> createAgentLocation({
    required String agentId,
    required String city,
    String? area,
    String? addressLine,
    double? geoLat,
    double? geoLng,
    bool isActive = true,
  }) async {
    try {
      final location = await _supabase.createAgentLocation(
        agentId: agentId,
        city: city,
        area: area,
        addressLine: addressLine,
        geoLat: geoLat,
        geoLng: geoLng,
        isActive: isActive,
      );

      if (location != null) {
        if (kDebugMode) {
          print('✅ Agent location created successfully: ${location['id']}');
        }
        return {'success': true, 'location': location};
      } else {
        throw Exception('Failed to create agent location');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating agent location: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get available cities
  Future<List<String>> getAvailableCities() async {
    try {
      final locations = await _supabase.client
          .from('agent_locations')
          .select('city')
          .eq('is_active', true)
          .order('city', ascending: true);

      final cities = <String>{};
      for (final location in locations) {
        final city = location['city']?.toString();
        if (city != null && city.isNotEmpty) {
          cities.add(city);
        }
      }

      final cityList = cities.toList()..sort();

      // Add common cities if not present
      const commonCities = [
        'Mumbai',
        'Delhi',
        'Bangalore',
        'Chennai',
        'Hyderabad',
        'Pune',
        'Kolkata',
        'Ahmedabad',
        'Surat',
        'Jaipur',
      ];

      for (final city in commonCities) {
        if (!cityList.contains(city)) {
          cityList.add(city);
        }
      }

      cityList.sort();
      return cityList;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching available cities: $e');
      }
      return ['Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune'];
    }
  }

  /// Search agents by name
  Future<List<Map<String, dynamic>>> searchAgents(String query) async {
    try {
      final allAgents = await getAllAgents();

      if (query.isEmpty) return allAgents;

      final filteredAgents =
          allAgents.where((agent) {
            final name = agent['name']?.toString().toLowerCase() ?? '';
            return name.contains(query.toLowerCase());
          }).toList();

      return filteredAgents;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error searching agents: $e');
      }
      return [];
    }
  }

  /// Get agent statistics
  Future<Map<String, int>> getAgentStatistics() async {
    try {
      final allAgents = await getAllAgents();
      final verifiedAgents =
          allAgents.where((agent) => agent['verified'] == true).toList();

      return {
        'total_agents': allAgents.length,
        'verified_agents': verifiedAgents.length,
        'unverified_agents': allAgents.length - verifiedAgents.length,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent statistics: $e');
      }
      return {'total_agents': 0, 'verified_agents': 0, 'unverified_agents': 0};
    }
  }

  /// Check if agent has location in city
  Future<bool> hasLocationInCity({
    required String agentId,
    required String city,
  }) async {
    try {
      final locations = await _supabase.getAgentLocations(agentId);
      return locations.any(
        (location) =>
            location['city']?.toString().toLowerCase() == city.toLowerCase(),
      );
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking agent location: $e');
      }
      return false;
    }
  }

  /// Validate agent for trade creation
  Future<Map<String, dynamic>> validateAgentForTrade({
    required String agentId,
    required String buyerCity,
    required String sellerCity,
  }) async {
    try {
      final agent = await getAgentDetails(agentId);

      if (agent == null) {
        return {'valid': false, 'error': 'Agent not found'};
      }

      if (agent['verified'] != true) {
        return {'valid': false, 'error': 'Agent is not verified'};
      }

      // Check if agent has locations in both cities
      final hasBuyerCity = await hasLocationInCity(
        agentId: agentId,
        city: buyerCity,
      );

      final hasSellerCity = await hasLocationInCity(
        agentId: agentId,
        city: sellerCity,
      );

      if (!hasBuyerCity) {
        return {
          'valid': false,
          'error': 'Agent has no location in buyer city: $buyerCity',
        };
      }

      if (!hasSellerCity) {
        return {
          'valid': false,
          'error': 'Agent has no location in seller city: $sellerCity',
        };
      }

      return {'valid': true, 'agent': agent};
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error validating agent for trade: $e');
      }
      return {'valid': false, 'error': e.toString()};
    }
  }
}
