import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecureWalletService {
  static const String _walletAddressKey = 'wallet_address';
  static const String _privateKeyKey = 'private_key';
  static const String _mnemonicKey = 'mnemonic';

  static const _secureStorage = FlutterSecureStorage(
    aOptions: AndroidOptions(
      encryptedSharedPreferences: true,
    ),
    iOptions: IOSOptions(
      accessibility: KeychainAccessibility.first_unlock_this_device,
    ),
  );

  static SecureWalletService? _instance;
  bool _isInitialized = false;

  static SecureWalletService get instance {
    _instance ??= SecureWalletService._internal();
    return _instance!;
  }

  SecureWalletService._internal();

  Future<void> initialize() async {
    try {
      if (_isInitialized) return;

      if (kDebugMode) {
        print('🔐 Initializing Secure Wallet Service...');
      }

      _isInitialized = true;

      if (kDebugMode) {
        print('✅ Secure Wallet Service initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to initialize Secure Wallet Service: $e');
      }
      rethrow;
    }
  }

  /// Store wallet credentials securely
  Future<Map<String, dynamic>> storeWallet({
    required String address,
    required String privateKey,
    String? mnemonic,
  }) async {
    try {
      // Store wallet address
      await _secureStorage.write(key: _walletAddressKey, value: address);

      if (kDebugMode) {
        print('📱 Address: $address');
      }

      return {
        'success': true,
        'address': address,
        'message': 'Wallet stored securely',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to store wallet: $e');
      }

      return {
        'success': false,
        'error': 'Failed to store wallet: ${e.toString()}',
      };
    }
  }

  /// Create a new wallet
  Future<Map<String, dynamic>> createWallet() async {
    try {
      if (kDebugMode) {
        print('👛 Creating new wallet...');
      }

      // Generate a mock wallet address for now
      final address = _generateMockAddress();
      final privateKey = _generateMockPrivateKey();

      // Store wallet address
      await _secureStorage.write(key: _walletAddressKey, value: address);

      if (kDebugMode) {
        print('📱 Address: $address');
      }

      return {
        'success': true,
        'address': address,
        'privateKey': privateKey, // Only return, don't log
        'message': 'Wallet created successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to create wallet: $e');
      }

      return {
        'success': false,
        'error': 'Failed to create wallet: ${e.toString()}',
      };
    }
  }

  /// Get stored wallet address
  Future<String?> getWalletAddress() async {
    try {
      return await _secureStorage.read(key: _walletAddressKey);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to get wallet address: $e');
      }
      return null;
    }
  }

  /// Check if wallet exists
  Future<bool> hasWallet() async {
    try {
      final address = await _secureStorage.read(key: _walletAddressKey);
      return address != null && address.isNotEmpty;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to check wallet existence: $e');
      }
      return false;
    }
  }

  /// Clear wallet data
  Future<void> clearWallet() async {
    try {
      await _secureStorage.delete(key: _walletAddressKey);
      await _secureStorage.delete(key: _privateKeyKey);
      await _secureStorage.delete(key: _mnemonicKey);

      if (kDebugMode) {
        print('🗑️ Wallet data cleared');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to clear wallet: $e');
      }
      rethrow;
    }
  }

  /// Send transaction (mock implementation)
  Future<Map<String, dynamic>> sendTransaction({
    required String toAddress,
    required String value,
    required String gasPrice,
  }) async {
    try {
      if (kDebugMode) {
        print('💸 Sending transaction...');
      }

      // Simulate transaction processing
      await Future.delayed(const Duration(seconds: 2));

      final txHash = _generateMockTxHash();

      return {
        'success': true,
        'txHash': txHash,
        'message': 'Transaction sent successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to send transaction: $e');
      }

      return {
        'success': false,
        'error': 'Failed to send transaction: ${e.toString()}',
      };
    }
  }

  String _generateMockAddress() {
    return '0x${_generateRandomHex(40)}';
  }

  String _generateMockPrivateKey() {
    return '0x${_generateRandomHex(64)}';
  }

  String _generateMockTxHash() {
    return '0x${_generateRandomHex(64)}';
  }

  String _generateRandomHex(int length) {
    const chars = '0123456789abcdef';
    return String.fromCharCodes(Iterable.generate(length,
        (_) => chars.codeUnitAt((DateTime.now().microsecond) % chars.length)));
  }
}
