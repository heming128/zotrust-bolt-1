import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Singleton service for Supabase integration with admin-controlled agent system
class SupabaseService {
  static SupabaseService? _instance;
  static SupabaseClient? _client;

  SupabaseService._();

  static SupabaseService get instance {
    _instance ??= SupabaseService._();
    return _instance!;
  }

  SupabaseClient get client {
    if (_client == null) {
      throw Exception('Supabase not initialized. Call initialize() first.');
    }
    return _client!;
  }

  /// Initialize Supabase with environment configuration
  Future<void> initialize() async {
    try {
      const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
      const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

      if (supabaseUrl.isEmpty || supabaseAnonKey.isEmpty) {
        throw Exception(
          'SUPABASE_URL and SUPABASE_ANON_KEY must be provided in environment',
        );
      }

      await Supabase.initialize(
        url: supabaseUrl,
        anonKey: supabaseAnonKey,
        debug: kDebugMode,
      );

      _client = Supabase.instance.client;

      if (kDebugMode) {
        print('✅ Supabase initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Supabase initialization failed: $e');
      }
      rethrow;
    }
  }

  /// Check if current user is admin
  Future<bool> isCurrentUserAdmin() async {
    try {
      final user = client.auth.currentUser;
      if (user == null) return false;

      // Check user metadata for admin role
      final userMetadata = user.userMetadata ?? {};
      final appMetadata = user.appMetadata ?? {};

      return userMetadata['role'] == 'admin' || appMetadata['role'] == 'admin';
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking admin status: $e');
      }
      return false;
    }
  }

  /// Get admin dashboard statistics
  Future<Map<String, dynamic>> getAdminDashboardStats() async {
    try {
      final results = await Future.wait([
        client.from('agents').select().count(CountOption.exact),
        client
            .from('agents')
            .select()
            .eq('is_verified', true)
            .count(CountOption.exact),
        client.from('agent_locations').select().count(CountOption.exact),
        client
            .from('trades')
            .select()
            .neq('status', 'COMPLETED')
            .neq('status', 'CANCELLED')
            .count(CountOption.exact),
      ]);

      return {
        'totalAgents': results[0].count,
        'verifiedAgents': results[1].count,
        'totalLocations': results[2].count,
        'activeTrades': results[3].count,
        'pendingVerifications': results[0].count - results[1].count,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching admin dashboard stats: $e');
      }
      rethrow;
    }
  }

  /// Get all verified agents for agent selection
  Future<List<Map<String, dynamic>>> getVerifiedAgents() async {
    try {
      final response = await client
          .from('agents')
          .select()
          .eq('is_verified', true)
          .order('name', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching verified agents: $e');
      }
      rethrow;
    }
  }

  /// Get agent locations for a specific agent in a specific city
  Future<List<Map<String, dynamic>>> getAgentLocationsByCity({
    required String agentId,
    required String city,
  }) async {
    try {
      final response = await client
          .from('agent_locations')
          .select()
          .eq('agent_id', agentId)
          .eq('city', city)
          .eq('is_active', true)
          .order('display_alias', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations: $e');
      }
      rethrow;
    }
  }

  /// Get all agents with their location counts (Admin only)
  Future<List<Map<String, dynamic>>> getAllAgentsWithLocationCounts() async {
    try {
      final response = await client.from('agents').select('''
            *,
            agent_locations(
              id,
              city,
              area,
              display_alias,
              address_line,
              is_active,
              enable_buyer_matching,
              enable_seller_matching,
              city_wide_coverage,
              cross_region_access
            )
          ''').order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error fetching agents with location counts: $e');
      return [];
    }
  }

  /// Get agent locations with city-based filtering for trade matching
  Future<Map<String, dynamic>?> getAgentLocationForCity({
    required String agentId,
    required String city,
  }) async {
    try {
      final response = await client
          .from('agent_locations')
          .select()
          .eq('agent_id', agentId)
          .eq('city', city)
          .eq('is_active', true)
          .order('display_alias', ascending: true)
          .maybeSingle();

      return response != null ? Map<String, dynamic>.from(response) : null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent location for city: $e');
      }
      rethrow;
    }
  }

  /// Create trade with enhanced location assignment logic
  Future<Map<String, dynamic>> createTradeWithEnhancedAssignment({
    required String buyerId,
    required String sellerId,
    required String agentId,
    required String buyerCity,
    required String sellerCity,
    Map<String, dynamic>? tradeDetails,
  }) async {
    try {
      // Get seller's city location for the agent
      final sellerLocation = await getAgentLocationForCity(
        agentId: agentId,
        city: sellerCity,
      );

      if (sellerLocation == null) {
        throw Exception(
          'No active agent locations found in seller city: $sellerCity. '
          'Please choose a different agent or change the seller city.',
        );
      }

      // Get buyer's city location for the same agent
      final buyerLocation = await getAgentLocationForCity(
        agentId: agentId,
        city: buyerCity,
      );

      if (buyerLocation == null) {
        throw Exception(
          'No active agent locations found in buyer city: $buyerCity. '
          'Please choose a different agent or change the buyer city.',
        );
      }

      final response = await client
          .from('trades')
          .insert({
            'buyer_id': buyerId,
            'seller_id': sellerId,
            'agent_id': agentId,
            'buyer_location_id': buyerLocation['id'],
            'seller_location_id': sellerLocation['id'],
            'buyer_city': buyerCity,
            'seller_city': sellerCity,
            'status': 'CREATED',
            ...?tradeDetails,
          })
          .select()
          .single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating trade with enhanced assignment: $e');
      }
      rethrow;
    }
  }

  /// Get trade with detailed agent branch information for display
  Future<Map<String, dynamic>> getTradeWithAgentBranchInfo(
    String tradeId,
  ) async {
    try {
      final response = await client.from('trades').select('''
            *,
            agents!inner(
              id,
              name,
              alias,
              rating,
              agent_type,
              mobile_number
            ),
            buyer_location:agent_locations!buyer_location_id(
              id,
              display_alias,
              city,
              area,
              address_line,
              geo_lat,
              geo_lng
            ),
            seller_location:agent_locations!seller_location_id(
              id,
              display_alias,
              city,
              area,
              address_line,
              geo_lat,
              geo_lng
            )
          ''').eq('id', tradeId).single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade with agent branch info: $e');
      }
      rethrow;
    }
  }

  /// Validate agent coverage for cities (used before trade creation)
  Future<Map<String, bool>> validateAgentCityCoverage({
    required String agentId,
    required List<String> cities,
  }) async {
    try {
      final coverage = <String, bool>{};

      for (final city in cities) {
        final locations = await getAgentLocationsByCity(
          agentId: agentId,
          city: city,
        );
        coverage[city] = locations.isNotEmpty;
      }

      return coverage;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error validating agent city coverage: $e');
      }
      rethrow;
    }
  }

  /// Create new agent (Admin only)
  Future<Map<String, dynamic>> createAgent({
    required String name,
    required String alias,
    required String mobileNumber,
    required String agentType,
    required double rating,
    required bool isVerified,
    String? notes,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final agentData = {
        'name': name,
        'alias': alias,
        'mobile': mobileNumber,
        'agent_type': agentType,
        'rating': rating,
        'is_verified': isVerified,
        'notes': notes,
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
        ...?additionalData,
      };

      final response =
          await client.from('agents').insert(agentData).select().single();

      return response;
    } catch (e) {
      debugPrint('Error creating agent: $e');
      rethrow;
    }
  }

  /// Create multiple agent locations in batch (Admin only)
  Future<List<Map<String, dynamic>>> createAgentLocationsBatch({
    required String agentId,
    required List<Map<String, dynamic>> locations,
  }) async {
    try {
      final locationData = locations.map((location) {
        return {
          'agent_id': agentId,
          'city': location['city'],
          'area': location['area'],
          'display_alias': location['display_alias'],
          'address_line': location['address_line'],
          'is_active': location['is_active'] ?? true,
          'enable_buyer_matching': location['enable_buyer_matching'] ?? true,
          'enable_seller_matching': location['enable_seller_matching'] ?? true,
          'city_wide_coverage': location['city_wide_coverage'] ?? true,
          'cross_region_access': location['cross_region_access'] ?? false,
          'created_at': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        };
      }).toList();

      final response =
          await client.from('agent_locations').insert(locationData).select();

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      debugPrint('Error creating agent locations: $e');
      rethrow;
    }
  }

  /// Get available cities for agent location setup
  Future<List<String>> getAvailableCities() async {
    try {
      final response =
          await client.from('agent_locations').select('city').order('city');

      final cities =
          response.map((item) => item['city'].toString()).toSet().toList();

      // Add common cities if not present
      final commonCities = [
        'Mumbai',
        'Surat',
        'Delhi',
        'Pune',
        'Bangalore',
        'Chennai',
        'Hyderabad',
        'Ahmedabad',
        'Kolkata',
        'Jaipur',
      ];
      for (final city in commonCities) {
        if (!cities.contains(city)) {
          cities.add(city);
        }
      }

      cities.sort();
      return cities;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching available cities: $e');
      }
      return ['Mumbai', 'Surat', 'Delhi', 'Pune', 'Bangalore', 'Chennai'];
    }
  }

  /// Update agent verification status (Admin only)
  Future<Map<String, dynamic>> updateAgentVerification({
    required String agentId,
    required bool isVerified,
  }) async {
    try {
      final response = await client
          .from('agents')
          .update({'is_verified': isVerified})
          .eq('id', agentId)
          .select()
          .single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating agent verification: $e');
      }
      rethrow;
    }
  }

  /// Create new agent location (Admin only)
  Future<Map<String, dynamic>> createAgentLocation({
    required String agentId,
    required String city,
    required String area,
    required String displayAlias,
    required String addressLine,
    double? geoLat,
    double? geoLng,
    bool isActive = true,
  }) async {
    try {
      final response = await client
          .from('agent_locations')
          .insert({
            'agent_id': agentId,
            'city': city,
            'area': area,
            'display_alias': displayAlias,
            'address_line': addressLine,
            'geo_lat': geoLat,
            'geo_lng': geoLng,
            'is_active': isActive,
          })
          .select()
          .single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating agent location: $e');
      }
      rethrow;
    }
  }

  /// Get agent locations for management (Admin only)
  Future<List<Map<String, dynamic>>> getAgentLocationsForManagement(
    String agentId,
  ) async {
    try {
      final response = await client
          .from('agent_locations')
          .select()
          .eq('agent_id', agentId)
          .order('city', ascending: true)
          .order('area', ascending: true);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations for management: $e');
      }
      rethrow;
    }
  }

  /// Create trade with automatic agent location assignment
  Future<Map<String, dynamic>> createTradeWithAgentAssignment({
    required String buyerId,
    required String sellerId,
    required String agentId,
    required String buyerCity,
    required String sellerCity,
  }) async {
    try {
      // Get seller's city location for the agent
      final sellerLocations = await getAgentLocationsByCity(
        agentId: agentId,
        city: sellerCity,
      );

      if (sellerLocations.isEmpty) {
        throw Exception(
          'No active agent locations found in seller city: $sellerCity',
        );
      }

      // Get buyer's city location for the same agent
      final buyerLocations = await getAgentLocationsByCity(
        agentId: agentId,
        city: buyerCity,
      );

      if (buyerLocations.isEmpty) {
        throw Exception(
          'No active agent locations found in buyer city: $buyerCity',
        );
      }

      // Use the first active location (highest priority/nearest)
      final sellerLocationId = sellerLocations.first['id'];
      final buyerLocationId = buyerLocations.first['id'];

      final response = await client
          .from('trades')
          .insert({
            'buyer_id': buyerId,
            'seller_id': sellerId,
            'agent_id': agentId,
            'buyer_location_id': buyerLocationId,
            'seller_location_id': sellerLocationId,
            'buyer_city': buyerCity,
            'seller_city': sellerCity,
            'status': 'CREATED',
          })
          .select()
          .single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating trade with agent assignment: $e');
      }
      rethrow;
    }
  }

  /// Get trade with agent information (masked for privacy)
  Future<Map<String, dynamic>> getTradeWithAgentInfo(String tradeId) async {
    try {
      final response = await client.from('trades').select('''
            *,
            agents(
              name,
              alias,
              rating
            ),
            buyer_location:agent_locations!buyer_location_id(
              display_alias,
              city,
              area,
              address_line
            ),
            seller_location:agent_locations!seller_location_id(
              display_alias,
              city,
              area,
              address_line
            )
          ''').eq('id', tradeId).single();

      return Map<String, dynamic>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade with agent info: $e');
      }
      rethrow;
    }
  }

  /// Get allowed agents for a seller based on seller policies
  Future<List<Map<String, dynamic>>> getAllowedAgentsForSeller(
    String sellerId,
  ) async {
    try {
      // First check if seller has specific allowed agents policy
      final sellerPolicy = await client
          .from('seller_policies')
          .select('allowed_agent_ids')
          .eq('seller_id', sellerId)
          .maybeSingle();

      if (sellerPolicy != null && sellerPolicy['allowed_agent_ids'] != null) {
        // Return only allowed agents
        final allowedIds = List<String>.from(sellerPolicy['allowed_agent_ids']);
        final response = await client
            .from('agents')
            .select()
            .eq('is_verified', true)
            .inFilter('id', allowedIds)
            .order('name', ascending: true);

        return List<Map<String, dynamic>>.from(response);
      } else {
        // Return all verified agents
        return await getVerifiedAgents();
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching allowed agents for seller: $e');
      }
      rethrow;
    }
  }

  /// Update seller agent policies (Admin only)
  Future<void> updateSellerAgentPolicy({
    required String sellerId,
    required List<String> allowedAgentIds,
  }) async {
    try {
      await client.from('seller_policies').upsert({
        'seller_id': sellerId,
        'allowed_agent_ids': allowedAgentIds,
      });
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating seller agent policy: $e');
      }
      rethrow;
    }
  }

  /// Get agent analytics and performance metrics (Admin only)
  Future<Map<String, dynamic>> getAgentAnalytics(String agentId) async {
    try {
      // Get total trades count
      final tradesCount =
          await client.from('trades').select().eq('agent_id', agentId).count();

      // Get completed trades count
      final completedCount = await client
          .from('trades')
          .select()
          .eq('agent_id', agentId)
          .eq('status', 'RELEASED')
          .count();

      // Get active locations count
      final activeLocationsCount = await client
          .from('agent_locations')
          .select()
          .eq('agent_id', agentId)
          .eq('is_active', true)
          .count();

      return {
        'total_trades': tradesCount.count,
        'completed_trades': completedCount.count,
        'active_locations': activeLocationsCount.count,
        'success_rate': tradesCount.count > 0
            ? (completedCount.count / tradesCount.count * 100)
                .toStringAsFixed(1)
            : '0.0',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent analytics: $e');
      }
      rethrow;
    }
  }

  /// Update agent details
  Future<void> updateAgentDetails({
    required String agentId,
    String? name,
    String? alias,
    String? mobile,
    String? notes,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final updateData = <String, dynamic>{
        'updated_at': DateTime.now().toIso8601String(),
      };

      if (name != null) updateData['name'] = name;
      if (alias != null) updateData['alias'] = alias;
      if (mobile != null) updateData['mobile'] = mobile;
      if (notes != null) updateData['notes'] = notes;
      if (additionalData != null) updateData.addAll(additionalData);

      await client.from('agents').update(updateData).eq('id', agentId);
    } catch (e) {
      debugPrint('Error updating agent details: $e');
      rethrow;
    }
  }

  /// Delete an agent
  Future<void> deleteAgent(String agentId) async {
    try {
      // First delete all agent locations
      await client.from('agent_locations').delete().eq('agent_id', agentId);

      // Then delete the agent
      await client.from('agents').delete().eq('id', agentId);
    } catch (e) {
      throw Exception('Failed to delete agent: $e');
    }
  }

  /// Dispose resources
  void dispose() {
    _client = null;
    _instance = null;
  }
}