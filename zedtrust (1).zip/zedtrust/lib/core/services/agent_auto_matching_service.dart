import 'package:flutter/foundation.dart';

import './supabase_service.dart';

/// Auto-matching service for intelligent agent location assignment
class AgentAutoMatchingService {
  static AgentAutoMatchingService? _instance;
  static AgentAutoMatchingService get instance {
    _instance ??= AgentAutoMatchingService._();
    return _instance!;
  }

  AgentAutoMatchingService._();

  /// Auto-match agent based on seller and buyer cities with priority logic
  Future<Map<String, dynamic>> autoMatchAgentForTrade({
    required String sellerCity,
    required String buyerCity,
    required double tradeAmount,
    String? preferredAgentId,
  }) async {
    try {
      final supabaseService = SupabaseService.instance;

      // Step 1: Get all verified agents
      final agents = await supabaseService.getVerifiedAgents();

      if (agents.isEmpty) {
        throw Exception('No verified agents available');
      }

      // Step 2: Find agents with coverage in both cities
      Map<String, dynamic>? bestMatch;
      int highestScore = 0;

      for (final agent in agents) {
        final agentId = agent['id'];

        // Check city coverage
        final coverage = await supabaseService.validateAgentCityCoverage(
          agentId: agentId,
          cities: [sellerCity, buyerCity],
        );

        // Skip if agent doesn't cover both cities
        if (!coverage[sellerCity]! || !coverage[buyerCity]!) {
          continue;
        }

        // Calculate matching score
        final score = await _calculateAgentScore(
          agent: agent,
          sellerCity: sellerCity,
          buyerCity: buyerCity,
          tradeAmount: tradeAmount,
          isPreferred: preferredAgentId == agentId,
        );

        if (score > highestScore) {
          highestScore = score;
          bestMatch = agent;
        }
      }

      if (bestMatch == null) {
        throw Exception(
          'No agents found with coverage in both $sellerCity and $buyerCity',
        );
      }

      // Step 3: Get specific branch locations for the matched agent
      final sellerLocation = await supabaseService.getAgentLocationForCity(
        agentId: bestMatch['id'],
        city: sellerCity,
      );

      final buyerLocation = await supabaseService.getAgentLocationForCity(
        agentId: bestMatch['id'],
        city: buyerCity,
      );

      return {
        'agent': bestMatch,
        'sellerLocation': sellerLocation,
        'buyerLocation': buyerLocation,
        'matchingScore': highestScore,
        'agentBranchDisplay': _formatAgentBranchDisplay(
          agentName: bestMatch['name'],
          sellerBranch: sellerLocation?['display_alias'],
          buyerBranch: buyerLocation?['display_alias'],
        ),
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Auto-matching error: $e');
      }
      rethrow;
    }
  }

  /// Calculate agent matching score based on various factors
  Future<int> _calculateAgentScore({
    required Map<String, dynamic> agent,
    required String sellerCity,
    required String buyerCity,
    required double tradeAmount,
    bool isPreferred = false,
  }) async {
    int score = 0;

    // Preferred agent bonus
    if (isPreferred) score += 100;

    // Rating score (0-50 points)
    final rating = agent['rating']?.toDouble() ?? 0.0;
    score += (rating * 10).round() as int;

    // Verification status
    if (agent['is_verified'] == true) score += 25;

    // Agent type preference for trade amount
    final agentType = agent['agent_type'] ?? '';
    if (tradeAmount > 5000 && agentType == 'premium') {
      score += 20;
    } else if (tradeAmount <= 5000 && agentType == 'standard') {
      score += 15;
    }

    // Same city bonus (if seller and buyer are in same city)
    if (sellerCity == buyerCity) score += 10;

    return score;
  }

  /// Format agent branch display for P2P integration
  String _formatAgentBranchDisplay({
    required String agentName,
    String? sellerBranch,
    String? buyerBranch,
  }) {
    if (sellerBranch == buyerBranch && sellerBranch != null) {
      return '$agentName — $sellerBranch';
    } else {
      final sellerDisplay = sellerBranch ?? 'Unknown';
      final buyerDisplay = buyerBranch ?? 'Unknown';
      return '$agentName — $sellerDisplay | $buyerDisplay';
    }
  }

  /// Get available agents for a specific city with branch information
  Future<List<Map<String, dynamic>>> getAgentsForCity({
    required String city,
    int limit = 10,
  }) async {
    try {
      final supabaseService = SupabaseService.instance;
      final agents = await supabaseService.getVerifiedAgents();

      final List<Map<String, dynamic>> cityAgents = [];

      for (final agent in agents) {
        final agentId = agent['id'];
        final locations = await supabaseService.getAgentLocationsByCity(
          agentId: agentId,
          city: city,
        );

        if (locations.isNotEmpty) {
          // Add branch information to agent data
          final agentWithBranches = Map<String, dynamic>.from(agent);
          agentWithBranches['city_branches'] = locations;
          agentWithBranches['primary_branch'] = locations.first;
          cityAgents.add(agentWithBranches);
        }

        if (cityAgents.length >= limit) break;
      }

      // Sort by rating and availability
      cityAgents.sort((a, b) {
        final ratingA = a['rating']?.toDouble() ?? 0.0;
        final ratingB = b['rating']?.toDouble() ?? 0.0;
        return ratingB.compareTo(ratingA);
      });

      return cityAgents;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting agents for city: $e');
      }
      return [];
    }
  }

  /// Get agent branch network for P2P user profile display
  Future<List<Map<String, dynamic>>> getAgentBranchNetwork({
    required String agentId,
    required String userCity,
  }) async {
    try {
      final supabaseService = SupabaseService.instance;

      // Get all locations for the agent
      final locations = await supabaseService.getAgentLocationsForManagement(
        agentId,
      );

      final List<Map<String, dynamic>> branchNetwork = [];

      for (final location in locations) {
        final distance = _calculateCityDistance(userCity, location['city']);
        branchNetwork.add({
          ...location,
          'distance_priority': distance <= 0 ? 1 : 2, // 1 = local, 2 = nearby
          'agent_name': 'Agent Branch', // Will be populated from agent data
          'branch_alias': location['display_alias'],
          'branch_area': location['area'],
          'agent_rating': 4.8, // Will be populated from agent data
        });
      }

      // Sort by distance priority and rating
      branchNetwork.sort((a, b) {
        final priorityCompare = a['distance_priority'].compareTo(
          b['distance_priority'],
        );
        if (priorityCompare != 0) return priorityCompare;

        final ratingA = a['agent_rating']?.toDouble() ?? 0.0;
        final ratingB = b['agent_rating']?.toDouble() ?? 0.0;
        return ratingB.compareTo(ratingA);
      });

      return branchNetwork;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting agent branch network: $e');
      }
      return [];
    }
  }

  /// Simple city distance calculation (mock implementation)
  int _calculateCityDistance(String city1, String city2) {
    if (city1.toLowerCase() == city2.toLowerCase()) return 0;

    // Mock distance calculation - in real implementation, use geolocation
    final cityGroups = {
      'mumbai': ['mumbai', 'navi mumbai', 'thane'],
      'delhi': ['delhi', 'new delhi', 'gurgaon', 'noida'],
      'bangalore': ['bangalore', 'bengaluru'],
      'pune': ['pune', 'pimpri chinchwad'],
    };

    for (final group in cityGroups.values) {
      if (group.contains(city1.toLowerCase()) &&
          group.contains(city2.toLowerCase())) {
        return 1; // Nearby
      }
    }

    return 2; // Far
  }

  /// Dispose resources
  void dispose() {
    _instance = null;
  }
}