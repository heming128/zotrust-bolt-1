import 'package:flutter/foundation.dart';

import './agent_auto_matching_service.dart';
import './supabase_service.dart';

/// Trade flow integration service with automatic agent location assignment
class TradeFlowIntegrationService {
  static TradeFlowIntegrationService? _instance;
  static TradeFlowIntegrationService get instance {
    _instance ??= TradeFlowIntegrationService._();
    return _instance!;
  }

  TradeFlowIntegrationService._();

  /// Create trade with full auto-matching integration
  Future<Map<String, dynamic>> createTradeWithAutoMatching({
    required String buyerId,
    required String sellerId,
    required String sellerCity,
    required String buyerCity,
    required double tradeAmount,
    String? preferredAgentId,
    Map<String, dynamic>? additionalTradeData,
  }) async {
    try {
      final supabaseService = SupabaseService.instance;
      final autoMatchingService = AgentAutoMatchingService.instance;

      // Step 1: Auto-match the best agent with location assignment
      final matchResult = await autoMatchingService.autoMatchAgentForTrade(
        sellerCity: sellerCity,
        buyerCity: buyerCity,
        tradeAmount: tradeAmount,
        preferredAgentId: preferredAgentId,
      );

      final agent = matchResult['agent'] as Map<String, dynamic>;
      final sellerLocation =
          matchResult['sellerLocation'] as Map<String, dynamic>?;
      final buyerLocation =
          matchResult['buyerLocation'] as Map<String, dynamic>?;

      if (sellerLocation == null || buyerLocation == null) {
        throw Exception('Agent locations not found for the selected cities');
      }

      // Step 2: Create trade with enhanced location assignment
      final tradeData = {
        'buyer_id': buyerId,
        'seller_id': sellerId,
        'agent_id': agent['id'],
        'seller_location_id': sellerLocation['id'],
        'buyer_location_id': buyerLocation['id'],
        'seller_city': sellerCity,
        'buyer_city': buyerCity,
        'trade_amount': tradeAmount,
        'status': 'CREATED',
        'auto_matched': true,
        'matching_score': matchResult['matchingScore'],
        'agent_branch_display': matchResult['agentBranchDisplay'],
        ...?additionalTradeData,
      };

      final trade =
          await supabaseService.client
              .from('trades')
              .insert(tradeData)
              .select()
              .single();

      // Step 3: Return comprehensive trade information
      return {
        'trade': trade,
        'agent': agent,
        'sellerLocation': sellerLocation,
        'buyerLocation': buyerLocation,
        'agentBranchDisplay': matchResult['agentBranchDisplay'],
        'autoMatched': true,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Trade flow integration error: $e');
      }
      rethrow;
    }
  }

  /// Get trade with complete agent branch information for display
  Future<Map<String, dynamic>> getTradeWithFullAgentInfo(String tradeId) async {
    try {
      final supabaseService = SupabaseService.instance;

      // Get trade with agent branch information
      final trade = await supabaseService.getTradeWithAgentBranchInfo(tradeId);

      // Enhance with P2P display format
      final agentName = trade['agents']['name'] ?? 'Unknown Agent';
      final sellerBranch = trade['seller_location']?['display_alias'];
      final buyerBranch = trade['buyer_location']?['display_alias'];

      final agentBranchDisplay = _formatP2PAgentDisplay(
        agentName: agentName,
        sellerBranch: sellerBranch,
        buyerBranch: buyerBranch,
      );

      return {
        ...trade,
        'agent_branch_display': agentBranchDisplay,
        'seller_branch_info': {
          'city': trade['seller_city'],
          'branch': sellerBranch,
          'area': trade['seller_location']?['area'],
          'address': trade['seller_location']?['address_line'],
        },
        'buyer_branch_info': {
          'city': trade['buyer_city'],
          'branch': buyerBranch,
          'area': trade['buyer_location']?['area'],
          'address': trade['buyer_location']?['address_line'],
        },
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting trade with full agent info: $e');
      }
      rethrow;
    }
  }

  /// Format P2P agent display with proper branch information
  String _formatP2PAgentDisplay({
    required String agentName,
    String? sellerBranch,
    String? buyerBranch,
  }) {
    if (sellerBranch == null && buyerBranch == null) {
      return '$agentName — No Branch Info';
    }

    if (sellerBranch == buyerBranch && sellerBranch != null) {
      return '$agentName — $sellerBranch Branch';
    }

    final seller = sellerBranch ?? 'Unknown';
    final buyer = buyerBranch ?? 'Unknown';
    return '$agentName — $seller | $buyer';
  }

  /// Get P2P orders with agent branch information
  Future<List<Map<String, dynamic>>> getP2POrdersWithAgentInfo({
    required String orderType, // 'buy' or 'sell'
    String? cityFilter,
    int limit = 20,
  }) async {
    try {
      final supabaseService = SupabaseService.instance;

      // Get P2P orders (mock implementation - replace with actual P2P orders table)
      final orders = await supabaseService.client
          .from('p2p_orders')
          .select('''
            *,
            agents(
              id,
              name,
              alias,
              rating
            ),
            agent_locations!agent_location_id(
              display_alias,
              city,
              area,
              address_line
            )
          ''')
          .eq('order_type', orderType)
          .eq('status', 'active')
          .order('created_at', ascending: false)
          .limit(limit);

      // Enhance with P2P display format
      return orders.map<Map<String, dynamic>>((order) {
        final agentName = order['agents']?['name'] ?? 'Unknown Agent';
        final branchAlias = order['agent_locations']?['display_alias'];
        final city = order['agent_locations']?['city'];

        return {
          ...order,
          'agent_branch_display': '$agentName — $branchAlias ($city)',
          'formatted_agent_info': {
            'name': agentName,
            'branch': branchAlias,
            'city': city,
            'rating': order['agents']?['rating'] ?? 0.0,
          },
        };
      }).toList();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting P2P orders with agent info: $e');
      }
      return [];
    }
  }

  /// Validate trade flow requirements
  Future<Map<String, dynamic>> validateTradeFlowRequirements({
    required String sellerCity,
    required String buyerCity,
    required double tradeAmount,
  }) async {
    try {
      final autoMatchingService = AgentAutoMatchingService.instance;
      final supabaseService = SupabaseService.instance;

      // Check if there are any agents with coverage in both cities
      final agents = await supabaseService.getVerifiedAgents();
      int availableAgents = 0;

      for (final agent in agents) {
        final coverage = await supabaseService.validateAgentCityCoverage(
          agentId: agent['id'],
          cities: [sellerCity, buyerCity],
        );

        if (coverage[sellerCity]! && coverage[buyerCity]!) {
          availableAgents++;
        }
      }

      return {
        'isValid': availableAgents > 0,
        'availableAgents': availableAgents,
        'sellerCity': sellerCity,
        'buyerCity': buyerCity,
        'tradeAmount': tradeAmount,
        'recommendations':
            availableAgents == 0
                ? [
                  'Try selecting agents in different cities',
                  'Contact support for agent network expansion',
                ]
                : ['Multiple agents available for your trade'],
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error validating trade flow requirements: $e');
      }
      return {'isValid': false, 'error': e.toString()};
    }
  }

  /// Get agent performance analytics for trade flow optimization
  Future<Map<String, dynamic>> getAgentPerformanceForTradeFlow(
    String agentId,
  ) async {
    try {
      final supabaseService = SupabaseService.instance;

      // Get agent analytics
      final analytics = await supabaseService.getAgentAnalytics(agentId);

      // Get location-specific performance
      final locations = await supabaseService.getAgentLocationsForManagement(
        agentId,
      );

      return {
        ...analytics,
        'location_coverage': locations.length,
        'cities_served': locations.map((loc) => loc['city']).toSet().toList(),
        'performance_rating': _calculatePerformanceRating(analytics),
        'trade_flow_optimization': {
          'avg_response_time': '< 5 minutes',
          'success_rate': analytics['success_rate'],
          'recommended_for_amount_range': _getRecommendedAmountRange(analytics),
        },
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting agent performance: $e');
      }
      return {};
    }
  }

  /// Calculate performance rating for trade flow
  String _calculatePerformanceRating(Map<String, dynamic> analytics) {
    final successRate =
        double.tryParse(analytics['success_rate'] ?? '0') ?? 0.0;
    final totalTrades = analytics['total_trades'] ?? 0;

    if (successRate >= 95 && totalTrades >= 100) return 'Excellent';
    if (successRate >= 90 && totalTrades >= 50) return 'Very Good';
    if (successRate >= 85 && totalTrades >= 20) return 'Good';
    return 'Developing';
  }

  /// Get recommended amount range for agent
  String _getRecommendedAmountRange(Map<String, dynamic> analytics) {
    final totalTrades = analytics['total_trades'] ?? 0;

    if (totalTrades >= 200) return '\$100 - \$50,000';
    if (totalTrades >= 100) return '\$100 - \$25,000';
    if (totalTrades >= 50) return '\$100 - \$10,000';
    return '\$100 - \$5,000';
  }

  /// Dispose resources
  void dispose() {
    _instance = null;
  }
}
