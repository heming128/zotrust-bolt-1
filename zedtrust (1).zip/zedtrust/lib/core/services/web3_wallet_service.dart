import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:web3dart/web3dart.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:http/http.dart' as http;

enum WalletType { metamask, trustWallet, walletConnect, unknown }

enum WalletConnectionStatus { disconnected, connecting, connected, failed }

class ConnectedWallet {
  final String address;
  final WalletType type;
  final String? ensName;
  final DateTime connectedAt;

  ConnectedWallet({
    required this.address,
    required this.type,
    this.ensName,
    required this.connectedAt,
  });

  Map<String, dynamic> toJson() => {
        'address': address,
        'type': type.name,
        'ensName': ensName,
        'connectedAt': connectedAt.toIso8601String(),
      };

  factory ConnectedWallet.fromJson(Map<String, dynamic> json) =>
      ConnectedWallet(
        address: json['address'],
        type: WalletType.values.firstWhere((e) => e.name == json['type']),
        ensName: json['ensName'],
        connectedAt: DateTime.parse(json['connectedAt']),
      );
}

class WalletBalance {
  final BigInt wei;
  final String symbol;
  final int decimals;

  WalletBalance({required this.wei, required this.symbol, this.decimals = 18});

  String get formatted {
    final divisor = BigInt.from(10).pow(decimals);
    final eth = wei ~/ divisor;
    final remainder = wei.remainder(divisor);
    final remainderStr = remainder.toString().padLeft(decimals, '0');
    final trimmed = remainderStr.replaceAll(RegExp(r'0+$'), '');

    return trimmed.isEmpty
        ? eth.toString()
        : '$eth.${trimmed.substring(0, min(trimmed.length, 6))}';
  }

  double get asDouble {
    final divisor = BigInt.from(10).pow(decimals);
    return wei.toDouble() / divisor.toDouble();
  }
}

class Web3WalletService {
  static final Web3WalletService _instance = Web3WalletService._internal();
  static Web3WalletService get instance => _instance;
  Web3WalletService._internal();

  // Web3 clients for different networks
  static const String polygonAmoyRpc = 'https://rpc-amoy.polygon.technology';
  static const String polygonAmoyWs = 'wss://ws-amoy.polygon.technology';
  static const int polygonAmoyChainId = 80002;

  // Contract configuration
  static final String contractAddressString = const String.fromEnvironment(
    'CONTRACT_ADDRESS',
    defaultValue: '0xf3fcdaaE3320D32e2386B795FA4e3F93e22634f5',
  );

  Web3Client? _web3Client;
  WebSocketChannel? _wsChannel;

  ConnectedWallet? _connectedWallet;
  WalletConnectionStatus _connectionStatus =
      WalletConnectionStatus.disconnected;

  final StreamController<WalletConnectionStatus> _statusController =
      StreamController<WalletConnectionStatus>.broadcast();
  final StreamController<ConnectedWallet?> _walletController =
      StreamController<ConnectedWallet?>.broadcast();
  final StreamController<WalletBalance?> _balanceController =
      StreamController<WalletBalance?>.broadcast();

  // Initialization flag
  bool _isInitialized = false;

  // Getters
  ConnectedWallet? get connectedWallet => _connectedWallet;
  WalletConnectionStatus get connectionStatus => _connectionStatus;
  Stream<WalletConnectionStatus> get statusStream => _statusController.stream;
  Stream<ConnectedWallet?> get walletStream => _walletController.stream;
  Stream<WalletBalance?> get balanceStream => _balanceController.stream;

  bool get isConnected =>
      _connectionStatus == WalletConnectionStatus.connected &&
      _connectedWallet != null;

  bool get isInitialized => _isInitialized;

  // Initialize Web3 client
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Initialize HTTP client for Polygon Amoy
      _web3Client = Web3Client(polygonAmoyRpc, http.Client());

      // Test connection with timeout
      await _web3Client!.getChainId().timeout(const Duration(seconds: 10));

      _isInitialized = true;

      if (kDebugMode) {
        print('✅ Web3WalletService initialized successfully');
        print(
          '🌐 Connected to Polygon Amoy network (Chain ID: $polygonAmoyChainId)',
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Web3WalletService initialization failed: $e');
      }
      // Don't rethrow - allow app to continue in bypass mode
      _isInitialized = false;
    }
  }

  // Connect to MetaMask via deep linking
  Future<bool> connectToMetaMask() async {
    return await _connectToWallet(WalletType.metamask);
  }

  // Connect to Trust Wallet via deep linking
  Future<bool> connectToTrustWallet() async {
    return await _connectToWallet(WalletType.trustWallet);
  }

  // Connect via WalletConnect v2
  Future<bool> connectViaWalletConnect() async {
    return await _connectToWallet(WalletType.walletConnect);
  }

  // Generic wallet connection with enhanced deep linking
  Future<bool> _connectToWallet(WalletType walletType) async {
    if (_connectionStatus == WalletConnectionStatus.connecting) {
      return false;
    }

    _updateConnectionStatus(WalletConnectionStatus.connecting);

    try {
      if (!_isInitialized) {
        await initialize();
      }

      // Generate connection request
      final connectionRequest = _generateConnectionRequest();

      // Handle different wallet types
      bool connected = false;
      switch (walletType) {
        case WalletType.metamask:
          connected = await _connectToMetaMask(connectionRequest);
          break;
        case WalletType.trustWallet:
          connected = await _connectToTrustWallet(connectionRequest);
          break;
        case WalletType.walletConnect:
          connected = await _connectViaWalletConnectV2();
          break;
        default:
          throw Exception('Unsupported wallet type: ${walletType.name}');
      }

      if (connected) {
        _updateConnectionStatus(WalletConnectionStatus.connected);
        return true;
      } else {
        throw Exception('Wallet connection rejected or timed out');
      }
    } catch (e) {
      _updateConnectionStatus(WalletConnectionStatus.failed);
      if (kDebugMode) {
        print('❌ Wallet connection failed: $e');
      }
      return false;
    }
  }

  Future<bool> _connectToMetaMask(Map<String, dynamic> request) async {
    try {
      // Create MetaMask deep link
      final deepLinkUrl = _buildMetaMaskDeepLink(request);

      // Launch MetaMask app
      final launched = await _launchWalletApp(deepLinkUrl);

      if (!launched) {
        throw Exception('Failed to launch MetaMask app');
      }

      // Wait for connection response (simulated for now)
      final connected = await _waitForWalletResponse(WalletType.metamask);
      return connected;
    } catch (e) {
      if (kDebugMode) {
        print('❌ MetaMask connection failed: $e');
      }
      return false;
    }
  }

  Future<bool> _connectToTrustWallet(Map<String, dynamic> request) async {
    try {
      // Create Trust Wallet deep link
      final deepLinkUrl = _buildTrustWalletDeepLink(request);

      // Launch Trust Wallet app
      final launched = await _launchWalletApp(deepLinkUrl);

      if (!launched) {
        throw Exception('Failed to launch Trust Wallet app');
      }

      // Wait for connection response
      final connected = await _waitForWalletResponse(WalletType.trustWallet);
      return connected;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Trust Wallet connection failed: $e');
      }
      return false;
    }
  }

  Future<bool> _connectViaWalletConnectV2() async {
    try {
      if (kDebugMode) {
        print('🔗 Initiating WalletConnect v2 session...');
      }

      // Simulate WalletConnect v2 initialization
      await Future.delayed(const Duration(seconds: 2));

      // For demo purposes, generate a mock connection
      final connected = await _waitForWalletResponse(WalletType.walletConnect);
      return connected;
    } catch (e) {
      if (kDebugMode) {
        print('❌ WalletConnect connection failed: $e');
      }
      return false;
    }
  }

  // Generate mock wallet addresses and connection for demo purposes
  Future<bool> _waitForWalletResponse(WalletType walletType) async {
    try {
      // Simulate connection delay
      await Future.delayed(const Duration(seconds: 2));

      // Generate mock wallet address
      final mockAddress = _generateMockAddress();

      _connectedWallet = ConnectedWallet(
        address: mockAddress,
        type: walletType,
        connectedAt: DateTime.now(),
      );

      _walletController.add(_connectedWallet);

      // Fetch balance after connection
      await _fetchBalance();

      return true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Wallet response timeout: $e');
      }
      return false;
    }
  }

  // Build wallet-specific deep link URLs
  String _buildMetaMaskDeepLink(Map<String, dynamic> request) {
    final requestData = Uri.encodeComponent(jsonEncode(request));
    return 'metamask://wc?uri=$requestData';
  }

  String _buildTrustWalletDeepLink(Map<String, dynamic> request) {
    final requestData = Uri.encodeComponent(jsonEncode(request));
    return 'trust://wc?uri=$requestData';
  }

  // Launch wallet application with fallback support
  Future<bool> _launchWalletApp(String url) async {
    try {
      final uri = Uri.parse(url);

      if (await canLaunchUrl(uri)) {
        return await launchUrl(uri, mode: LaunchMode.externalApplication);
      }

      // Fallback to web if app not installed
      return await _launchWalletFallback(url);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to launch wallet app: $e');
      }
      return false;
    }
  }

  // Fallback to web-based connection
  Future<bool> _launchWalletFallback(String originalUrl) async {
    try {
      String fallbackUrl;

      if (originalUrl.contains('metamask://')) {
        fallbackUrl =
            'https://metamask.app.link/dapp/${Uri.encodeComponent('https://app.uniswap.org')}';
      } else if (originalUrl.contains('trust://')) {
        fallbackUrl =
            'https://link.trustwallet.com/open_url?coin_id=60&url=${Uri.encodeComponent('https://app.uniswap.org')}';
      } else {
        return false;
      }

      return await launchUrl(Uri.parse(fallbackUrl));
    } catch (e) {
      if (kDebugMode) {
        print('❌ Fallback wallet launch failed: $e');
      }
      return false;
    }
  }

  // Generate connection request data
  Map<String, dynamic> _generateConnectionRequest() {
    return {
      'id': DateTime.now().millisecondsSinceEpoch,
      'jsonrpc': '2.0',
      'method': 'eth_requestAccounts',
      'params': [],
      'chainId': polygonAmoyChainId,
      'origin': 'ZedTrust DApp',
    };
  }

  // Generate mock address for demo
  String _generateMockAddress() {
    final random = Random();
    final bytes = List<int>.generate(20, (i) => random.nextInt(256));
    return '0x${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}';
  }

  // Fetch wallet balance
  Future<void> _fetchBalance() async {
    if (_web3Client == null || _connectedWallet == null || !_isInitialized) {
      return;
    }

    try {
      final addressObj = EthereumAddress.fromHex(_connectedWallet!.address);
      final balance = await _web3Client!.getBalance(addressObj);

      final walletBalance = WalletBalance(
        wei: balance.getInWei,
        symbol: 'MATIC',
        decimals: 18,
      );

      _balanceController.add(walletBalance);

      if (kDebugMode) {
        print('💰 Wallet balance: ${walletBalance.formatted} MATIC');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to fetch balance: $e');
      }
      _balanceController.add(null);
    }
  }

  // Get token balance for specific ERC20 token
  Future<WalletBalance?> getTokenBalance(
    String tokenAddress, {
    String symbol = 'TOKEN',
    int decimals = 18,
  }) async {
    if (_web3Client == null || _connectedWallet == null || !_isInitialized) {
      return null;
    }

    try {
      const abi = '''[
        {
          "constant": true,
          "inputs": [{"name": "_owner", "type": "address"}],
          "name": "balanceOf",
          "outputs": [{"name": "balance", "type": "uint256"}],
          "type": "function"
        }
      ]''';

      final contract = DeployedContract(
        ContractAbi.fromJson(abi, 'ERC20'),
        EthereumAddress.fromHex(tokenAddress),
      );

      final balanceFunction = contract.function('balanceOf');
      final addressObj = EthereumAddress.fromHex(_connectedWallet!.address);

      final result = await _web3Client!.call(
        contract: contract,
        function: balanceFunction,
        params: [addressObj],
      );

      final balance = result.first as BigInt;

      return WalletBalance(wei: balance, symbol: symbol, decimals: decimals);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to fetch token balance: $e');
      }
      return null;
    }
  }

  // Disconnect wallet
  Future<void> disconnect() async {
    _connectedWallet = null;
    _updateConnectionStatus(WalletConnectionStatus.disconnected);
    _walletController.add(null);
    _balanceController.add(null);

    if (kDebugMode) {
      print('🔌 Wallet disconnected');
    }
  }

  // Update connection status and notify listeners
  void _updateConnectionStatus(WalletConnectionStatus status) {
    _connectionStatus = status;
    _statusController.add(status);
  }

  // Copy wallet address to clipboard
  Future<void> copyAddressToClipboard() async {
    if (_connectedWallet?.address != null) {
      await Clipboard.setData(ClipboardData(text: _connectedWallet!.address));
    }
  }

  // Get truncated wallet address for display
  String get truncatedAddress {
    if (_connectedWallet?.address == null) return '';
    final address = _connectedWallet!.address;
    return '${address.substring(0, 6)}...${address.substring(address.length - 4)}';
  }

  // Convert wallet address string to EthereumAddress object
  EthereumAddress? get ethereumAddress {
    if (_connectedWallet?.address == null) return null;
    try {
      return EthereumAddress.fromHex(_connectedWallet!.address);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to convert address to EthereumAddress: $e');
      }
      return null;
    }
  }

  // Convert any wallet address string to EthereumAddress object
  static EthereumAddress? addressFromHex(String? addressString) {
    if (addressString == null || addressString.isEmpty) return null;
    try {
      return EthereumAddress.fromHex(addressString);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to convert address string to EthereumAddress: $e');
      }
      return null;
    }
  }

  // Refresh balance
  Future<void> refreshBalance() async {
    await _fetchBalance();
  }

  // Dispose resources
  void dispose() {
    _statusController.close();
    _walletController.close();
    _balanceController.close();
    _wsChannel?.sink.close();
    _web3Client?.dispose();
  }
}