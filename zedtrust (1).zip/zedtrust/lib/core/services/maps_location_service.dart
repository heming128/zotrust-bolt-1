import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:dio/dio.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';

/// Service for Google Maps integration and location validation
class MapsLocationService {
  static MapsLocationService? _instance;
  static MapsLocationService get instance =>
      _instance ??= MapsLocationService._();

  MapsLocationService._();

  final Dio _dio = Dio();

  // Google Maps API configuration
  static const String _googleMapsApiKey = String.fromEnvironment(
    'GOOGLE_MAPS_API_KEY',
    defaultValue: 'YOUR_GOOGLE_MAPS_API_KEY_HERE',
  );

  /// Request location permissions
  Future<Map<String, dynamic>> requestLocationPermission() async {
    try {
      PermissionStatus permission = await Permission.location.request();

      if (permission.isGranted) {
        return {
          'success': true,
          'message': 'Location permission granted',
        };
      } else if (permission.isDenied) {
        return {
          'success': false,
          'message': 'Location permission denied',
          'can_request_again': true,
        };
      } else if (permission.isPermanentlyDenied) {
        return {
          'success': false,
          'message':
              'Location permission permanently denied. Please enable in settings.',
          'open_settings_required': true,
        };
      }

      return {
        'success': false,
        'message': 'Location permission request failed',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Location permission request failed: $e');
      }
      return {
        'success': false,
        'message': 'Permission request error: $e',
      };
    }
  }

  /// Get current device location
  Future<Map<String, dynamic>> getCurrentLocation() async {
    try {
      // Check if location service is enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return {
          'success': false,
          'message': 'Location service is disabled. Please enable GPS.',
          'enable_location_required': true,
        };
      }

      // Check permissions
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return {
            'success': false,
            'message': 'Location permission denied',
          };
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return {
          'success': false,
          'message': 'Location permission permanently denied',
        };
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );

      if (kDebugMode) {
        print(
            '✅ Location obtained: ${position.latitude}, ${position.longitude}');
      }

      return {
        'success': true,
        'latitude': position.latitude,
        'longitude': position.longitude,
        'accuracy': position.accuracy,
        'timestamp': position.timestamp.toIso8601String(),
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Failed to get current location: $e');
      }
      return {
        'success': false,
        'message': 'Failed to get location: $e',
      };
    }
  }

  /// Validate address using Google Maps Geocoding API
  Future<Map<String, dynamic>> validateAddress({
    required String address,
    String? city,
    String? state,
    String? country = 'India',
  }) async {
    try {
      if (_googleMapsApiKey == 'YOUR_GOOGLE_MAPS_API_KEY_HERE') {
        // Fallback to mock validation if API key not configured
        return _mockAddressValidation(address, city);
      }

      String fullAddress = address;
      if (city != null) fullAddress += ', $city';
      if (state != null) fullAddress += ', $state';
      if (country != null) fullAddress += ', $country';

      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/geocode/json',
        queryParameters: {
          'address': fullAddress,
          'key': _googleMapsApiKey,
          'region': 'in', // Bias results to India
        },
      );

      if (response.statusCode == 200 && response.data['status'] == 'OK') {
        final results = response.data['results'] as List;
        if (results.isNotEmpty) {
          final result = results.first;
          final geometry = result['geometry'];
          final location = geometry['location'];

          return {
            'success': true,
            'valid': true,
            'latitude': location['lat'],
            'longitude': location['lng'],
            'formatted_address': result['formatted_address'],
            'place_id': result['place_id'],
            'types': result['types'],
          };
        }
      }

      return {
        'success': true,
        'valid': false,
        'message': 'Address not found or invalid',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Address validation failed: $e');
      }

      // Fallback to mock validation on error
      return _mockAddressValidation(address, city);
    }
  }

  /// Mock address validation (fallback when Google Maps API unavailable)
  Map<String, dynamic> _mockAddressValidation(String address, String? city) {
    // Generate deterministic coordinates based on address hash
    final fullAddress = city != null ? '$address, $city' : address;
    final bytes = utf8.encode(fullAddress.toLowerCase());
    final digest = sha256.convert(bytes);
    final hashValue = digest.bytes.fold(0, (prev, element) => prev + element);

    // Map to realistic coordinates for major Indian cities
    final cityCoordinates = {
      'mumbai': {'lat': 19.0760, 'lng': 72.8777},
      'surat': {'lat': 21.1702, 'lng': 72.8311},
      'delhi': {'lat': 28.7041, 'lng': 77.1025},
      'pune': {'lat': 18.5204, 'lng': 73.8567},
      'bangalore': {'lat': 12.9716, 'lng': 77.5946},
      'chennai': {'lat': 13.0827, 'lng': 80.2707},
      'kolkata': {'lat': 22.5726, 'lng': 88.3639},
      'hyderabad': {'lat': 17.3850, 'lng': 78.4867},
      'ahmedabad': {'lat': 23.0225, 'lng': 72.5714},
      'jaipur': {'lat': 26.9124, 'lng': 75.7873},
    };

    final cityKey = city?.toLowerCase() ?? 'mumbai';
    final baseCoords = cityCoordinates[cityKey] ?? cityCoordinates['mumbai']!;

    // Add small random offset based on hash
    final latOffset = ((hashValue % 1000) - 500) / 10000.0; // ±0.05 degrees
    final lngOffset = ((hashValue % 1500) - 750) / 10000.0; // ±0.075 degrees

    if (kDebugMode) {
      print('🔄 Using mock address validation for: $fullAddress');
    }

    return {
      'success': true,
      'valid': true,
      'latitude': baseCoords['lat']! + latOffset,
      'longitude': baseCoords['lng']! + lngOffset,
      'formatted_address': '$fullAddress (Mock Location)',
      'is_mock': true,
      'message': 'Using mock coordinates (Google Maps API not configured)',
    };
  }

  /// Get distance between two points
  Future<Map<String, dynamic>> getDistanceBetween({
    required double lat1,
    required double lng1,
    required double lat2,
    required double lng2,
  }) async {
    try {
      // Calculate distance using Haversine formula
      double distanceInMeters =
          Geolocator.distanceBetween(lat1, lng1, lat2, lng2);
      double distanceInKm = distanceInMeters / 1000;

      return {
        'success': true,
        'distance_meters': distanceInMeters,
        'distance_km': distanceInKm,
        'distance_formatted': _formatDistance(distanceInMeters),
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Distance calculation failed: $e');
      }
      return {
        'success': false,
        'message': 'Failed to calculate distance: $e',
      };
    }
  }

  /// Format distance for display
  String _formatDistance(double distanceInMeters) {
    if (distanceInMeters < 1000) {
      return '${distanceInMeters.round()}m';
    } else {
      return '${(distanceInMeters / 1000).toStringAsFixed(1)}km';
    }
  }

  /// Get nearby places using Google Places API
  Future<Map<String, dynamic>> getNearbyPlaces({
    required double latitude,
    required double longitude,
    String type = 'bank',
    int radius = 5000,
  }) async {
    try {
      if (_googleMapsApiKey == 'YOUR_GOOGLE_MAPS_API_KEY_HERE') {
        return _mockNearbyPlaces(type);
      }

      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
        queryParameters: {
          'location': '$latitude,$longitude',
          'radius': radius,
          'type': type,
          'key': _googleMapsApiKey,
        },
      );

      if (response.statusCode == 200 && response.data['status'] == 'OK') {
        final results = response.data['results'] as List;
        final places = results
            .map((place) => {
                  'name': place['name'],
                  'place_id': place['place_id'],
                  'latitude': place['geometry']['location']['lat'],
                  'longitude': place['geometry']['location']['lng'],
                  'rating': place['rating'],
                  'types': place['types'],
                  'vicinity': place['vicinity'],
                })
            .toList();

        return {
          'success': true,
          'places': places,
        };
      }

      return {
        'success': false,
        'message': 'No places found',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Nearby places search failed: $e');
      }
      return _mockNearbyPlaces(type);
    }
  }

  /// Mock nearby places (fallback)
  Map<String, dynamic> _mockNearbyPlaces(String type) {
    final mockPlaces = {
      'bank': [
        {'name': 'State Bank of India', 'rating': 4.2},
        {'name': 'HDFC Bank', 'rating': 4.0},
        {'name': 'ICICI Bank', 'rating': 3.8},
      ],
      'atm': [
        {'name': 'SBI ATM', 'rating': 4.0},
        {'name': 'HDFC ATM', 'rating': 4.1},
        {'name': 'Axis Bank ATM', 'rating': 3.9},
      ],
    };

    return {
      'success': true,
      'places': mockPlaces[type] ?? [],
      'is_mock': true,
    };
  }

  /// Validate city name exists
  Future<Map<String, dynamic>> validateCity(String cityName) async {
    try {
      if (_googleMapsApiKey == 'YOUR_GOOGLE_MAPS_API_KEY_HERE') {
        return _mockCityValidation(cityName);
      }

      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/geocode/json',
        queryParameters: {
          'address': '$cityName, India',
          'key': _googleMapsApiKey,
          'types': 'locality',
        },
      );

      if (response.statusCode == 200 && response.data['status'] == 'OK') {
        final results = response.data['results'] as List;
        if (results.isNotEmpty) {
          final result = results.first;
          final geometry = result['geometry'];
          final location = geometry['location'];

          return {
            'success': true,
            'valid': true,
            'city_name': cityName,
            'latitude': location['lat'],
            'longitude': location['lng'],
            'formatted_address': result['formatted_address'],
          };
        }
      }

      return {
        'success': true,
        'valid': false,
        'message': 'City not found',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ City validation failed: $e');
      }
      return _mockCityValidation(cityName);
    }
  }

  /// Mock city validation
  Map<String, dynamic> _mockCityValidation(String cityName) {
    final validCities = [
      'mumbai',
      'surat',
      'delhi',
      'pune',
      'bangalore',
      'chennai',
      'kolkata',
      'hyderabad',
      'ahmedabad',
      'jaipur',
      'lucknow',
      'kanpur',
      'nagpur',
      'indore',
      'thane',
      'bhopal',
      'visakhapatnam',
    ];

    final isValid = validCities.contains(cityName.toLowerCase());

    return {
      'success': true,
      'valid': isValid,
      'city_name': cityName,
      'is_mock': true,
      'message':
          isValid ? 'City validated (mock)' : 'City not found in mock data',
    };
  }

  /// Create Google Maps markers for agent locations
  Set<Marker> createAgentMarkers(List<Map<String, dynamic>> agentLocations) {
    final markers = <Marker>{};

    for (int i = 0; i < agentLocations.length; i++) {
      final location = agentLocations[i];
      final lat = location['geo_lat'] as double?;
      final lng = location['geo_lng'] as double?;

      if (lat != null && lng != null) {
        markers.add(
          Marker(
            markerId: MarkerId('agent_${location['id']}'),
            position: LatLng(lat, lng),
            infoWindow: InfoWindow(
              title: location['display_alias'] ?? 'Agent Location',
              snippet: '${location['area']}, ${location['city']}',
            ),
            onTap: () {
              // Handle marker tap
              if (kDebugMode) {
                print('🗺️ Agent marker tapped: ${location['display_alias']}');
              }
            },
          ),
        );
      }
    }

    return markers;
  }

  /// Watch position changes
  Stream<Position> watchPosition() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10, // Update every 10 meters
      ),
    );
  }

  /// Calculate bearing between two points
  double calculateBearing({
    required double lat1,
    required double lng1,
    required double lat2,
    required double lng2,
  }) {
    return Geolocator.bearingBetween(lat1, lng1, lat2, lng2);
  }

  /// Check if Google Maps API is configured
  bool get isGoogleMapsConfigured =>
      _googleMapsApiKey != 'YOUR_GOOGLE_MAPS_API_KEY_HERE';

  /// Dispose resources
  void dispose() {
    // Cleanup if needed
  }
}
