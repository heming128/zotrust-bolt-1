import 'package:flutter/foundation.dart';
import './trade_fee_logic_service.dart';
import './platform_settings_service.dart';

/// EscrowSettlementService: Handles USDC trade escrow operations with platform fees
/// on Polygon chain. Manages lock, release, and refund operations with exact fee calculations.
class EscrowSettlementService {
  static final EscrowSettlementService _instance =
      EscrowSettlementService._internal();
  static EscrowSettlementService get instance => _instance;
  EscrowSettlementService._internal();

  final TradeFeeLogicService _feeLogic = TradeFeeLogicService.instance;
  final PlatformSettingsService _platformSettings =
      PlatformSettingsService.instance;

  /// Create escrow lock transaction for seller
  /// Seller must lock RequiredLockFromSeller (1.01 * G) into escrow
  Future<Map<String, dynamic>> createEscrowLock({
    required String tradeId,
    required double grossTradeAmount,
    required String sellerAddress,
    required String buyerAddress,
    String? agentAddress,
  }) async {
    try {
      // Validate platform configuration
      final platformConfig = await _feeLogic.validatePlatformConfiguration();
      if (!platformConfig['tradeFeeLogicReady']) {
        throw Exception(
          'Platform fees not properly configured: ${platformConfig['errors']}',
        );
      }

      // Get fee wallet address
      final feeWalletAddress = await _feeLogic.getFeeWalletAddress();
      if (feeWalletAddress == null) {
        throw Exception('Platform fee wallet not configured');
      }

      // Calculate escrow parameters
      final escrowParams = _feeLogic.generateEscrowSettlementParams(
        grossTradeAmount: grossTradeAmount,
        buyerAddress: buyerAddress,
        sellerAddress: sellerAddress,
        feeWalletAddress: feeWalletAddress,
      );

      // Create escrow lock transaction
      final lockTransaction = {
        'tradeId': tradeId,
        'operation': 'ESCROW_LOCK',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'blockchain': 'POLYGON',
        'token': 'USDC',
        'tokenDecimals': 6,
        'sender': sellerAddress,
        'escrowContract':
            '0xESCROW_CONTRACT_ADDRESS', // Replace with actual contract
        'lockAmount': escrowParams['sellerLockAmountWei'],
        'lockAmountFormatted': _formatFromWei(
          escrowParams['sellerLockAmountWei'],
        ),
        'grossTradeAmount': escrowParams['grossTradeAmountWei'],
        'grossTradeAmountFormatted': _formatFromWei(
          escrowParams['grossTradeAmountWei'],
        ),
        'parties': {
          'buyer': buyerAddress,
          'seller': sellerAddress,
          'agent': agentAddress,
          'feeWallet': feeWalletAddress,
        },
        'feeBreakdown': {
          'buyerReceiveAmount': escrowParams['buyerReceiveAmountWei'],
          'buyerReceiveAmountFormatted': _formatFromWei(
            escrowParams['buyerReceiveAmountWei'],
          ),
          'platformFeeAmount': escrowParams['platformFeeAmountWei'],
          'platformFeeAmountFormatted': _formatFromWei(
            escrowParams['platformFeeAmountWei'],
          ),
        },
        'settlementRules': escrowParams['settlement'],
        'status': 'PENDING',
        'transactionHash': null, // Set after blockchain confirmation
      };

      // Log transaction for debugging
      if (kDebugMode) {
        print('🔒 Creating Escrow Lock Transaction:');
        print('Trade ID: $tradeId');
        print(
          'Gross Amount: ${lockTransaction['grossTradeAmountFormatted']} USDC',
        );
        print('Lock Amount: ${lockTransaction['lockAmountFormatted']} USDC');
        print('Seller: $sellerAddress');
        print('Buyer: $buyerAddress');
      }

      return {
        'success': true,
        'transaction': lockTransaction,
        'message':
            'Escrow lock created successfully. Seller must lock ${lockTransaction['lockAmountFormatted']} USDC',
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
        'message': 'Failed to create escrow lock: ${e.toString()}',
      };
    }
  }

  /// Execute successful trade release (OTP verified)
  /// On release: Buyer gets NetToBuyer (0.99*G), Platform gets PlatformFeeTotal (0.02*G)
  Future<Map<String, dynamic>> executeTradeRelease({
    required String tradeId,
    required String otpCode,
    required double grossTradeAmount,
    required String buyerAddress,
    required String sellerAddress,
  }) async {
    try {
      // Validate OTP (implement actual OTP validation)
      if (!_validateOTP(otpCode)) {
        throw Exception('Invalid OTP code');
      }

      // Get fee wallet address
      final feeWalletAddress = await _feeLogic.getFeeWalletAddress();
      if (feeWalletAddress == null) {
        throw Exception('Platform fee wallet not configured');
      }

      // Calculate release amounts
      final escrowParams = _feeLogic.generateEscrowSettlementParams(
        grossTradeAmount: grossTradeAmount,
        buyerAddress: buyerAddress,
        sellerAddress: sellerAddress,
        feeWalletAddress: feeWalletAddress,
      );

      // Create release transactions
      final releaseTransactions = [
        // Transfer to buyer (99% of gross amount)
        {
          'operation': 'ESCROW_RELEASE_TO_BUYER',
          'recipient': buyerAddress,
          'amount': escrowParams['buyerReceiveAmountWei'],
          'amountFormatted': _formatFromWei(
            escrowParams['buyerReceiveAmountWei'],
          ),
          'description': 'Trade settlement payment to buyer',
        },
        // Transfer to platform (2% total fees)
        {
          'operation': 'ESCROW_RELEASE_TO_PLATFORM',
          'recipient': feeWalletAddress,
          'amount': escrowParams['platformFeeAmountWei'],
          'amountFormatted': _formatFromWei(
            escrowParams['platformFeeAmountWei'],
          ),
          'description':
              'Platform fees collection (1% from buyer + 1% from seller)',
        },
      ];

      final releaseResult = {
        'tradeId': tradeId,
        'operation': 'TRADE_RELEASE',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'otpCode': otpCode,
        'grossTradeAmount': grossTradeAmount,
        'transactions': releaseTransactions,
        'summary': {
          'buyerReceived': _formatFromWei(
            escrowParams['buyerReceiveAmountWei'],
          ),
          'platformCollected': _formatFromWei(
            escrowParams['platformFeeAmountWei'],
          ),
          'totalReleased': _formatFromWei(
            escrowParams['buyerReceiveAmountWei'] +
                escrowParams['platformFeeAmountWei'],
          ),
        },
        'status': 'COMPLETED',
      };

      // Log successful release
      if (kDebugMode) {
        print('✅ Trade Release Executed:');
        print('Trade ID: $tradeId');
        print(
          'Buyer received: ${(releaseResult['summary'] as Map<String, dynamic>)['buyerReceived']} USDC',
        );
        print(
          'Platform collected: ${(releaseResult['summary'] as Map<String, dynamic>)['platformCollected']} USDC',
        );
      }

      return {
        'success': true,
        'release': releaseResult,
        'message':
            'Trade completed successfully. Funds released to buyer and platform fees collected.',
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
        'message': 'Failed to execute trade release: ${e.toString()}',
      };
    }
  }

  /// Execute trade refund (before OTP release)
  /// On refund: Seller gets full locked amount back (1.01*G), no fees deducted
  Future<Map<String, dynamic>> executeTradeRefund({
    required String tradeId,
    required double grossTradeAmount,
    required String sellerAddress,
    required String reason,
  }) async {
    try {
      // Calculate refund amount (full locked amount)
      final fees = _feeLogic.calculateTradeFees(
        grossTradeAmount: grossTradeAmount,
      );
      final refundAmount = fees['requiredLockFromSeller'];

      final refundTransaction = {
        'tradeId': tradeId,
        'operation': 'TRADE_REFUND',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
        'reason': reason,
        'recipient': sellerAddress,
        'refundAmount': (refundAmount * 1000000).round(),
        'refundAmountFormatted': refundAmount.toStringAsFixed(6),
        'originalGrossAmount': grossTradeAmount,
        'feesRefunded': true,
        'description': 'Full refund to seller - no fees deducted',
        'status': 'COMPLETED',
      };

      // Log refund
      if (kDebugMode) {
        print('🔄 Trade Refund Executed:');
        print('Trade ID: $tradeId');
        print(
          'Refund Amount: ${refundTransaction['refundAmountFormatted']} USDC',
        );
        print('Seller: $sellerAddress');
        print('Reason: $reason');
      }

      return {
        'success': true,
        'refund': refundTransaction,
        'message':
            'Trade refunded successfully. Full locked amount returned to seller.',
      };
    } catch (e) {
      return {
        'success': false,
        'error': e.toString(),
        'message': 'Failed to execute trade refund: ${e.toString()}',
      };
    }
  }

  /// Get escrow status for a trade
  Future<Map<String, dynamic>> getEscrowStatus(String tradeId) async {
    // Mock implementation - replace with actual blockchain queries
    return {
      'tradeId': tradeId,
      'status': 'LOCKED', // PENDING, LOCKED, RELEASED, REFUNDED
      'lockTimestamp':
          DateTime.now()
              .subtract(const Duration(hours: 1))
              .millisecondsSinceEpoch,
      'expirationTimestamp':
          DateTime.now().add(const Duration(hours: 23)).millisecondsSinceEpoch,
      'canRelease': true,
      'canRefund': true,
    };
  }

  /// Estimate gas fees for escrow operations on Polygon
  Future<Map<String, dynamic>> estimateGasFees({
    required String operation, // 'lock', 'release', 'refund'
    required double grossTradeAmount,
  }) async {
    // Mock gas estimation - replace with actual Polygon gas price API
    final baseGasUnits = {
      'lock': 150000,
      'release': 200000, // Higher due to multiple transfers
      'refund': 100000,
    };

    final gasUnits = baseGasUnits[operation] ?? 150000;
    const gasPrice = 30.0; // Gwei
    const maticPrice = 0.45; // USD

    final gasFeeMatic = (gasUnits * gasPrice) / 1e9;
    final gasFeeUSD = gasFeeMatic * maticPrice;

    return {
      'operation': operation,
      'gasUnits': gasUnits,
      'gasPrice': gasPrice,
      'gasFeeMatic': gasFeeMatic.toStringAsFixed(8),
      'gasFeeUSD': gasFeeUSD.toStringAsFixed(4),
      'network': 'Polygon',
      'estimated': true,
    };
  }

  /// Private helper methods
  bool _validateOTP(String otpCode) {
    // Mock OTP validation - implement actual validation logic
    return otpCode.length == 6 && int.tryParse(otpCode) != null;
  }

  double _formatFromWei(int amountWei) {
    return amountWei / 1000000; // Convert from 6-decimal integer
  }
}