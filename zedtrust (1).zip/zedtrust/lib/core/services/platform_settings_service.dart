import 'package:supabase_flutter/supabase_flutter.dart';
import './supabase_service.dart';
import './trade_fee_logic_service.dart';

class PlatformSettingsService {
  static final PlatformSettingsService _instance =
      PlatformSettingsService._internal();
  static PlatformSettingsService get instance => _instance;
  PlatformSettingsService._internal();

  SupabaseClient get _client => SupabaseService.instance.client;

  /// Get platform fee wallet address
  Future<String?> getPlatformFeesWalletAddress() async {
    try {
      final response = await _client.rpc(
        'get_platform_setting',
        params: {'key_name': 'platform_fees_wallet_address'},
      );

      return response as String?;
    } catch (e) {
      print('Error fetching platform fees wallet address: $e');
      return null;
    }
  }

  /// Get platform fee percentage
  Future<double> getPlatformFeePercentage() async {
    try {
      final response = await _client.rpc(
        'get_platform_setting',
        params: {'key_name': 'platform_fee_percentage'},
      );

      return double.tryParse(response?.toString() ?? '1.0') ?? 1.0;
    } catch (e) {
      print('Error fetching platform fee percentage: $e');
      return 1.0; // Default 1%
    }
  }

  /// Check if platform fees are enabled
  Future<bool> arePlatformFeesEnabled() async {
    try {
      final response = await _client.rpc(
        'get_platform_setting',
        params: {'key_name': 'platform_fees_enabled'},
      );

      return response?.toString().toLowerCase() == 'true';
    } catch (e) {
      print('Error checking platform fees status: $e');
      return true; // Default enabled
    }
  }

  /// Get minimum trade amount for fee application
  Future<double> getMinTradeAmount() async {
    try {
      final response = await _client.rpc(
        'get_platform_setting',
        params: {'key_name': 'min_trade_amount'},
      );

      return double.tryParse(response?.toString() ?? '10.00') ?? 10.00;
    } catch (e) {
      print('Error fetching minimum trade amount: $e');
      return 10.00; // Default $10
    }
  }

  /// Calculate platform fees for a trade amount using TradeFeeLogicService
  Future<Map<String, double>> calculatePlatformFees({
    required double tradeAmount,
    required String userRole, // 'buyer' or 'seller'
  }) async {
    try {
      final feesEnabled = await arePlatformFeesEnabled();
      final minTradeAmount = await getMinTradeAmount();

      if (!feesEnabled || tradeAmount < minTradeAmount) {
        return {'platformFee': 0.0, 'totalAmount': tradeAmount};
      }

      // Use TradeFeeLogicService for precise calculations
      final feeLogic = TradeFeeLogicService.instance;
      final fees = feeLogic.calculateTradeFees(grossTradeAmount: tradeAmount);

      if (userRole.toLowerCase() == 'buyer') {
        return {
          'platformFee': fees['platformFeeBuyer'],
          'totalAmount': tradeAmount + fees['platformFeeBuyer'],
        };
      } else {
        return {
          'platformFee': fees['platformFeeSeller'],
          'totalAmount': fees['netToBuyer'], // What seller actually receives
        };
      }
    } catch (e) {
      print('Error calculating platform fees: $e');
      return {'platformFee': 0.0, 'totalAmount': tradeAmount};
    }
  }

  /// Update platform setting (admin only)
  Future<bool> updatePlatformSetting({
    required String key,
    required String value,
    String? description,
  }) async {
    try {
      final response = await _client.rpc(
        'update_platform_setting',
        params: {
          'key_name': key,
          'new_value': value,
          'setting_description': description,
        },
      );

      return response == true;
    } catch (e) {
      print('Error updating platform setting: $e');
      return false;
    }
  }

  /// Get all platform settings (admin only)
  Future<List<Map<String, dynamic>>> getAllPlatformSettings() async {
    try {
      final response = await _client
          .from('platform_settings')
          .select()
          .eq('is_active', true)
          .order('setting_key');

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error fetching all platform settings: $e');
      return [];
    }
  }

  /// Validate platform fees configuration with TradeFeeLogicService integration
  Future<Map<String, dynamic>> validatePlatformConfiguration() async {
    try {
      final settings = await getAllPlatformSettings();
      final walletAddress = await getPlatformFeesWalletAddress();
      final feesEnabled = await arePlatformFeesEnabled();

      // Use TradeFeeLogicService for comprehensive validation
      final feeLogic = TradeFeeLogicService.instance;
      final testValidation = feeLogic.validateTradeParameters(
        grossTradeAmount: 100.0,
        userRole: 'buyer',
      );

      final isValid =
          walletAddress != null &&
          walletAddress.isNotEmpty &&
          feesEnabled &&
          testValidation['isValid'];

      return {
        'isValid': isValid,
        'walletConfigured': walletAddress != null && walletAddress.isNotEmpty,
        'feesEnabled': feesEnabled,
        'settingsCount': settings.length,
        'tradeFeeLogicValid': testValidation['isValid'],
        'acceptanceCriteria': testValidation['acceptanceCriteria'],
        'errors':
            isValid
                ? []
                : [
                  if (walletAddress == null || walletAddress.isEmpty)
                    'Platform fees wallet address not configured',
                  if (!feesEnabled) 'Platform fees are disabled',
                  if (!testValidation['isValid'])
                    'Trade fee logic validation failed: ${testValidation['errors']}',
                ],
      };
    } catch (e) {
      print('Error validating platform configuration: $e');
      return {
        'isValid': false,
        'walletConfigured': false,
        'feesEnabled': false,
        'settingsCount': 0,
        'tradeFeeLogicValid': false,
        'errors': ['Error validating configuration: ${e.toString()}'],
      };
    }
  }
}
