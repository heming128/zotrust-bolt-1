import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/supabase_service.dart';
import './auth_service.dart';
import './realtime_service.dart';

/// Enhanced Backend API service for comprehensive database operations
class BackendApiService {
  static BackendApiService? _instance;
  static BackendApiService get instance => _instance ??= BackendApiService._();

  BackendApiService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  // MARK: - User Profile Operations

  /// Get user profile by ID
  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final response = await _client.from('user_profiles').select('''
            id,
            email,
            display_name,
            full_name,
            bio,
            avatar_url,
            phone,
            city,
            preferred_language,
            role,
            is_verified,
            is_active,
            kyc_verified,
            created_at,
            updated_at,
            last_seen_at
          ''').eq('id', userId).maybeSingle();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user profile: $e');
      }
      return null;
    }
  }

  /// Search users by name or email
  Future<List<Map<String, dynamic>>> searchUsers({
    required String query,
    int limit = 10,
  }) async {
    try {
      final response = await _client
          .from('user_profiles')
          .select('id, display_name, full_name, email, avatar_url, is_verified')
          .or(
            'display_name.ilike.%$query%,full_name.ilike.%$query%,email.ilike.%$query%',
          )
          .eq('is_active', true)
          .limit(limit);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error searching users: $e');
      }
      return [];
    }
  }

  // MARK: - Agent Operations

  /// Get all verified agents
  Future<List<Map<String, dynamic>>> getVerifiedAgents({String? city}) async {
    try {
      final response = await _client.rpc(
        'get_verified_agents',
        params: {'p_city': city},
      );

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching verified agents: $e');
      }
      return [];
    }
  }

  /// Get agent locations by city
  Future<List<Map<String, dynamic>>> getAgentLocationsByCity({
    required String agentId,
    required String city,
  }) async {
    try {
      final response = await _client.rpc(
        'get_agent_locations_by_city',
        params: {'p_agent_id': agentId, 'p_city': city},
      );

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent locations: $e');
      }
      return [];
    }
  }

  /// Get agent details with locations
  Future<Map<String, dynamic>?> getAgentDetails(String agentId) async {
    try {
      final response = await _client.from('agents').select('''
            id,
            name,
            alias,
            phone,
            email,
            rating,
            total_trades,
            is_verified,
            is_online,
            agent_locations (
              id,
              city,
              area,
              display_alias,
              address_line,
              geo_lat,
              geo_lng,
              is_active
            )
          ''').eq('id', agentId).eq('is_verified', true).maybeSingle();

      return response;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching agent details: $e');
      }
      return null;
    }
  }

  // MARK: - Trade Operations

  /// Create a new trade
  Future<Map<String, dynamic>> createTrade({
    required String sellerId,
    required String buyerCity,
    required String sellerCity,
    String? agentId,
    double? amountUsdc,
    Map<String, dynamic>? metadata,
  }) async {
    try {
      final response = await _client.rpc(
        'create_trade',
        params: {
          'p_seller_id': sellerId,
          'p_buyer_city': buyerCity,
          'p_seller_city': sellerCity,
          'p_agent_id': agentId,
        },
      );

      if (response != null) {
        // Update trade with additional details if provided
        if (amountUsdc != null || metadata != null) {
          final updateData = <String, dynamic>{};
          if (amountUsdc != null) updateData['amount_usdc'] = amountUsdc;
          if (metadata != null) updateData['metadata'] = metadata;

          await _client
              .from('trades')
              .update(updateData)
              .eq('id', response)
              .select()
              .single();
        }

        return {
          'success': true,
          'trade_id': response,
          'message': 'Trade created successfully',
        };
      }

      throw Exception('Failed to create trade');
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating trade: $e');
      }
      return {'success': false, 'message': 'Failed to create trade: $e'};
    }
  }

  /// Get trade details with comprehensive information
  Future<Map<String, dynamic>?> getTradeDetails(String tradeId) async {
    try {
      final response = await _client.rpc(
        'get_trade_details',
        params: {'p_trade_id': tradeId},
      );

      if (response is List && response.isNotEmpty) {
        return Map<String, dynamic>.from(response.first);
      }

      return null;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching trade details: $e');
      }
      return null;
    }
  }

  /// Get user trade history
  Future<List<Map<String, dynamic>>> getUserTrades({
    String? status,
    int limit = 20,
    int offset = 0,
  }) async {
    try {
      // Start with base query
      var query = _client.from('user_trade_history').select();

      // Apply status filter if provided
      if (status != null) {
        query = query.eq('status', status);
      }

      // Apply ordering and pagination
      final response = await query
          .order('created_at', ascending: false)
          .range(offset, offset + limit - 1);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user trades: $e');
      }
      return [];
    }
  }

  /// Update trade status
  Future<Map<String, dynamic>> updateTradeStatus({
    required String tradeId,
    required String status,
    Map<String, dynamic>? additionalData,
  }) async {
    try {
      final updateData = {
        'status': status,
        'updated_at': DateTime.now().toIso8601String(),
        ...?additionalData,
      };

      final response = await _client
          .from('trades')
          .update(updateData)
          .eq('id', tradeId)
          .select()
          .single();

      return {
        'success': true,
        'trade': response,
        'message': 'Trade status updated successfully',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error updating trade status: $e');
      }
      return {'success': false, 'message': 'Failed to update trade status: $e'};
    }
  }

  // MARK: - OTP Operations

  /// Generate OTP for trade
  Future<Map<String, dynamic>> generateTradeOTP(String tradeId) async {
    try {
      final response = await _client.rpc(
        'generate_trade_otp',
        params: {'p_trade_id': tradeId},
      );

      if (response is List && response.isNotEmpty) {
        final otpData = Map<String, dynamic>.from(response.first);
        return {
          'success': true,
          'otp_data': otpData,
          'message': 'OTP generated successfully',
        };
      }

      throw Exception('Failed to generate OTP');
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error generating OTP: $e');
      }
      return {'success': false, 'message': 'Failed to generate OTP: $e'};
    }
  }

  /// Verify trade OTP
  Future<Map<String, dynamic>> verifyTradeOTP({
    required String tradeId,
    required String otpCode,
    required String otpColor,
  }) async {
    try {
      final response = await _client.rpc(
        'verify_trade_otp',
        params: {
          'p_trade_id': tradeId,
          'p_otp_code': otpCode,
          'p_otp_color': otpColor,
        },
      );

      return {
        'success': response == true,
        'verified': response == true,
        'message': response == true
            ? 'OTP verified successfully'
            : 'Invalid or expired OTP',
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error verifying OTP: $e');
      }
      return {
        'success': false,
        'verified': false,
        'message': 'Failed to verify OTP: $e',
      };
    }
  }

  /// Get OTP logs for trade
  Future<List<Map<String, dynamic>>> getTradeOTPLogs(String tradeId) async {
    try {
      final response = await _client.from('otp_logs').select('''
            id,
            otp_code,
            otp_color,
            is_verified,
            verified_at,
            expires_at,
            created_at
          ''').eq('trade_id', tradeId).order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching OTP logs: $e');
      }
      return [];
    }
  }

  // MARK: - Real-time Operations

  /// Subscribe to trade updates
  RealtimeChannel subscribeToTradeUpdates({
    String? tradeId,
    Function(Map<String, dynamic>)? onInsert,
    Function(Map<String, dynamic>)? onUpdate,
    Function(Map<String, dynamic>)? onDelete,
  }) {
    return RealtimeService.instance.subscribeToTable(
      tableName: 'trades',
      filter: tradeId != null ? 'id=eq.$tradeId' : null,
      onInsert: onInsert,
      onUpdate: onUpdate,
      onDelete: onDelete,
    );
  }

  /// Subscribe to OTP updates for a trade
  RealtimeChannel subscribeToOTPUpdates({
    required String tradeId,
    Function(Map<String, dynamic>)? onInsert,
    Function(Map<String, dynamic>)? onUpdate,
  }) {
    return RealtimeService.instance.subscribeToTable(
      tableName: 'otp_logs',
      filter: 'trade_id=eq.$tradeId',
      onInsert: onInsert,
      onUpdate: onUpdate,
    );
  }

  /// Subscribe to agent status updates
  RealtimeChannel subscribeToAgentUpdates({
    String? agentId,
    Function(Map<String, dynamic>)? onUpdate,
  }) {
    return RealtimeService.instance.subscribeToTable(
      tableName: 'agents',
      filter: agentId != null ? 'id=eq.$agentId' : null,
      onUpdate: onUpdate,
    );
  }

  // MARK: - Statistics and Analytics

  /// Get user statistics
  Future<Map<String, dynamic>> getUserStatistics([String? userId]) async {
    try {
      final targetUserId = userId ?? AuthService.instance.currentUser?.id;
      if (targetUserId == null) {
        throw Exception('User not authenticated');
      }

      // Get trade statistics
      final tradeStats = await _client
          .from('trades')
          .select('id, status')
          .or('buyer_id.eq.$targetUserId,seller_id.eq.$targetUserId');

      final totalTrades = tradeStats.length;
      final completedTrades =
          tradeStats.where((t) => t['status'] == 'RELEASED').length;
      final activeTrades = tradeStats
          .where(
            (t) => [
              'CREATED',
              'ACCEPTED',
              'IN_PROGRESS',
              'OTP_PENDING',
            ].contains(t['status']),
          )
          .length;

      return {
        'total_trades': totalTrades,
        'completed_trades': completedTrades,
        'active_trades': activeTrades,
        'success_rate':
            totalTrades > 0 ? (completedTrades / totalTrades * 100).round() : 0,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching user statistics: $e');
      }
      return {
        'total_trades': 0,
        'completed_trades': 0,
        'active_trades': 0,
        'success_rate': 0,
      };
    }
  }

  /// Get platform statistics (admin only)
  Future<Map<String, dynamic>?> getPlatformStatistics() async {
    try {
      // Check if user is admin
      final isAdmin = await AuthService.instance.isCurrentUserAdmin();
      if (!isAdmin) {
        throw Exception('Unauthorized: Admin access required');
      }

      // Get various statistics
      final [
        userCount,
        agentCount,
        tradeCount,
        activeTradeCount,
      ] = await Future.wait([
        _client.from('user_profiles').select('id').count(),
        _client.from('agents').select('id').count(),
        _client.from('trades').select('id').count(),
        _client
            .from('trades')
            .select('id')
            .not('status', 'in', '(CANCELLED,RELEASED)')
            .count(),
      ]);

      return {
        'total_users': userCount.count,
        'total_agents': agentCount.count,
        'total_trades': tradeCount.count,
        'active_trades': activeTradeCount.count,
      };
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching platform statistics: $e');
      }
      return null;
    }
  }

  // MARK: - Utility Methods

  /// Check database connection
  Future<bool> checkConnection() async {
    try {
      await _client.from('user_profiles').select('id').limit(1);
      return true;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Database connection failed: $e');
      }
      return false;
    }
  }

  /// Batch operation helper
  Future<List<Map<String, dynamic>>> performBatchOperation(
    String tableName,
    List<Map<String, dynamic>> operations,
  ) async {
    try {
      final results = <Map<String, dynamic>>[];

      for (final operation in operations) {
        final type = operation['type'] as String;
        final data = operation['data'] as Map<String, dynamic>;

        late dynamic result;

        switch (type) {
          case 'insert':
            result =
                await _client.from(tableName).insert(data).select().single();
            break;
          case 'update':
            final id = operation['id'] as String;
            result = await _client
                .from(tableName)
                .update(data)
                .eq('id', id)
                .select()
                .single();
            break;
          case 'delete':
            final id = operation['id'] as String;
            result = await _client
                .from(tableName)
                .delete()
                .eq('id', id)
                .select()
                .single();
            break;
          default:
            throw Exception('Invalid operation type: $type');
        }

        results.add({
          'operation': operation,
          'result': result,
          'success': true,
        });
      }

      return results;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Batch operation failed: $e');
      }
      return [];
    }
  }

  /// Dispose resources
  void dispose() {
    // Cleanup if needed
  }
}
