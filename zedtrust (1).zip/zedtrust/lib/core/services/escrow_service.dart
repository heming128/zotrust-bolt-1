import 'package:flutter/foundation.dart';

import './enhanced_supabase_service.dart';

/// Escrow service for handling escrow operations with Supabase
class EscrowService {
  static EscrowService? _instance;
  static EscrowService get instance => _instance ??= EscrowService._();

  EscrowService._();

  final _supabase = EnhancedSupabaseService.instance;

  /// Create escrow for a trade
  Future<Map<String, dynamic>> createEscrow({
    required String tradeId,
    required double lockedAmount,
    String? smartContractAddress,
    double buyerFee = 0.0,
    double sellerFee = 0.0,
    double platformFeeTotal = 0.0,
  }) async {
    try {
      // Verify trade exists and user has access
      final trade = await _supabase.getTradeDetails(tradeId);
      if (trade == null) {
        throw Exception('Trade not found');
      }

      final currentUser = _supabase.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Only buyer can create escrow
      if (trade['buyer_id'] != currentUser.id) {
        throw Exception('Only the buyer can create escrow');
      }

      // Check if escrow already exists
      final existingEscrow = await _supabase.getEscrowDetails(tradeId);
      if (existingEscrow != null) {
        throw Exception('Escrow already exists for this trade');
      }

      final escrow = await _supabase.createEscrow(
        tradeId: tradeId,
        lockedAmount: lockedAmount,
        smartContractAddress: smartContractAddress,
        buyerFee: buyerFee,
        sellerFee: sellerFee,
        platformFeeTotal: platformFeeTotal,
      );

      if (escrow != null) {
        if (kDebugMode) {
          print('✅ Escrow created successfully: ${escrow['id']}');
        }
        return {'success': true, 'escrow': escrow};
      } else {
        throw Exception('Failed to create escrow');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error creating escrow: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Get escrow details for a trade
  Future<Map<String, dynamic>?> getEscrowDetails(String tradeId) async {
    try {
      final escrow = await _supabase.getEscrowDetails(tradeId);

      if (escrow != null && kDebugMode) {
        print('✅ Escrow details fetched: ${escrow['id']}');
      }

      return escrow;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow details: $e');
      }
      return null;
    }
  }

  /// Release escrow funds
  Future<Map<String, dynamic>> releaseEscrow({
    required String tradeId,
    String? releaseTransactionHash,
  }) async {
    try {
      // Verify trade exists and user has access
      final trade = await _supabase.getTradeDetails(tradeId);
      if (trade == null) {
        throw Exception('Trade not found');
      }

      final currentUser = _supabase.currentUser;
      if (currentUser == null) {
        throw Exception('User not authenticated');
      }

      // Only buyer can release escrow
      if (trade['buyer_id'] != currentUser.id) {
        throw Exception('Only the buyer can release escrow');
      }

      // Get escrow details
      final escrow = await _supabase.getEscrowDetails(tradeId);
      if (escrow == null) {
        throw Exception('Escrow not found for this trade');
      }

      if (escrow['released'] == true) {
        throw Exception('Escrow has already been released');
      }

      final releasedEscrow = await _supabase.releaseEscrow(
        escrowId: escrow['id'],
        releaseTransactionHash: releaseTransactionHash,
      );

      if (releasedEscrow != null) {
        if (kDebugMode) {
          print('✅ Escrow released successfully: ${escrow['id']}');
        }
        return {'success': true, 'escrow': releasedEscrow};
      } else {
        throw Exception('Failed to release escrow');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error releasing escrow: $e');
      }
      return {'success': false, 'error': e.toString()};
    }
  }

  /// Check escrow status
  Future<String> getEscrowStatus(String tradeId) async {
    try {
      final escrow = await _supabase.getEscrowDetails(tradeId);

      if (escrow == null) return 'NOT_CREATED';
      if (escrow['released'] == true) return 'RELEASED';
      if (escrow['locked_at'] != null) return 'LOCKED';

      return 'PENDING';
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error checking escrow status: $e');
      }
      return 'ERROR';
    }
  }

  /// Calculate platform fees
  Map<String, double> calculateFees({
    required double amount,
    double buyerFeePercent = 0.5,
    double sellerFeePercent = 0.5,
  }) {
    final buyerFee = amount * (buyerFeePercent / 100);
    final sellerFee = amount * (sellerFeePercent / 100);
    final totalFee = buyerFee + sellerFee;

    return {
      'buyer_fee': double.parse(buyerFee.toStringAsFixed(2)),
      'seller_fee': double.parse(sellerFee.toStringAsFixed(2)),
      'total_fee': double.parse(totalFee.toStringAsFixed(2)),
      'amount_after_fees': double.parse((amount - totalFee).toStringAsFixed(2)),
    };
  }

  /// Get escrow statistics
  Future<Map<String, dynamic>> getEscrowStatistics() async {
    try {
      final stats = await _supabase.getPlatformStats();
      return stats;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow statistics: $e');
      }
      return {};
    }
  }

  /// Subscribe to escrow updates for real-time notifications
  void subscribeToEscrowUpdates({
    required Function(Map<String, dynamic>) onEscrowUpdated,
  }) {
    _supabase.subscribeToEscrow(
      onUpdate: (escrow) {
        if (kDebugMode) {
          print(
            '📱 Escrow updated: ${escrow['id']} -> Released: ${escrow['released']}',
          );
        }
        onEscrowUpdated(escrow);
      },
    );
  }

  /// Validate escrow creation parameters
  bool validateEscrowParams({
    required double lockedAmount,
    String? smartContractAddress,
  }) {
    if (lockedAmount <= 0) {
      if (kDebugMode) {
        print('❌ Invalid locked amount: $lockedAmount');
      }
      return false;
    }

    if (smartContractAddress != null && smartContractAddress.isEmpty) {
      if (kDebugMode) {
        print('❌ Invalid smart contract address');
      }
      return false;
    }

    return true;
  }

  /// Get escrow transaction history for audit
  Future<List<Map<String, dynamic>>> getEscrowAuditLog(String tradeId) async {
    try {
      final response = await _supabase.client
          .from('escrow_audit_log')
          .select('*')
          .eq('trade_id', tradeId)
          .order('created_at', ascending: false);

      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error fetching escrow audit log: $e');
      }
      return [];
    }
  }
}
