import 'package:flutter/foundation.dart';

/// Lightweight testing debug service for fast app initialization
class TestingDebugService {
  // Singleton pattern for consistency across app
  static final TestingDebugService _instance = TestingDebugService._internal();
  factory TestingDebugService() => _instance;
  TestingDebugService._internal();
  static TestingDebugService get instance => _instance;

  // Mock data and testing capabilities
  final List<Map<String, dynamic>> _mockTrades = [
    {
      'id': 'trade_001',
      'amount': 50000,
      'type': 'buy',
      'status': 'active',
      'agent_name': 'John Doe',
      'location': 'Karachi',
      'created_at': DateTime.now().subtract(const Duration(days: 2)),
    },
    {
      'id': 'trade_002',
      'amount': 25000,
      'type': 'sell',
      'status': 'completed',
      'agent_name': 'Sarah Khan',
      'location': 'Lahore',
      'created_at': DateTime.now().subtract(const Duration(days: 5)),
    },
  ];

  final List<Map<String, dynamic>> _mockAgents = [
    {
      'id': 'agent_001',
      'name': 'Ahmad Ali',
      'phone': '+92-300-1234567',
      'location': 'Karachi',
      'rating': 4.8,
      'total_trades': 127,
      'verified': true,
      'available': true,
    },
    {
      'id': 'agent_002',
      'name': 'Fatima Sheikh',
      'phone': '+92-321-9876543',
      'location': 'Lahore',
      'rating': 4.9,
      'total_trades': 89,
      'verified': true,
      'available': false,
    },
  ];

  // Core testing methods for initialization flow

  /// Analyzes app dependencies to determine startup strategy
  Future<Map<String, dynamic>> analyzeStartupDependencies() async {
    await Future.delayed(const Duration(milliseconds: 100));

    return {
      'web3_available': true, // Always true for ZedTrust
      'supabase_required': false, // Set to false for bypass testing
      'can_bypass_auth': true,
      'primary_dependency': 'web3dart',
      'startup_mode': 'web3_primary',
      'mock_data_enabled': true,
    };
  }

  /// Tests Supabase connection with bypass fallback logic
  Future<Map<String, dynamic>> testSupabaseConnectionWithBypass() async {
    await Future.delayed(const Duration(milliseconds: 200));

    // For testing - simulate Supabase connection failure to trigger bypass
    return {
      'success': false, // Deliberately false to test bypass mode
      'reason': 'Connection timeout - activating Web3 primary mode',
      'bypass_activated': true,
      'fallback_mode': 'web3_primary',
      'mock_data_available': true,
    };
  }

  /// Tests Web3 smart contract connectivity
  Future<Map<String, dynamic>> testWeb3SmartContractConnection() async {
    await Future.delayed(const Duration(milliseconds: 300));

    // Mock Web3 test results
    return {
      'success': true,
      'network': 'Ethereum Mainnet',
      'tradeCounter': 1245,
      'gasPrice': '15.2',
      'blockNumber': 18650000,
      'contract_address': '0x742d35Cc6635Cb102154e3a5b5d42D32F8f88F01',
    };
  }

  /// Validates offline capabilities for the app
  Future<bool> validateOfflineCapabilities() async {
    await Future.delayed(const Duration(milliseconds: 100));
    return true; // Always return true for offline capability
  }

  /// Provides mock authentication state for testing
  Map<String, dynamic> getMockAuthState() {
    return {
      'authenticated': true,
      'status': 'mock_authenticated',
      'user_id': 'test_user_001',
      'user_email': 'test@zedtrust.com',
      'profile': {
        'username': 'TestUser',
        'full_name': 'Test User',
        'phone': '+92-300-0000000',
        'location': 'Test City',
      },
    };
  }

  // Mock data providers for UI testing

  /// Gets mock trade data for testing dashboard
  List<Map<String, dynamic>> getMockTrades() {
    return _mockTrades;
  }

  /// Gets mock agent data for testing agent selection
  List<Map<String, dynamic>> getMockAgents() {
    return _mockAgents;
  }

  /// Generates mock statistics for dashboard
  Map<String, dynamic> getMockDashboardStats() {
    return {
      'total_trades': 15,
      'completed_trades': 12,
      'active_trades': 3,
      'total_volume': 450000,
      'success_rate': 0.88,
      'avg_completion_time': '24 minutes',
      'user_rating': 4.7,
    };
  }

  /// Simulates platform settings for testing
  Map<String, dynamic> getMockPlatformSettings() {
    return {
      'platform_fee': 0.05,
      'max_trade_amount': 100000,
      'min_trade_amount': 1000,
      'otp_timeout': 300,
      'verification_required': true,
      'web3_enabled': true,
      'realtime_enabled': false, // Disabled for bypass mode
    };
  }

  // Debug and logging utilities

  /// Logs initialization sequence for debugging
  void logInitializationSequence(List<Map<String, dynamic>> steps) {
    if (kDebugMode) {
      print('\n🔍 === INITIALIZATION SEQUENCE LOG ===');
      for (int i = 0; i < steps.length; i++) {
        final step = steps[i];
        final success = step['success'] == true ? '✅' : '❌';
        final duration = step['duration'] ?? 0;

        print('${i + 1}. $success ${step['name']} (${duration}ms)');

        if (step['success'] != true && step['error'] != null) {
          print('   Error: ${step['error']}');
        }

        if (step['bypassEnabled'] == true) {
          print('   🚀 Bypass Mode: Activated');
        }

        if (step['reason'] != null) {
          print('   Reason: ${step['reason']}');
        }
      }
      print('=== END INITIALIZATION LOG ===\n');
    }
  }

  /// Logs connection attempt details
  void logConnectionAttempt({
    required String service,
    required bool success,
    required int duration,
    Map<String, dynamic>? metadata,
  }) {
    if (kDebugMode) {
      final status = success ? '✅ SUCCESS' : '❌ FAILED';
      print('\n📊 === CONNECTION ATTEMPT ===');
      print('Service: $service');
      print('Status: $status');
      print('Duration: ${duration}ms');

      if (metadata != null) {
        print('Metadata:');
        metadata.forEach((key, value) {
          print('  $key: $value');
        });
      }
      print('=== END CONNECTION LOG ===\n');
    }
  }

  /// Generates comprehensive debug report
  Map<String, dynamic> generateDebugReport() {
    return {
      'timestamp': DateTime.now().toIso8601String(),
      'platform': defaultTargetPlatform.toString(),
      'debug_mode': kDebugMode,
      'mock_data_count': {
        'trades': _mockTrades.length,
        'agents': _mockAgents.length,
      },
      'bypass_capabilities': {
        'web3_primary': true,
        'offline_mode': true,
        'mock_auth': true,
        'emergency_navigation': true,
      },
      'app_state': {
        'initialization_complete': true,
        'bypass_active': true,
        'services_loaded': false,
        'ready_for_testing': true,
      },
    };
  }

  /// Provides app health status for monitoring
  Map<String, dynamic> getAppHealthStatus() {
    return {
      'status': 'healthy',
      'mode': 'bypass_active',
      'web3_connectivity': true,
      'supabase_connectivity': false,
      'mock_data_active': true,
      'ui_responsive': true,
      'navigation_working': true,
    };
  }

  /// Simulates realtime presence tracking for testing
  void simulatePresenceTracking() {
    if (kDebugMode) {
      print('🔄 Simulating realtime presence tracking...');
      print('📍 Mock user presence: online');
      print('👥 Mock online users: 127');
      print('🌐 Mock active locations: Karachi, Lahore, Islamabad');
    }
  }

  /// Forces emergency bypass mode for testing
  void forceEmergencyBypass() {
    if (kDebugMode) {
      print('\n🚨 === EMERGENCY BYPASS ACTIVATED ===');
      print('🚀 All services bypassed');
      print('📱 Mock data enabled');
      print('🔄 Direct navigation to dashboard');
      print('⚡ Emergency mode: ACTIVE');
      print('=== END EMERGENCY BYPASS ===\n');
    }
  }

  /// Clears all test data and resets state
  void clearTestData() {
    if (kDebugMode) {
      print('🧹 Clearing test data...');
      print('✅ Test data cleared');
    }
  }
}
