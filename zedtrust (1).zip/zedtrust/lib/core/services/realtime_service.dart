import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../services/supabase_service.dart';
import './auth_service.dart';

/// Enhanced Real-time service for comprehensive live updates
class RealtimeService {
  static RealtimeService? _instance;
  static RealtimeService get instance => _instance ??= RealtimeService._();

  RealtimeService._();

  SupabaseClient get _client => SupabaseService.instance.client;

  final Map<String, RealtimeChannel> _channels = {};
  final Map<String, Function> _presenceCallbacks = {};
  bool _isInitialized = false;

  /// Initialize real-time service
  Future<void> initialize() async {
    if (_isInitialized) return;

    try {
      // Initialize presence tracking for authenticated users
      if (AuthService.instance.isAuthenticated) {
        await initializePresenceTracking();
      }

      // Listen to auth state changes
      AuthService.instance.authStateChanges.listen((event) {
        if (event.event == AuthChangeEvent.signedIn) {
          initializePresenceTracking();
        } else if (event.event == AuthChangeEvent.signedOut) {
          setUserOffline();
          stopAllListeners();
        }
      });

      _isInitialized = true;

      if (kDebugMode) {
        print('✅ RealtimeService initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ RealtimeService initialization failed: $e');
      }
    }
  }

  /// Subscribe to table changes with comprehensive options
  RealtimeChannel subscribeToTable({
    required String tableName,
    String? filter,
    Function(Map<String, dynamic>)? onInsert,
    Function(Map<String, dynamic>)? onUpdate,
    Function(Map<String, dynamic>)? onDelete,
    String? schema = 'public',
  }) {
    final channelName = '${schema}_${tableName}_${filter ?? 'all'}';

    // Remove existing channel if exists
    if (_channels.containsKey(channelName)) {
      _channels[channelName]?.unsubscribe();
      _channels.remove(channelName);
    }

    // Create new channel
    final channel = _client.channel(channelName);

    // Configure postgres changes listener
    channel.onPostgresChanges(
      event: PostgresChangeEvent.all,
      schema: schema,
      table: tableName,
      filter: filter != null ? PostgresChangeFilter(
        type: PostgresChangeFilterType.eq,
        column: filter.split('=')[0],
        value: filter.split('=')[1].replaceFirst('eq.', ''),
      ) : null,
      callback: (payload) {
        try {
          final eventType = payload.eventType;
          final record = payload.newRecord;
          final oldRecord = payload.oldRecord;

          if (kDebugMode) {
            print('🔄 Real-time event: $eventType on $tableName');
            print('📄 New record: $record');
          }

          switch (eventType) {
            case PostgresChangeEvent.insert:
              onInsert?.call(record);
              break;
            case PostgresChangeEvent.update:
              onUpdate?.call({...record, 'old_record': oldRecord});
              break;
            case PostgresChangeEvent.delete:
              onDelete?.call(oldRecord);
              break;
            default:
              break;
          }
        } catch (e) {
          if (kDebugMode) {
            print('❌ Error processing real-time event: $e');
          }
        }
      },
    );

    // Subscribe to channel
    channel.subscribe((status, error) {
      if (kDebugMode) {
        if (status == RealtimeSubscribeStatus.subscribed) {
          print('✅ Subscribed to $channelName');
        } else if (error != null) {
          print('❌ Subscription error for $channelName: $error');
        }
      }
    });

    _channels[channelName] = channel;
    return channel;
  }

  /// Subscribe to specific record changes
  RealtimeChannel subscribeToRecord({
    required String tableName,
    required String recordId,
    Function(Map<String, dynamic>)? onUpdate,
    Function(Map<String, dynamic>)? onDelete,
    String? schema = 'public',
  }) {
    return subscribeToTable(
      tableName: tableName,
      filter: 'id=eq.$recordId',
      onUpdate: onUpdate,
      onDelete: onDelete,
      schema: schema,
    );
  }

  /// Subscribe to user-specific changes
  RealtimeChannel subscribeToUserData({
    required String tableName,
    required String userIdColumn,
    Function(Map<String, dynamic>)? onInsert,
    Function(Map<String, dynamic>)? onUpdate,
    Function(Map<String, dynamic>)? onDelete,
    String? schema = 'public',
  }) {
    final userId = AuthService.instance.currentUser?.id;
    if (userId == null) {
      throw Exception('User not authenticated');
    }

    return subscribeToTable(
      tableName: tableName,
      filter: '$userIdColumn=eq.$userId',
      onInsert: onInsert,
      onUpdate: onUpdate,
      onDelete: onDelete,
      schema: schema,
    );
  }

  /// Initialize presence tracking for user online status
  Future<void> initializePresenceTracking() async {
    try {
      final user = AuthService.instance.currentUser;
      if (user == null) return;

      const channelName = 'user_presence';

      // Remove existing presence channel
      if (_channels.containsKey(channelName)) {
        await _channels[channelName]?.unsubscribe();
        _channels.remove(channelName);
      }

      // Create presence channel
      final channel = _client.channel(channelName);

      // Track user presence
      await channel
          .onPresenceSync((payload) {
            if (kDebugMode) {
              print('🟢 Presence sync: users online');
            }
          })
          .onPresenceJoin((payload) {
            if (kDebugMode) {
              print('🟢 User joined: ${payload.newPresences}');
            }
          })
          .onPresenceLeave((payload) {
            if (kDebugMode) {
              print('🔴 User left: ${payload.leftPresences}');
            }
          })
          .subscribe((status, error) async {
            if (status == RealtimeSubscribeStatus.subscribed) {
              // Track current user presence
              await channel.track({
                'user_id': user.id,
                'email': user.email,
                'online_at': DateTime.now().toIso8601String(),
                'device_info': _getDeviceInfo(),
              });

              // Update last seen in database
              await AuthService.instance.updateLastSeen();

              if (kDebugMode) {
                print(
                  '✅ Presence tracking initialized for user: ${user.email}',
                );
              }
            } else if (error != null) {
              if (kDebugMode) {
                print('❌ Presence tracking error: $error');
              }
            }
          });

      _channels[channelName] = channel;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error initializing presence tracking: $e');
      }
    }
  }

  /// Set user as offline
  Future<void> setUserOffline() async {
    try {
      const channelName = 'user_presence';

      if (_channels.containsKey(channelName)) {
        await _channels[channelName]?.untrack();
        await _channels[channelName]?.unsubscribe();
        _channels.remove(channelName);
      }

      // Update last seen in database
      await AuthService.instance.updateLastSeen();

      if (kDebugMode) {
        print('🔴 User set to offline');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error setting user offline: $e');
      }
    }
  }

  /// Subscribe to trade real-time updates
  RealtimeChannel subscribeToTrades({
    String? tradeId,
    Function(Map<String, dynamic>)? onTradeCreated,
    Function(Map<String, dynamic>)? onTradeUpdated,
    Function(Map<String, dynamic>)? onTradeCompleted,
  }) {
    return subscribeToTable(
      tableName: 'trades',
      filter: tradeId != null ? 'id=eq.$tradeId' : null,
      onInsert: (data) {
        onTradeCreated?.call(data);
        _showTradeNotification('New trade created', data);
      },
      onUpdate: (data) {
        onTradeUpdated?.call(data);

        final status = data['status'] as String?;
        if (status == 'RELEASED') {
          onTradeCompleted?.call(data);
          _showTradeNotification('Trade completed', data);
        } else {
          _showTradeNotification('Trade updated', data);
        }
      },
    );
  }

  /// Subscribe to OTP updates for a trade
  RealtimeChannel subscribeToTradeOTP({
    required String tradeId,
    Function(Map<String, dynamic>)? onOTPGenerated,
    Function(Map<String, dynamic>)? onOTPVerified,
  }) {
    return subscribeToTable(
      tableName: 'otp_logs',
      filter: 'trade_id=eq.$tradeId',
      onInsert: (data) {
        onOTPGenerated?.call(data);
        _showTradeNotification('OTP generated', data);
      },
      onUpdate: (data) {
        if (data['is_verified'] == true) {
          onOTPVerified?.call(data);
          _showTradeNotification('OTP verified', data);
        }
      },
    );
  }

  /// Subscribe to agent status updates
  RealtimeChannel subscribeToAgents({
    String? agentId,
    Function(Map<String, dynamic>)? onAgentOnline,
    Function(Map<String, dynamic>)? onAgentOffline,
    Function(Map<String, dynamic>)? onAgentUpdated,
  }) {
    return subscribeToTable(
      tableName: 'agents',
      filter: agentId != null ? 'id=eq.$agentId' : null,
      onUpdate: (data) {
        onAgentUpdated?.call(data);

        final isOnline = data['is_online'] as bool?;
        final oldRecord = data['old_record'] as Map<String, dynamic>?;
        final wasOnline = oldRecord?['is_online'] as bool?;

        if (isOnline == true && wasOnline == false) {
          onAgentOnline?.call(data);
        } else if (isOnline == false && wasOnline == true) {
          onAgentOffline?.call(data);
        }
      },
    );
  }

  /// Get online users count
  Future<int> getOnlineUsersCount() async {
    try {
      const channelName = 'user_presence';
      final channel = _channels[channelName];

      if (channel != null) {
        final presenceState = channel.presenceState();
        return presenceState.length;
      }

      return 0;
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting online users count: $e');
      }
      return 0;
    }
  }

  /// Get online users list
  List<Map<String, dynamic>> getOnlineUsers() {
    try {
      const channelName = 'user_presence';
      final channel = _channels[channelName];

      if (channel != null) {
        final presenceState = channel.presenceState();
        return presenceState
            .expand((state) => state.presences)
            .map((presence) => Map<String, dynamic>.from(presence.payload))
            .toList();
      }

      return [];
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error getting online users: $e');
      }
      return [];
    }
  }

  /// Stop all real-time listeners
  Future<void> stopAllListeners() async {
    try {
      for (final channel in _channels.values) {
        await channel.unsubscribe();
      }
      _channels.clear();

      if (kDebugMode) {
        print('🔴 All real-time listeners stopped');
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error stopping listeners: $e');
      }
    }
  }

  /// Stop specific listener
  Future<void> stopListener(String channelName) async {
    try {
      if (_channels.containsKey(channelName)) {
        await _channels[channelName]?.unsubscribe();
        _channels.remove(channelName);

        if (kDebugMode) {
          print('🔴 Stopped listener: $channelName');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('❌ Error stopping listener $channelName: $e');
      }
    }
  }

  /// Check if channel is subscribed
  bool isChannelSubscribed(String channelName) {
    return _channels.containsKey(channelName);
  }

  /// Get active channels count
  int get activeChannelsCount => _channels.length;

  /// Get active channel names
  List<String> get activeChannelNames => _channels.keys.toList();

  /// Private helper methods

  Map<String, dynamic> _getDeviceInfo() {
    return {
      'platform': defaultTargetPlatform.name,
      'is_web': kIsWeb,
      'timestamp': DateTime.now().toIso8601String(),
    };
  }

  void _showTradeNotification(String title, Map<String, dynamic> data) {
    if (kDebugMode) {
      print('🔔 Notification: $title - ${data['id']}');
    }
    // Add actual notification logic here if needed
    // Could integrate with flutter_local_notifications or similar
  }

  /// Dispose resources
  void dispose() {
    stopAllListeners();
    _presenceCallbacks.clear();
    _isInitialized = false;
  }
}