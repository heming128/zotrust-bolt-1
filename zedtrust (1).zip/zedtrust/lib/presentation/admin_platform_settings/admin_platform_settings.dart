import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/services/supabase_service.dart';

class AdminPlatformSettings extends StatefulWidget {
  const AdminPlatformSettings({Key? key}) : super(key: key);

  @override
  State<AdminPlatformSettings> createState() => _AdminPlatformSettingsState();
}

class _AdminPlatformSettingsState extends State<AdminPlatformSettings> {
  bool _isLoading = false;
  bool _isSaving = false;

  // Form controllers
  final _walletAddressController = TextEditingController();
  final _feePercentageController = TextEditingController();
  final _minTradeAmountController = TextEditingController();
  final _maxDailyCollectionController = TextEditingController();

  bool _platformFeesEnabled = true;

  // Form key for validation
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _loadPlatformSettings();
  }

  @override
  void dispose() {
    _walletAddressController.dispose();
    _feePercentageController.dispose();
    _minTradeAmountController.dispose();
    _maxDailyCollectionController.dispose();
    super.dispose();
  }

  Future<void> _loadPlatformSettings() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final settings = await SupabaseService.instance.client
          .from('platform_settings')
          .select()
          .eq('is_active', true);

      if (settings.isNotEmpty) {
        for (var setting in settings) {
          switch (setting['setting_key']) {
            case 'platform_fees_wallet_address':
              _walletAddressController.text = setting['setting_value'] ?? '';
              break;
            case 'platform_fee_percentage':
              _feePercentageController.text = setting['setting_value'] ?? '1.0';
              break;
            case 'platform_fees_enabled':
              _platformFeesEnabled = setting['setting_value'] == 'true';
              break;
            case 'min_trade_amount':
              _minTradeAmountController.text =
                  setting['setting_value'] ?? '10.00';
              break;
            case 'max_daily_fee_collection':
              _maxDailyCollectionController.text =
                  setting['setting_value'] ?? '10000.00';
              break;
          }
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error loading settings: ${e.toString()}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _savePlatformSettings() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isSaving = true;
    });

    try {
      // Prepare settings to update
      final settingsUpdates = [
        {
          'key': 'platform_fees_wallet_address',
          'value': _walletAddressController.text.trim(),
          'description':
              'Wallet address where 1% platform fees from both buyers and sellers are collected'
        },
        {
          'key': 'platform_fee_percentage',
          'value': _feePercentageController.text.trim(),
          'description': 'Platform fee percentage'
        },
        {
          'key': 'platform_fees_enabled',
          'value': _platformFeesEnabled.toString(),
          'description': 'Enable or disable platform fee collection'
        },
        {
          'key': 'min_trade_amount',
          'value': _minTradeAmountController.text.trim(),
          'description': 'Minimum trade amount to apply platform fees'
        },
        {
          'key': 'max_daily_fee_collection',
          'value': _maxDailyCollectionController.text.trim(),
          'description': 'Maximum daily fee collection limit'
        },
      ];

      // Update each setting using the database function
      for (var setting in settingsUpdates) {
        await SupabaseService.instance.client.rpc(
          'update_platform_setting',
          params: {
            'key_name': setting['key'],
            'new_value': setting['value'],
            'setting_description': setting['description'],
          },
        );
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Platform settings saved successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error saving settings: ${e.toString()}'),
            backgroundColor: Colors.red[700],
          ),
        );
      }
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  String? _validateWalletAddress(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Wallet address is required';
    }

    // Basic wallet address validation (can be enhanced based on specific blockchain)
    if (value.trim().length < 20) {
      return 'Please enter a valid wallet address';
    }

    return null;
  }

  String? _validatePercentage(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Fee percentage is required';
    }

    final percentage = double.tryParse(value.trim());
    if (percentage == null) {
      return 'Please enter a valid number';
    }

    if (percentage < 0 || percentage > 10) {
      return 'Fee percentage must be between 0% and 10%';
    }

    return null;
  }

  String? _validateAmount(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }

    final amount = double.tryParse(value.trim());
    if (amount == null) {
      return 'Please enter a valid amount';
    }

    if (amount < 0) {
      return '$fieldName must be positive';
    }

    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: _buildAppBar(),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF3B82F6),
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildHeaderSection(),
                    const SizedBox(height: 32),
                    _buildPlatformFeesCard(),
                    const SizedBox(height: 24),
                    _buildLimitsConfigCard(),
                    const SizedBox(height: 24),
                    _buildInfoCard(),
                    const SizedBox(height: 32),
                    _buildActionButtons(),
                  ],
                ),
              ),
            ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF1E293B),
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: const Icon(Icons.arrow_back, color: Colors.white),
      ),
      title: Text(
        'Platform Settings',
        style: GoogleFonts.inter(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Colors.white,
        ),
      ),
      actions: [
        IconButton(
          onPressed: _loadPlatformSettings,
          icon: const Icon(Icons.refresh, color: Colors.white),
          tooltip: 'Refresh Settings',
        ),
      ],
    );
  }

  Widget _buildHeaderSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF3B82F6), Color(0xFF1E40AF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Platform Fee Configuration',
                  style: GoogleFonts.inter(
                    fontSize: 24,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Configure wallet address and settings for 1% platform fees collection from both buyers and sellers',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    color: Colors.blue[50],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(51),
              borderRadius: BorderRadius.circular(40),
            ),
            child: const Icon(
              Icons.account_balance_wallet,
              color: Colors.white,
              size: 40,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlatformFeesCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.account_balance_wallet,
                color: Color(0xFF3B82F6),
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Platform Fees Configuration',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Enable/Disable Platform Fees
          Row(
            children: [
              Switch(
                value: _platformFeesEnabled,
                onChanged: (value) {
                  setState(() {
                    _platformFeesEnabled = value;
                  });
                },
                activeColor: const Color(0xFF3B82F6),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Enable Platform Fees',
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Turn on to collect fees from all transactions',
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        color: Colors.grey[400],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Wallet Address Input
          Text(
            'Platform Fees Wallet Address*',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _walletAddressController,
            validator: _validateWalletAddress,
            style: GoogleFonts.inter(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Enter wallet address where fees will be collected',
              hintStyle: GoogleFonts.inter(color: Colors.grey[400]),
              filled: true,
              fillColor: const Color(0xFF0F172A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF3B82F6)),
              ),
              suffixIcon: IconButton(
                icon: const Icon(Icons.content_copy, color: Colors.grey),
                onPressed: () async {
                  final data = await Clipboard.getData(Clipboard.kTextPlain);
                  if (data?.text != null) {
                    _walletAddressController.text = data!.text!;
                  }
                },
                tooltip: 'Paste from clipboard',
              ),
            ),
          ),

          const SizedBox(height: 24),

          // Fee Percentage
          Text(
            'Platform Fee Percentage*',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          TextFormField(
            controller: _feePercentageController,
            validator: _validatePercentage,
            keyboardType: TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
            ],
            style: GoogleFonts.inter(color: Colors.white),
            decoration: InputDecoration(
              hintText: '1.0',
              hintStyle: GoogleFonts.inter(color: Colors.grey[400]),
              filled: true,
              fillColor: const Color(0xFF0F172A),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF334155)),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: const BorderSide(color: Color(0xFF3B82F6)),
              ),
              suffixText: '%',
              suffixStyle: GoogleFonts.inter(color: Colors.grey[400]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLimitsConfigCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.tune,
                color: Color(0xFF10B981),
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Fee Collection Limits',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              // Minimum Trade Amount
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Minimum Trade Amount (USD)*',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _minTradeAmountController,
                      validator: (value) =>
                          _validateAmount(value, 'Minimum trade amount'),
                      keyboardType:
                          TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d*')),
                      ],
                      style: GoogleFonts.inter(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: '10.00',
                        hintStyle: GoogleFonts.inter(color: Colors.grey[400]),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF334155)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF334155)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF3B82F6)),
                        ),
                        prefixText: '\$ ',
                        prefixStyle: GoogleFonts.inter(color: Colors.grey[400]),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 16),

              // Maximum Daily Collection
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Max Daily Collection (USD)*',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextFormField(
                      controller: _maxDailyCollectionController,
                      validator: (value) =>
                          _validateAmount(value, 'Maximum daily collection'),
                      keyboardType:
                          TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(
                            RegExp(r'^\d*\.?\d*')),
                      ],
                      style: GoogleFonts.inter(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: '10000.00',
                        hintStyle: GoogleFonts.inter(color: Colors.grey[400]),
                        filled: true,
                        fillColor: const Color(0xFF0F172A),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF334155)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF334155)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide:
                              const BorderSide(color: Color(0xFF3B82F6)),
                        ),
                        prefixText: '\$ ',
                        prefixStyle: GoogleFonts.inter(color: Colors.grey[400]),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF334155)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.info_outline,
                color: Color(0xFF3B82F6),
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Platform Fee Information',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF3B82F6),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            '• Platform fees are automatically collected from both buyers and sellers during transactions\n'
            '• Buyers pay: Trade amount + Platform fee\n'
            '• Sellers receive: Trade amount - Platform fee\n'
            '• All fees are transferred to the configured wallet address\n'
            '• Minimum trade amount determines when fees apply\n'
            '• Daily collection limit helps control maximum fee revenue',
            style: GoogleFonts.inter(
              fontSize: 14,
              color: Colors.grey[300],
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed:
                _isLoading || _isSaving ? null : () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              side: const BorderSide(color: Color(0xFF334155)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: Colors.grey[300],
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          flex: 2,
          child: ElevatedButton(
            onPressed: _isLoading || _isSaving ? null : _savePlatformSettings,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3B82F6),
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : Text(
                    'Save Settings',
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),
      ],
    );
  }
}
