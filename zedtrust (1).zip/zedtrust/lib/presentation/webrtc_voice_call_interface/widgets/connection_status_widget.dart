// ... keep existing imports ...
import '../../../services/call_service.dart';

class ConnectionStatusWidget extends StatelessWidget {
  final CallState callState;

  const ConnectionStatusWidget({Key? key, required this.callState})
    : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _getStatusColor().withAlpha(51),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: _getStatusColor(), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: _getStatusColor(),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            _getStatusText(),
            style: TextStyle(
              color: _getStatusColor(),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor() {
    switch (callState) {
      case CallState.calling:
      case CallState.receiving:
      case CallState.connecting:
        return Colors.orange;
      case CallState.connected:
        return Colors.green;
      case CallState.ended:
        return Colors.grey;
      case CallState.failed:
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getStatusText() {
    switch (callState) {
      case CallState.calling:
        return 'Calling...';
      case CallState.receiving:
        return 'Incoming';
      case CallState.connecting:
        return 'Connecting...';
      case CallState.connected:
        return 'Connected';
      case CallState.ended:
        return 'Ended';
      case CallState.failed:
        return 'Failed';
      default:
        return 'Unknown';
    }
  }
}
