import '../../in_app_chat/widgets/voip_call_widget.dart';

// ... keep existing imports ...

class CallControlsWidget extends StatelessWidget {
  final bool isIncomingCall;
  final bool isMuted;
  final bool isSpeakerOn;
  final VoidCallback? onMute;
  final VoidCallback? onSpeaker;
  final VoidCallback? onEndCall;
  final VoidCallback? onAnswerCall;
  final VoidCallback? onDeclineCall;
  final CallState callState;

  const CallControlsWidget({
    Key? key,
    required this.isIncomingCall,
    required this.isMuted,
    required this.isSpeakerOn,
    this.onMute,
    this.onSpeaker,
    this.onEndCall,
    this.onAnswerCall,
    this.onDeclineCall,
    required this.callState,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (isIncomingCall && callState == CallState.receiving) {
      return _buildIncomingCallControls();
    } else {
      return _buildActiveCallControls();
    }
  }

  Widget _buildIncomingCallControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Decline button
        _CallControlButton(
          icon: Icons.call_end,
          color: Colors.red,
          size: 70,
          onTap: onDeclineCall,
        ),

        // Answer button
        _CallControlButton(
          icon: Icons.call,
          color: Colors.green,
          size: 70,
          onTap: onAnswerCall,
        ),
      ],
    );
  }

  Widget _buildActiveCallControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        // Mute button
        _CallControlButton(
          icon: isMuted ? Icons.mic_off : Icons.mic,
          color: isMuted ? Colors.red : Colors.grey[800]!,
          size: 60,
          onTap: onMute,
          isToggled: isMuted,
        ),

        // End call button
        _CallControlButton(
          icon: Icons.call_end,
          color: Colors.red,
          size: 70,
          onTap: onEndCall,
        ),

        // Speaker button
        _CallControlButton(
          icon: isSpeakerOn ? Icons.volume_up : Icons.volume_down,
          color: isSpeakerOn ? Colors.blue : Colors.grey[800]!,
          size: 60,
          onTap: onSpeaker,
          isToggled: isSpeakerOn,
        ),
      ],
    );
  }
}

class _CallControlButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  final VoidCallback? onTap;
  final bool isToggled;

  const _CallControlButton({
    required this.icon,
    required this.color,
    required this.size,
    this.onTap,
    this.isToggled = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow:
              isToggled
                  ? [
                    BoxShadow(
                      color: color.withAlpha(128),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ]
                  : null,
        ),
        child: Icon(icon, color: Colors.white, size: size * 0.4),
      ),
    );
  }
}
