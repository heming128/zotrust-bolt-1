import '../../services/call_service.dart';
import '../web_rtc_voice_call_interface/web_rtc_voice_call_interface.dart';
import './widgets/call_timer_widget.dart';
import './widgets/connection_status_widget.dart';

// ... keep existing imports ...

class WebRtcVoiceCallInterface extends StatefulWidget {
  final String? callId;
  final String? calleeId;
  final String? callerName;
  final String? calleeName;
  final bool isIncoming;

  const WebRtcVoiceCallInterface({
    Key? key,
    this.callId,
    this.calleeId,
    this.callerName,
    this.calleeName,
    this.isIncoming = false,
  }) : super(key: key);

  @override
  State<WebRtcVoiceCallInterface> createState() =>
      _WebRtcVoiceCallInterfaceState();
}

class _WebRtcVoiceCallInterfaceState extends State<WebRtcVoiceCallInterface> {
  final CallService _callService = CallService();
  CallState _callState = CallState.idle;
  bool _isMuted = false;
  bool _isSpeakerOn = false;
  StreamSubscription? _callStateSubscription;
  StreamSubscription? _incomingCallsSubscription;

  @override
  void initState() {
    super.initState();
    _initializeCall();
  }

  Future<void> _initializeCall() async {
    await _callService.initialize();

    _callStateSubscription = _callService.callStateStream.listen((state) {
      setState(() {
        _callState = state;
      });

      if (state == CallState.ended || state == CallState.failed) {
        _handleCallEnd();
      }
    });

    if (widget.isIncoming && widget.callId != null) {
      // Incoming call - show UI immediately
      setState(() {
        _callState = CallState.receiving;
      });
    } else if (widget.calleeId != null) {
      // Outgoing call
      _initiateCall();
    }
  }

  Future<void> _initiateCall() async {
    if (widget.calleeId != null) {
      await _callService.initiateCall(widget.calleeId!, isVideo: false);
    }
  }

  Future<void> _answerCall() async {
    if (widget.callId != null) {
      await _callService.answerCall(widget.callId!, withVideo: false);
    }
  }

  Future<void> _endCall() async {
    await _callService.endCall();
  }

  Future<void> _declineCall() async {
    if (widget.callId != null) {
      await _callService.declineCall(widget.callId!);
      _handleCallEnd();
    }
  }

  void _toggleMute() async {
    await _callService.toggleMute();
    setState(() {
      _isMuted = !_isMuted;
    });
  }

  void _toggleSpeaker() {
    setState(() {
      _isSpeakerOn = !_isSpeakerOn;
    });
    // Implement speaker toggle logic
  }

  void _handleCallEnd() {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        Navigator.of(context).pop();
      }
    });
  }

  String _getCallStatusText() {
    switch (_callState) {
      case CallState.calling:
        return 'Calling...';
      case CallState.receiving:
        return 'Incoming call';
      case CallState.connecting:
        return 'Connecting...';
      case CallState.connected:
        return 'Connected';
      case CallState.ended:
        return 'Call ended';
      case CallState.failed:
        return 'Call failed';
      default:
        return 'Idle';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black87,
      body: SafeArea(
        child: Column(
          children: [
            // Header with call status
            Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    _getCallStatusText(),
                    style: const TextStyle(color: Colors.white70, fontSize: 16),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    widget.isIncoming
                        ? (widget.callerName ?? 'Unknown Caller')
                        : (widget.calleeName ?? 'Unknown'),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),

            // Avatar section
            Expanded(
              flex: 2,
              child: Center(
                child: Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.grey[800],
                    border: Border.all(
                      color:
                          _callState == CallState.connected
                              ? Colors.green
                              : Colors.grey[600]!,
                      width: 3,
                    ),
                  ),
                  child: Icon(Icons.person, size: 80, color: Colors.grey[400]),
                ),
              ),
            ),

            // Call timer (when connected)
            if (_callState == CallState.connected)
              Container(
                margin: const EdgeInsets.only(bottom: 20),
                child: CallTimerWidget(),
              ),

            // Connection status indicator
            Container(
              margin: const EdgeInsets.only(bottom: 30),
              child: ConnectionStatusWidget(callState: _callState),
            ),

            // Call controls
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              child: _buildCallControls(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCallControls() {
    if (_callState == CallState.receiving) {
      // Incoming call controls
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Decline button
          GestureDetector(
            onTap: _declineCall,
            child: Container(
              width: 70,
              height: 70,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red,
              ),
              child: const Icon(Icons.call_end, color: Colors.white, size: 30),
            ),
          ),

          // Answer button
          GestureDetector(
            onTap: _answerCall,
            child: Container(
              width: 70,
              height: 70,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.green,
              ),
              child: const Icon(Icons.call, color: Colors.white, size: 30),
            ),
          ),
        ],
      );
    } else {
      // Active call controls
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Mute button
          GestureDetector(
            onTap: _toggleMute,
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _isMuted ? Colors.red : Colors.grey[800],
              ),
              child: Icon(
                _isMuted ? Icons.mic_off : Icons.mic,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),

          // End call button
          GestureDetector(
            onTap: _endCall,
            child: Container(
              width: 70,
              height: 70,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.red,
              ),
              child: const Icon(Icons.call_end, color: Colors.white, size: 30),
            ),
          ),

          // Speaker button
          GestureDetector(
            onTap: _toggleSpeaker,
            child: Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _isSpeakerOn ? Colors.blue : Colors.grey[800],
              ),
              child: Icon(
                _isSpeakerOn ? Icons.volume_up : Icons.volume_down,
                color: Colors.white,
                size: 24,
              ),
            ),
          ),
        ],
      );
    }
  }

  @override
  void dispose() {
    _callStateSubscription?.cancel();
    _incomingCallsSubscription?.cancel();
    super.dispose();
  }
}
