import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AgentCardWidget extends StatelessWidget {
  final Map<String, dynamic> agent;
  final bool isSelected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  const AgentCardWidget({
    Key? key,
    required this.agent,
    required this.isSelected,
    required this.onTap,
    required this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool isOnline = agent['isOnline'] as bool? ?? false;
    final double rating = (agent['rating'] as num?)?.toDouble() ?? 0.0;
    final int completedTrades = agent['completedTrades'] as int? ?? 0;
    final String distance = agent['distance'] as String? ?? '';
    final String responseTime = agent['responseTime'] as String? ?? '';
    final List<dynamic> specializations =
        agent['specializations'] as List<dynamic>? ?? [];

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
              : AppTheme.lightTheme.cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected
                ? AppTheme.lightTheme.primaryColor
                : AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.lightTheme.colorScheme.shadow,
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Agent Avatar
                Container(
                  width: 12.w,
                  height: 12.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppTheme.lightTheme.colorScheme.primaryContainer,
                  ),
                  child: CustomImageWidget(
                    imageUrl: agent['avatar'] as String? ?? '',
                    width: 12.w,
                    height: 12.w,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(width: 3.w),

                // Agent Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              agent['nickname'] as String? ?? 'Unknown Agent',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (isSelected)
                            CustomIconWidget(
                              iconName: 'check_circle',
                              color: AppTheme.lightTheme.primaryColor,
                              size: 20,
                            ),
                        ],
                      ),
                      SizedBox(height: 0.5.h),
                      Row(
                        children: [
                          // Online Status
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isOnline
                                  ? AppTheme.getSuccessColor(true)
                                  : AppTheme.getNeutralColor(true),
                            ),
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            isOnline ? 'Online' : 'Offline',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              color: isOnline
                                  ? AppTheme.getSuccessColor(true)
                                  : AppTheme
                                      .lightTheme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          if (distance.isNotEmpty) ...[
                            CustomIconWidget(
                              iconName: 'location_on',
                              color: AppTheme
                                  .lightTheme.colorScheme.onSurfaceVariant,
                              size: 14,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              distance,
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 2.h),

            // Rating and Stats
            Row(
              children: [
                // Rating Stars
                Row(
                  children: List.generate(5, (index) {
                    return CustomIconWidget(
                      iconName: index < rating.floor() ? 'star' : 'star_border',
                      color: index < rating.floor()
                          ? AppTheme.getWarningColor(true)
                          : AppTheme.getNeutralColor(true),
                      size: 16,
                    );
                  }),
                ),
                SizedBox(width: 2.w),
                Text(
                  rating.toStringAsFixed(1),
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(width: 4.w),
                Text(
                  '$completedTrades trades',
                  style: AppTheme.lightTheme.textTheme.bodySmall,
                ),
                const Spacer(),
                if (responseTime.isNotEmpty)
                  Text(
                    'Avg: $responseTime',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    ),
                  ),
              ],
            ),

            if (specializations.isNotEmpty) ...[
              SizedBox(height: 1.5.h),
              Wrap(
                spacing: 2.w,
                runSpacing: 1.h,
                children: (specializations).map((spec) {
                  return Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      spec.toString(),
                      style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                        color: AppTheme
                            .lightTheme.colorScheme.onSecondaryContainer,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
