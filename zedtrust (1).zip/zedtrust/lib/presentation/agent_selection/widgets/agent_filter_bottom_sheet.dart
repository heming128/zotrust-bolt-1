import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AgentFilterBottomSheet extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onFiltersChanged;

  const AgentFilterBottomSheet({
    Key? key,
    required this.currentFilters,
    required this.onFiltersChanged,
  }) : super(key: key);

  @override
  State<AgentFilterBottomSheet> createState() => _AgentFilterBottomSheetState();
}

class _AgentFilterBottomSheetState extends State<AgentFilterBottomSheet> {
  late Map<String, dynamic> _filters;
  late double _distanceRadius;
  late double _minimumRating;
  late bool _onlineOnly;
  late Set<String> _selectedPaymentMethods;

  final List<String> _paymentMethods = [
    'Cash Exchange',
    'Bank Transfer',
    'Mobile Money',
    'PayPal',
    'Crypto Exchange',
  ];

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);
    _distanceRadius = (_filters['distanceRadius'] as num?)?.toDouble() ?? 50.0;
    _minimumRating = (_filters['minimumRating'] as num?)?.toDouble() ?? 0.0;
    _onlineOnly = _filters['onlineOnly'] as bool? ?? false;
    _selectedPaymentMethods = Set<String>.from(
        (_filters['paymentMethods'] as List<dynamic>?)?.cast<String>() ?? []);
  }

  void _applyFilters() {
    final updatedFilters = {
      'distanceRadius': _distanceRadius,
      'minimumRating': _minimumRating,
      'onlineOnly': _onlineOnly,
      'paymentMethods': _selectedPaymentMethods.toList(),
    };
    widget.onFiltersChanged(updatedFilters);
    Navigator.pop(context);
  }

  void _resetFilters() {
    setState(() {
      _distanceRadius = 50.0;
      _minimumRating = 0.0;
      _onlineOnly = false;
      _selectedPaymentMethods.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle Bar
          Container(
            margin: EdgeInsets.only(top: 1.h),
            width: 12.w,
            height: 4,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.outline,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Text(
                  'Filter Agents',
                  style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: _resetFilters,
                  child: Text(
                    'Reset',
                    style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightTheme.primaryColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Distance Radius
                  _buildSectionTitle('Distance Radius'),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      Expanded(
                        child: Slider(
                          value: _distanceRadius,
                          min: 1.0,
                          max: 100.0,
                          divisions: 99,
                          label: '${_distanceRadius.round()} km',
                          onChanged: (value) {
                            setState(() {
                              _distanceRadius = value;
                            });
                          },
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Text(
                        '${_distanceRadius.round()} km',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: 3.h),

                  // Minimum Rating
                  _buildSectionTitle('Minimum Rating'),
                  SizedBox(height: 1.h),
                  Row(
                    children: [
                      Expanded(
                        child: Slider(
                          value: _minimumRating,
                          min: 0.0,
                          max: 5.0,
                          divisions: 10,
                          label: _minimumRating == 0.0
                              ? 'Any'
                              : '${_minimumRating.toStringAsFixed(1)} stars',
                          onChanged: (value) {
                            setState(() {
                              _minimumRating = value;
                            });
                          },
                        ),
                      ),
                      SizedBox(width: 2.w),
                      Row(
                        children: [
                          if (_minimumRating > 0.0) ...[
                            CustomIconWidget(
                              iconName: 'star',
                              color: AppTheme.getWarningColor(true),
                              size: 16,
                            ),
                            SizedBox(width: 1.w),
                          ],
                          Text(
                            _minimumRating == 0.0
                                ? 'Any'
                                : _minimumRating.toStringAsFixed(1),
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                              color: AppTheme.lightTheme.colorScheme.onSurface,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  SizedBox(height: 3.h),

                  // Availability Status
                  _buildSectionTitle('Availability'),
                  SizedBox(height: 1.h),
                  SwitchListTile(
                    title: Text(
                      'Online agents only',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    value: _onlineOnly,
                    onChanged: (value) {
                      setState(() {
                        _onlineOnly = value;
                      });
                    },
                    contentPadding: EdgeInsets.zero,
                  ),

                  SizedBox(height: 3.h),

                  // Payment Methods
                  _buildSectionTitle('Payment Methods'),
                  SizedBox(height: 1.h),
                  ..._paymentMethods.map((method) {
                    return CheckboxListTile(
                      title: Text(
                        method,
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      value: _selectedPaymentMethods.contains(method),
                      onChanged: (value) {
                        setState(() {
                          if (value == true) {
                            _selectedPaymentMethods.add(method);
                          } else {
                            _selectedPaymentMethods.remove(method);
                          }
                        });
                      },
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  }).toList(),

                  SizedBox(height: 4.h),
                ],
              ),
            ),
          ),

          // Apply Button
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              border: Border(
                top: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
            ),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _applyFilters,
                child: Text('Apply Filters'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
        fontWeight: FontWeight.w700,
        color: AppTheme.lightTheme.colorScheme.onSurface,
      ),
    );
  }
}
