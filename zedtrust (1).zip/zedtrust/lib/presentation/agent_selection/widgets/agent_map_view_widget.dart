import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class AgentMapViewWidget extends StatefulWidget {
  final List<Map<String, dynamic>> agents;
  final String? selectedAgentId;
  final Function(String) onAgentSelected;
  final Function(Map<String, dynamic>) onAgentProfileTap;

  const AgentMapViewWidget({
    Key? key,
    required this.agents,
    this.selectedAgentId,
    required this.onAgentSelected,
    required this.onAgentProfileTap,
  }) : super(key: key);

  @override
  State<AgentMapViewWidget> createState() => _AgentMapViewWidgetState();
}

class _AgentMapViewWidgetState extends State<AgentMapViewWidget> {
  GoogleMapController? _mapController;
  Position? _currentPosition;
  Set<Marker> _markers = {};
  bool _isLoadingLocation = false;

  // Default center location (India - New Delhi)
  static const LatLng _defaultCenter = LatLng(28.6139, 77.2090);

  // Indian cities with coordinates
  final Map<String, LatLng> _indianCities = {
    'Mumbai': LatLng(19.0760, 72.8777),
    'Delhi': LatLng(28.6139, 77.2090),
    'Bangalore': LatLng(12.9716, 77.5946),
    'Hyderabad': LatLng(17.3850, 78.4867),
    'Chennai': LatLng(13.0827, 80.2707),
    'Kolkata': LatLng(22.5726, 88.3639),
    'Pune': LatLng(18.5204, 73.8567),
    'Ahmedabad': LatLng(23.0225, 72.5714),
    'Jaipur': LatLng(26.9124, 75.7873),
    'Surat': LatLng(21.1702, 72.8311),
    'Lucknow': LatLng(26.8467, 80.9462),
    'Kanpur': LatLng(26.4499, 80.3319),
    'Nagpur': LatLng(21.1458, 79.0882),
    'Indore': LatLng(22.7196, 75.8577),
    'Thane': LatLng(19.2183, 72.9781),
    'Bhopal': LatLng(23.2599, 77.4126),
    'Visakhapatnam': LatLng(17.6868, 83.2185),
    'Pimpri-Chinchwad': LatLng(18.6298, 73.7997),
    'Patna': LatLng(25.5941, 85.1376),
    'Vadodara': LatLng(22.3072, 73.1812),
    'Ghaziabad': LatLng(28.6692, 77.4538),
    'Ludhiana': LatLng(30.9010, 75.8573),
    'Agra': LatLng(27.1767, 78.0081),
    'Nashik': LatLng(19.9975, 73.7898),
    'Faridabad': LatLng(28.4089, 77.3178),
    'Meerut': LatLng(28.9845, 77.7064),
    'Rajkot': LatLng(22.3039, 70.8022),
    'Kalyan-Dombivli': LatLng(19.2403, 73.1305),
    'Vasai-Virar': LatLng(19.4914, 72.8052),
    'Varanasi': LatLng(25.3176, 82.9739),
  };

  @override
  void initState() {
    super.initState();
    _createMarkers();
    if (!kIsWeb) {
      _getCurrentLocation();
    }
  }

  Future<void> _getCurrentLocation() async {
    if (kIsWeb) return;

    setState(() {
      _isLoadingLocation = true;
    });

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _isLoadingLocation = false;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          setState(() {
            _isLoadingLocation = false;
          });
          return;
        }
      }

      Position position = await Geolocator.getCurrentPosition();
      setState(() {
        _currentPosition = position;
        _isLoadingLocation = false;
      });

      _animateToLocation(LatLng(position.latitude, position.longitude));
    } catch (e) {
      setState(() {
        _isLoadingLocation = false;
      });
    }
  }

  void _createMarkers() {
    _markers.clear();

    for (int i = 0; i < widget.agents.length; i++) {
      final agent = widget.agents[i];
      final agentId = agent['id'] as String;
      final nickname = agent['nickname'] as String;
      final isOnline = agent['isOnline'] as bool? ?? false;
      final rating = (agent['rating'] as num?)?.toDouble() ?? 0.0;

      // Generate location based on city or use random location around major cities
      LatLng agentLocation = _generateAgentLocation(i);

      final marker = Marker(
        markerId: MarkerId(agentId),
        position: agentLocation,
        infoWindow: InfoWindow(
          title: nickname,
          snippet: '⭐ $rating • ${isOnline ? 'Online' : 'Offline'}',
          onTap: () => widget.onAgentProfileTap(agent),
        ),
        icon: isOnline
            ? BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen)
            : BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        onTap: () => widget.onAgentSelected(agentId),
      );

      _markers.add(marker);
    }

    // Add current location marker if available
    if (_currentPosition != null) {
      _markers.add(
        Marker(
          markerId: const MarkerId('current_location'),
          position:
              LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
          infoWindow: const InfoWindow(title: 'Your Location'),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      );
    }

    setState(() {});
  }

  LatLng _generateAgentLocation(int index) {
    // Distribute agents across major Indian cities
    final cities = _indianCities.values.toList();
    final baseCity = cities[index % cities.length];

    // Add some random offset to create clusters around cities
    final latOffset = (index * 0.001) % 0.05 - 0.025;
    final lngOffset = (index * 0.0015) % 0.05 - 0.025;

    return LatLng(
      baseCity.latitude + latOffset,
      baseCity.longitude + lngOffset,
    );
  }

  void _animateToLocation(LatLng location) {
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: location,
          zoom: 12.0,
        ),
      ),
    );
  }

  void animateToCity(String cityName) {
    final cityLocation = _indianCities[cityName];
    if (cityLocation != null) {
      _animateToLocation(cityLocation);
    }
  }

  @override
  void didUpdateWidget(AgentMapViewWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.agents != widget.agents) {
      _createMarkers();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GoogleMap(
          onMapCreated: (GoogleMapController controller) {
            _mapController = controller;
          },
          initialCameraPosition: const CameraPosition(
            target: _defaultCenter,
            zoom: 6.0,
          ),
          markers: _markers,
          myLocationEnabled: !kIsWeb && _currentPosition != null,
          myLocationButtonEnabled: !kIsWeb,
          compassEnabled: true,
          zoomControlsEnabled: false,
          mapToolbarEnabled: false,
          onTap: (LatLng location) {
            // Clear selection when tapping on empty area
          },
        ),

        // Loading indicator for location
        if (_isLoadingLocation)
          Positioned(
            top: 2.h,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.cardColor,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.lightTheme.colorScheme.shadow
                          .withValues(alpha: 0.1),
                      blurRadius: 4,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.primaryColor,
                        ),
                      ),
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Getting your location...',
                      style: AppTheme.lightTheme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            ),
          ),

        // Agent count overlay
        Positioned(
          top: 2.h,
          right: 4.w,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.lightTheme.colorScheme.shadow
                      .withValues(alpha: 0.2),
                  blurRadius: 4,
                ),
              ],
            ),
            child: Text(
              '${widget.agents.length} agents',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: Colors.white,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),

        // Custom zoom controls
        Positioned(
          bottom: 15.h,
          right: 4.w,
          child: Column(
            children: [
              _buildZoomButton(
                icon: Icons.add,
                onTap: () {
                  _mapController?.animateCamera(CameraUpdate.zoomIn());
                },
              ),
              SizedBox(height: 1.h),
              _buildZoomButton(
                icon: Icons.remove,
                onTap: () {
                  _mapController?.animateCamera(CameraUpdate.zoomOut());
                },
              ),
            ],
          ),
        ),

        // My location button (if not web)
        if (!kIsWeb)
          Positioned(
            bottom: 8.h,
            right: 4.w,
            child: _buildZoomButton(
              icon: Icons.my_location,
              onTap: _getCurrentLocation,
            ),
          ),
      ],
    );
  }

  Widget _buildZoomButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      width: 12.w,
      height: 12.w,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.2),
            blurRadius: 4,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Icon(
            icon,
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
      ),
    );
  }
}
