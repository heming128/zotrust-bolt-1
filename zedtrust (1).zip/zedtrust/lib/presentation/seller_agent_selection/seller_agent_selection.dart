import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/agent_category_chips_widget.dart';
import './widgets/agent_search_widget.dart';
import './widgets/seller_agent_card_widget.dart';

class SellerAgentSelection extends StatefulWidget {
  const SellerAgentSelection({Key? key}) : super(key: key);

  @override
  State<SellerAgentSelection> createState() => _SellerAgentSelectionState();
}

class _SellerAgentSelectionState extends State<SellerAgentSelection> {
  final TextEditingController _searchController = TextEditingController();
  String? _selectedAgentId;
  String _selectedCategory = 'All';
  bool _isLoading = false;
  String _sellerCity = 'Mumbai'; // GPS or manual input

  // Mock verified agents data (admin-approved only)
  final List<Map<String, dynamic>> _verifiedAgents = [
    {
      "id": "agent_001",
      "name": "Rajnikant Aagnya Hawala",
      "alias": "Rajni Network",
      "rating": 4.9,
      "isVerified": true,
      "specializations": ["Cash Exchange", "Bank Transfer"],
      "commissionRate": "0.5%",
      "processingTime": "2-5 min",
      "minTradeAmount": 1000,
      "acceptedMethods": ["Cash Exchange", "UPI", "Bank Transfer"],
      "sellerProtection": "Full Coverage",
      "notes": "Premier hawala service with nationwide network",
      "locations": {
        "Mumbai": {
          "area": "Fort",
          "displayAlias": "Fort Branch",
          "addressLine": "2nd Fl, Mehta Bldg, Fort"
        },
        "Surat": {
          "area": "Ring Road",
          "displayAlias": "Ring Road Branch",
          "addressLine": "Shop 12, Textile Mkt, Ring Road"
        }
      }
    },
    {
      "id": "agent_002",
      "name": "Swift Money Exchange",
      "alias": "Swift Network",
      "rating": 4.7,
      "isVerified": true,
      "specializations": ["Bank Transfer", "Mobile Money"],
      "commissionRate": "0.3%",
      "processingTime": "1-3 min",
      "minTradeAmount": 500,
      "acceptedMethods": ["Bank Transfer", "Mobile Money", "UPI"],
      "sellerProtection": "Standard Coverage",
      "notes": "Fast digital transactions with competitive rates",
      "locations": {
        "Mumbai": {
          "area": "Andheri",
          "displayAlias": "Andheri Hub",
          "addressLine": "Office 405, Business Plaza, Andheri West"
        },
        "Delhi": {
          "area": "Connaught Place",
          "displayAlias": "CP Branch",
          "addressLine": "Block A, Connaught Place"
        }
      }
    },
    {
      "id": "agent_003",
      "name": "TrustPay Solutions",
      "alias": "TrustPay",
      "rating": 4.8,
      "isVerified": true,
      "specializations": ["Cash Exchange", "Crypto Exchange"],
      "commissionRate": "0.4%",
      "processingTime": "3-7 min",
      "minTradeAmount": 2000,
      "acceptedMethods": ["Cash Exchange", "Crypto Exchange", "Bank Transfer"],
      "sellerProtection": "Premium Coverage",
      "notes": "Secure crypto-fiat bridge with escrow protection",
      "locations": {
        "Mumbai": {
          "area": "Bandra",
          "displayAlias": "Bandra Office",
          "addressLine": "301, Trade Center, Bandra Kurla Complex"
        },
        "Bangalore": {
          "area": "Koramangala",
          "displayAlias": "Koramangala Branch",
          "addressLine": "4th Block, Koramangala"
        }
      }
    },
    {
      "id": "agent_004",
      "name": "QuickCash Network",
      "alias": "QuickCash",
      "rating": 4.6,
      "isVerified": true,
      "specializations": ["Mobile Money", "UPI"],
      "commissionRate": "0.2%",
      "processingTime": "1-2 min",
      "minTradeAmount": 100,
      "acceptedMethods": ["Mobile Money", "UPI", "Bank Transfer"],
      "sellerProtection": "Basic Coverage",
      "notes": "Instant mobile payments with lowest fees",
      "locations": {
        "Mumbai": {
          "area": "Dadar",
          "displayAlias": "Dadar Center",
          "addressLine": "Shop 15, Dadar Market Complex"
        }
      }
    }
  ];

  List<Map<String, dynamic>> _filteredAgents = [];
  final List<String> _categories = [
    'All',
    'Cash Exchange',
    'Bank Transfer',
    'Mobile Money',
    'Crypto Exchange'
  ];

  @override
  void initState() {
    super.initState();
    _filteredAgents = List.from(_verifiedAgents);
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    _filterAgents();
  }

  void _filterAgents() {
    setState(() {
      _filteredAgents = _verifiedAgents.where((agent) {
        // Search filter by name
        final searchQuery = _searchController.text.toLowerCase();
        final matchesSearch = searchQuery.isEmpty ||
            (agent['name'] as String).toLowerCase().contains(searchQuery) ||
            (agent['alias'] as String).toLowerCase().contains(searchQuery);

        // Category filter
        final matchesCategory = _selectedCategory == 'All' ||
            (agent['specializations'] as List<dynamic>)
                .contains(_selectedCategory);

        // Must have location in seller's city
        final hasSellerCityLocation =
            (agent['locations'] as Map<String, dynamic>)
                .containsKey(_sellerCity);

        return matchesSearch &&
            matchesCategory &&
            hasSellerCityLocation &&
            agent['isVerified'] == true;
      }).toList();

      // Sort by rating
      _filteredAgents.sort((a, b) {
        final aRating = (a['rating'] as num?)?.toDouble() ?? 0.0;
        final bRating = (b['rating'] as num?)?.toDouble() ?? 0.0;
        return bRating.compareTo(aRating);
      });
    });
  }

  void _selectAgent(String agentId) {
    setState(() {
      _selectedAgentId = agentId;
    });

    // Auto-assign seller's city location
    final selectedAgent = _verifiedAgents.firstWhere(
      (agent) => agent['id'] == agentId,
    );

    final sellerLocation =
        (selectedAgent['locations'] as Map<String, dynamic>)[_sellerCity];

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Agent selected: ${selectedAgent['alias']} - ${sellerLocation['displayAlias']}'),
        backgroundColor: AppTheme.getSuccessColor(true),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _confirmAgentSelection() {
    if (_selectedAgentId != null) {
      final selectedAgent = _verifiedAgents.firstWhere(
        (agent) => agent['id'] == _selectedAgentId,
      );

      Navigator.pop(context, {
        'agent': selectedAgent,
        'sellerLocation':
            (selectedAgent['locations'] as Map<String, dynamic>)[_sellerCity],
      });
    }
  }

  Widget _buildAgentPreview() {
    if (_selectedAgentId == null) return const SizedBox.shrink();

    final selectedAgent = _verifiedAgents.firstWhere(
      (agent) => agent['id'] == _selectedAgentId,
    );

    final sellerLocation =
        (selectedAgent['locations'] as Map<String, dynamic>)[_sellerCity];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.primaryColor,
          width: 2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.check_circle,
                color: AppTheme.getSuccessColor(true),
                size: 24,
              ),
              SizedBox(width: 2.w),
              Text(
                'Agent Selected',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  color: AppTheme.getSuccessColor(true),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Text(
            selectedAgent['alias'],
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              color: AppTheme.lightTheme.primaryColor,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            '${sellerLocation['displayAlias']} • $_sellerCity',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              _buildInfoChip('Commission: ${selectedAgent['commissionRate']}'),
              SizedBox(width: 2.w),
              _buildInfoChip('Time: ${selectedAgent['processingTime']}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
        ),
      ),
      child: Text(
        label,
        style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.cardColor,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.lightTheme.colorScheme.shadow,
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: CustomIconWidget(
                          iconName: 'arrow_back',
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                          size: 24,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Select Agent',
                          style: AppTheme.lightTheme.textTheme.headlineSmall
                              ?.copyWith(
                            fontWeight: FontWeight.w700,
                            color: AppTheme.lightTheme.colorScheme.onSurface,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 2.w, vertical: 0.5.h),
                        decoration: BoxDecoration(
                          color: AppTheme.getSuccessColor(true)
                              .withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _sellerCity,
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            color: AppTheme.getSuccessColor(true),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 3.h),
                  AgentSearchWidget(
                    controller: _searchController,
                    hintText: 'Search by agent name or alias',
                  ),
                  SizedBox(height: 2.h),
                  AgentCategoryChipsWidget(
                    categories: _categories,
                    selectedCategory: _selectedCategory,
                    onCategorySelected: (category) {
                      setState(() {
                        _selectedCategory = category;
                      });
                      _filterAgents();
                    },
                  ),
                ],
              ),
            ),

            // Selected Agent Preview
            if (_selectedAgentId != null) _buildAgentPreview(),

            // Agents List
            Expanded(
              child: _isLoading
                  ? _buildLoadingState()
                  : _filteredAgents.isEmpty
                      ? _buildEmptyState()
                      : ListView.builder(
                          padding: EdgeInsets.symmetric(vertical: 1.h),
                          itemCount: _filteredAgents.length,
                          itemBuilder: (context, index) {
                            final agent = _filteredAgents[index];
                            final isSelected = agent['id'] == _selectedAgentId;
                            final sellerLocation = (agent['locations']
                                as Map<String, dynamic>)[_sellerCity];

                            return SellerAgentCardWidget(
                              agent: agent,
                              sellerLocation: sellerLocation,
                              sellerCity: _sellerCity,
                              isSelected: isSelected,
                              onTap: () => _selectAgent(agent['id'] as String),
                            );
                          },
                        ),
            ),

            // Confirm Button
            if (_selectedAgentId != null)
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.cardColor,
                  border: Border(
                    top: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.2),
                    ),
                  ),
                ),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _confirmAgentSelection,
                    child: Text('Confirm Agent Selection'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: CircularProgressIndicator(
        color: AppTheme.lightTheme.primaryColor,
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'search_off',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 64,
            ),
            SizedBox(height: 3.h),
            Text(
              'No agents available in $_sellerCity',
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              'No verified agents match your criteria in the selected city. Try different search terms or contact support.',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
