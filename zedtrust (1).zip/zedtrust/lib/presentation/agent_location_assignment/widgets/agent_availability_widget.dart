import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class AgentAvailabilityWidget extends StatelessWidget {
  final Map<String, dynamic>? agent;
  final String userCity;
  final List<Map<String, dynamic>> availableLocations;
  final Map<String, dynamic>? assignedLocation;
  final Function(Map<String, dynamic>) onLocationSelected;
  final VoidCallback onShowAlternatives;

  const AgentAvailabilityWidget({
    super.key,
    required this.agent,
    required this.userCity,
    required this.availableLocations,
    this.assignedLocation,
    required this.onLocationSelected,
    required this.onShowAlternatives,
  });

  @override
  Widget build(BuildContext context) {
    final hasLocations = availableLocations.isNotEmpty;

    return Container(
      padding: EdgeInsets.all(20.sp),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16.sp),
        border: Border.all(
          color: hasLocations
              ? AppTheme.successLight.withAlpha(77)
              : AppTheme.warningLight.withAlpha(77),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  color: hasLocations
                      ? AppTheme.successLight.withAlpha(26)
                      : AppTheme.warningLight.withAlpha(26),
                  borderRadius: BorderRadius.circular(20.sp),
                ),
                child: Icon(
                  hasLocations ? Icons.check_circle : Icons.warning,
                  color: hasLocations
                      ? AppTheme.successLight
                      : AppTheme.warningLight,
                  size: 20.sp,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Agent Availability',
                      style: GoogleFonts.inter(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      hasLocations
                          ? 'Available in $userCity'
                          : 'Not available in $userCity',
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        color: hasLocations
                            ? AppTheme.successLight
                            : AppTheme.warningLight,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          if (hasLocations) ...[
            SizedBox(height: 20.h),

            // Location Details
            Container(
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.successLight.withAlpha(13),
                borderRadius: BorderRadius.circular(12.sp),
                border: Border.all(
                  color: AppTheme.successLight.withAlpha(51),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color: AppTheme.primaryLight,
                        size: 20.sp,
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          assignedLocation?['display_alias'] ??
                              'Location Branch',
                          style: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12.h),
                  _buildLocationDetail(
                    icon: Icons.location_city,
                    label: 'City',
                    value: assignedLocation?['city'] ?? userCity,
                  ),
                  SizedBox(height: 8.h),
                  _buildLocationDetail(
                    icon: Icons.place,
                    label: 'Area',
                    value: assignedLocation?['area'] ?? 'Central Area',
                  ),
                  SizedBox(height: 8.h),
                  _buildLocationDetail(
                    icon: Icons.home,
                    label: 'Address',
                    value: assignedLocation?['address_line'] ??
                        'Main Branch Office',
                  ),
                  if (availableLocations.length > 1) ...[
                    SizedBox(height: 16.h),
                    TextButton.icon(
                      onPressed: () => _showLocationOptions(context),
                      icon: Icon(
                        Icons.swap_horiz,
                        size: 16.sp,
                      ),
                      label: Text(
                        'Choose Different Location (${availableLocations.length} available)',
                        style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ] else ...[
            SizedBox(height: 20.h),

            // No Location Available
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.warningLight.withAlpha(13),
                borderRadius: BorderRadius.circular(12.sp),
                border: Border.all(
                  color: AppTheme.warningLight.withAlpha(51),
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    Icons.location_off,
                    color: AppTheme.warningLight,
                    size: 48.sp,
                  ),
                  SizedBox(height: 12.h),
                  Text(
                    'This agent has no active location in your city.',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.warningLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'Choose a different agent or change city.',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 16.h),
                  ElevatedButton.icon(
                    onPressed: onShowAlternatives,
                    icon: Icon(
                      Icons.search,
                      size: 16.sp,
                    ),
                    label: Text(
                      'Find Alternative Agents',
                      style: GoogleFonts.inter(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryLight,
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(
                          horizontal: 20.w, vertical: 10.h),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildLocationDetail({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 16.sp,
          color: AppTheme.textSecondaryLight,
        ),
        SizedBox(width: 8.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 12.sp,
                  color: AppTheme.textSecondaryLight,
                ),
              ),
              Text(
                value,
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _showLocationOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(20.sp),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Choose Location',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 16.h),
            ...availableLocations.map((location) {
              final isSelected = assignedLocation?['id'] == location['id'];

              return ListTile(
                leading: Icon(
                  Icons.location_on,
                  color: isSelected
                      ? AppTheme.primaryLight
                      : AppTheme.textSecondaryLight,
                ),
                title: Text(
                  location['display_alias'] ?? 'Branch',
                  style: GoogleFonts.inter(
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  ),
                ),
                subtitle: Text(
                  '${location['area']} • ${location['address_line']}',
                  style: GoogleFonts.inter(fontSize: 12.sp),
                ),
                trailing: isSelected
                    ? Icon(Icons.check, color: AppTheme.successLight)
                    : null,
                onTap: () {
                  onLocationSelected(location);
                  Navigator.pop(context);
                },
              );
            }),
          ],
        ),
      ),
    );
  }
}
