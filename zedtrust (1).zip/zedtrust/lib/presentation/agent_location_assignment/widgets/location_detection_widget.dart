import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class LocationDetectionWidget extends StatelessWidget {
  final bool isLoading;
  final String? detectedCity;
  final String error;
  final VoidCallback onRetryLocation;
  final Function(String) onManualCitySelect;

  const LocationDetectionWidget({
    super.key,
    required this.isLoading,
    this.detectedCity,
    required this.error,
    required this.onRetryLocation,
    required this.onManualCitySelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.sp),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16.sp),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  color: _getStatusColor().withAlpha(26),
                  borderRadius: BorderRadius.circular(20.sp),
                ),
                child: isLoading
                    ? SizedBox(
                        width: 20.w,
                        height: 20.h,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.primaryLight,
                        ),
                      )
                    : Icon(
                        _getStatusIcon(),
                        color: _getStatusColor(),
                        size: 20.sp,
                      ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Location Detection',
                      style: GoogleFonts.inter(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      _getStatusText(),
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        color: _getStatusColor(),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          SizedBox(height: 16.h),

          if (isLoading) ...[
            // Loading State
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.primaryLight.withAlpha(13),
                borderRadius: BorderRadius.circular(12.sp),
              ),
              child: Column(
                children: [
                  Text(
                    'Finding your location...',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    'This helps us find the nearest agent location',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ] else if (error.isNotEmpty) ...[
            // Error State
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.errorLight.withAlpha(13),
                borderRadius: BorderRadius.circular(12.sp),
                border: Border.all(
                  color: AppTheme.errorLight.withAlpha(51),
                ),
              ),
              child: Column(
                children: [
                  Text(
                    'Location access failed',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.errorLight,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Text(
                    error,
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: onRetryLocation,
                          icon: Icon(
                            Icons.refresh,
                            size: 16.sp,
                          ),
                          label: Text(
                            'Retry',
                            style: GoogleFonts.inter(fontSize: 12.sp),
                          ),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showCitySelector(context),
                          icon: Icon(
                            Icons.location_city,
                            size: 16.sp,
                          ),
                          label: Text(
                            'Select City',
                            style: GoogleFonts.inter(fontSize: 12.sp),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ] else if (detectedCity != null) ...[
            // Success State
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.successLight.withAlpha(13),
                borderRadius: BorderRadius.circular(12.sp),
                border: Border.all(
                  color: AppTheme.successLight.withAlpha(51),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.my_location,
                        color: AppTheme.successLight,
                        size: 20.sp,
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          'Located in $detectedCity',
                          style: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.successLight,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () => _showCitySelector(context),
                        child: Text(
                          'Change',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            color: AppTheme.primaryLight,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8.h),
                  Row(
                    children: [
                      Icon(
                        Icons.gps_fixed,
                        color: AppTheme.textSecondaryLight,
                        size: 16.sp,
                      ),
                      SizedBox(width: 8.w),
                      Expanded(
                        child: Text(
                          'High accuracy location detected',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getStatusColor() {
    if (isLoading) return AppTheme.primaryLight;
    if (error.isNotEmpty) return AppTheme.errorLight;
    if (detectedCity != null) return AppTheme.successLight;
    return AppTheme.textSecondaryLight;
  }

  IconData _getStatusIcon() {
    if (error.isNotEmpty) return Icons.error;
    if (detectedCity != null) return Icons.location_on;
    return Icons.location_searching;
  }

  String _getStatusText() {
    if (isLoading) return 'Detecting location...';
    if (error.isNotEmpty) return 'Location unavailable';
    if (detectedCity != null) return 'Location confirmed';
    return 'Location needed';
  }

  void _showCitySelector(BuildContext context) {
    final cities = [
      'Mumbai',
      'Surat',
      'Delhi',
      'Bangalore',
      'Chennai',
      'Kolkata',
      'Hyderabad',
      'Pune',
      'Ahmedabad',
      'Jaipur',
    ];

    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: EdgeInsets.all(20.sp),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Select Your City',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 16.h),
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: cities.length,
                itemBuilder: (context, index) {
                  final city = cities[index];
                  final isSelected = city == detectedCity;

                  return ListTile(
                    leading: Icon(
                      Icons.location_city,
                      color: isSelected
                          ? AppTheme.primaryLight
                          : AppTheme.textSecondaryLight,
                    ),
                    title: Text(
                      city,
                      style: GoogleFonts.inter(
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.w500,
                      ),
                    ),
                    trailing: isSelected
                        ? Icon(Icons.check, color: AppTheme.successLight)
                        : null,
                    onTap: () {
                      onManualCitySelect(city);
                      Navigator.pop(context);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
