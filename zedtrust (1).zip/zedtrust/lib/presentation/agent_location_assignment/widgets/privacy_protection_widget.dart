import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class PrivacyProtectionWidget extends StatelessWidget {
  const PrivacyProtectionWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20.sp),
      decoration: BoxDecoration(
        color: AppTheme.primaryLight.withAlpha(13),
        borderRadius: BorderRadius.circular(16.sp),
        border: Border.all(
          color: AppTheme.primaryLight.withAlpha(51),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 40.w,
                height: 40.h,
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withAlpha(26),
                  borderRadius: BorderRadius.circular(20.sp),
                ),
                child: Icon(
                  Icons.security,
                  color: AppTheme.primaryLight,
                  size: 20.sp,
                ),
              ),
              SizedBox(width: 12.w),
              Expanded(
                child: Text(
                  'Privacy Protection',
                  style: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryLight,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 16.h),

          // Privacy Points
          _buildPrivacyPoint(
            icon: Icons.visibility_off,
            title: 'Contact Details Hidden',
            description:
                'Agent phone numbers and emails are never exposed to either party',
          ),

          SizedBox(height: 12.h),

          _buildPrivacyPoint(
            icon: Icons.location_on,
            title: 'Location-Based Assignment',
            description:
                'Each party sees only their city-specific agent location address',
          ),

          SizedBox(height: 12.h),

          _buildPrivacyPoint(
            icon: Icons.chat,
            title: 'In-App Communication Only',
            description:
                'All communication happens through secure in-app messaging',
          ),

          SizedBox(height: 16.h),

          // Privacy Notice
          Container(
            padding: EdgeInsets.all(12.sp),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(128),
              borderRadius: BorderRadius.circular(8.sp),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: AppTheme.primaryLight,
                  size: 16.sp,
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: Text(
                    'Both parties will see the same agent name but different location details based on their respective cities.',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                      height: 1.4,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacyPoint({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 32.w,
          height: 32.h,
          decoration: BoxDecoration(
            color: AppTheme.successLight.withAlpha(26),
            borderRadius: BorderRadius.circular(16.sp),
          ),
          child: Icon(
            icon,
            color: AppTheme.successLight,
            size: 16.sp,
          ),
        ),
        SizedBox(width: 12.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
              SizedBox(height: 4.h),
              Text(
                description,
                style: GoogleFonts.inter(
                  fontSize: 12.sp,
                  color: AppTheme.textSecondaryLight,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
