import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class UserProfileCardWidget extends StatelessWidget {
  final String displayName;
  final String city;
  final double reliabilityScore;
  final bool isOnline;
  final String? lastSeen;

  const UserProfileCardWidget({
    Key? key,
    required this.displayName,
    required this.city,
    required this.reliabilityScore,
    required this.isOnline,
    this.lastSeen,
  }) : super(key: key);

  String _formatLastSeen(String? lastSeenString) {
    if (lastSeenString == null) return 'Never';

    try {
      final lastSeenDate = DateTime.parse(lastSeenString);
      final now = DateTime.now();
      final difference = now.difference(lastSeenDate);

      if (difference.inMinutes < 60) {
        return '${difference.inMinutes}m ago';
      } else if (difference.inHours < 24) {
        return '${difference.inHours}h ago';
      } else {
        return '${difference.inDays}d ago';
      }
    } catch (e) {
      return 'Unknown';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
            color: Colors.grey.shade50,
            border: Border.all(color: Colors.grey.shade200, width: 1)),
        child: Column(children: [
          // Profile Avatar and Name
          Row(children: [
            // Avatar
            Container(
                width: 60.w,
                height: 60.h,
                decoration: BoxDecoration(
                    color: Colors.blue.shade100, shape: BoxShape.circle),
                child: Icon(Icons.person, color: Colors.blue.shade700)),

            SizedBox(width: 16.w),

            // Name and City
            Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                  Text(displayName,
                      style: GoogleFonts.inter(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87)),
                  SizedBox(height: 4.h),
                  Row(children: [
                    Icon(Icons.location_on, color: Colors.grey.shade600),
                    SizedBox(width: 4.w),
                    Text(city,
                        style: GoogleFonts.inter(
                            fontSize: 14.sp, color: Colors.grey.shade700)),
                  ]),
                ])),

            // Online Status
            Container(
                padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                decoration: BoxDecoration(
                    color: isOnline
                        ? Colors.green.shade100
                        : Colors.grey.shade200),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Container(
                      decoration: BoxDecoration(
                          color: isOnline ? Colors.green : Colors.grey,
                          shape: BoxShape.circle)),
                  SizedBox(width: 4.w),
                  Text(isOnline ? 'Online' : 'Offline',
                      style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                          color: isOnline
                              ? Colors.green.shade800
                              : Colors.grey.shade700)),
                ])),
          ]),

          SizedBox(height: 16.h),

          // Rating and Last Seen
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            // Reliability Score
            Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                    color: Colors.amber.shade50,
                    border: Border.all(color: Colors.amber.shade200, width: 1)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.star, color: Colors.amber.shade700),
                  SizedBox(width: 4.w),
                  Text(reliabilityScore.toStringAsFixed(1),
                      style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                          color: Colors.amber.shade800)),
                ])),

            // Last Seen
            if (!isOnline)
              Text('Last seen ${_formatLastSeen(lastSeen)}',
                  style: GoogleFonts.inter(
                      fontSize: 12.sp, color: Colors.grey.shade600)),
          ]),
        ]));
  }
}
