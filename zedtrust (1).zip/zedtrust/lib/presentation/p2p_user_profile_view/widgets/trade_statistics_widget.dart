import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class TradeStatisticsWidget extends StatelessWidget {
  final int successfulTrades;
  final int totalTrades;
  final double completionRate;
  final String? averageResponseTime;

  const TradeStatisticsWidget({
    Key? key,
    required this.successfulTrades,
    required this.totalTrades,
    required this.completionRate,
    this.averageResponseTime,
  }) : super(key: key);

  String _formatResponseTime(String? responseTime) {
    if (responseTime == null) return 'Unknown';

    try {
      // Parse PostgreSQL interval format
      if (responseTime.contains('minutes')) {
        final minutes = RegExp(r'(\d+)\s*minutes').firstMatch(responseTime);
        if (minutes != null) {
          return '${minutes.group(1)}m';
        }
      } else if (responseTime.contains('hours')) {
        final hours = RegExp(r'(\d+)\s*hours').firstMatch(responseTime);
        if (hours != null) {
          return '${hours.group(1)}h';
        }
      }
      return responseTime;
    } catch (e) {
      return 'Unknown';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Trade Statistics',
          style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      SizedBox(height: 12.h),
      Container(
          decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey.shade200, width: 1)),
          child: Column(children: [
            // Completion Rate Progress
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('Completion Rate',
                  style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87)),
              Text('${completionRate.toStringAsFixed(1)}%',
                  style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: completionRate >= 90
                          ? Colors.green
                          : completionRate >= 70
                              ? Colors.orange
                              : Colors.red)),
            ]),
            SizedBox(height: 8.h),
            LinearProgressIndicator(
                value: completionRate / 100,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation<Color>(completionRate >= 90
                    ? Colors.green
                    : completionRate >= 70
                        ? Colors.orange
                        : Colors.red)),

            SizedBox(height: 16.h),

            // Statistics Row
            Row(children: [
              Expanded(
                  child: _buildStatItem(
                      'Successful',
                      successfulTrades.toString(),
                      Icons.check_circle_outline,
                      Colors.green)),
              Container(width: 1, height: 40.h, color: Colors.grey.shade200),
              Expanded(
                  child: _buildStatItem('Total Trades', totalTrades.toString(),
                      Icons.swap_horiz, Colors.blue)),
              Container(width: 1, height: 40.h, color: Colors.grey.shade200),
              Expanded(
                  child: _buildStatItem(
                      'Avg. Response',
                      _formatResponseTime(averageResponseTime),
                      Icons.schedule,
                      Colors.orange)),
            ]),
          ])),
    ]);
  }

  Widget _buildStatItem(
      String label, String value, IconData icon, Color color) {
    return Column(children: [
      Icon(icon, color: color),
      SizedBox(height: 8.h),
      Text(value,
          style: GoogleFonts.inter(
              fontSize: 18.sp,
              fontWeight: FontWeight.w700,
              color: Colors.black87)),
      SizedBox(height: 2.h),
      Text(label,
          style:
              GoogleFonts.inter(fontSize: 12.sp, color: Colors.grey.shade600),
          textAlign: TextAlign.center),
    ]);
  }
}
