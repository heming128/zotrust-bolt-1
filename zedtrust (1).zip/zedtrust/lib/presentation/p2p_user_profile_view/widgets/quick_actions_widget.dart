import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';

class QuickActionsWidget extends StatelessWidget {
  final VoidCallback onStartTrade;
  final VoidCallback onSendMessage;
  final VoidCallback onReportUser;
  final bool isCurrentUser;

  const QuickActionsWidget({
    Key? key,
    required this.onStartTrade,
    required this.onSendMessage,
    required this.onReportUser,
    required this.isCurrentUser,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Quick Actions',
          style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.black87)),
      SizedBox(height: 12.h),
      if (isCurrentUser) ...[
        // Actions for current user's profile
        _buildActionButton(
            label: 'Edit Profile',
            icon: Icons.edit_outlined,
            color: Colors.blue,
            onPressed: () => _navigateToEditProfile(context)),
        SizedBox(height: 8.h),
        _buildActionButton(
            label: 'View My Trades',
            icon: Icons.history,
            color: Colors.green,
            onPressed: () => _navigateToTradeHistory(context)),
      ] else ...[
        // Actions for other user's profile
        Row(children: [
          Expanded(
              child: _buildActionButton(
                  label: 'Start Trade',
                  icon: Icons.swap_horiz,
                  color: Colors.green,
                  onPressed: onStartTrade)),
          SizedBox(width: 12.w),
          Expanded(
              child: _buildActionButton(
                  label: 'Send Message',
                  icon: Icons.message_outlined,
                  color: Colors.blue,
                  onPressed: onSendMessage)),
        ]),
        SizedBox(height: 8.h),
        _buildActionButton(
            label: 'Report User',
            icon: Icons.flag_outlined,
            color: Colors.red,
            onPressed: onReportUser,
            isOutlined: true),
      ],
    ]);
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
    bool isOutlined = false,
  }) {
    return SizedBox(
        width: double.infinity,
        child: ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
                backgroundColor: isOutlined ? Colors.transparent : color,
                foregroundColor: isOutlined ? color : Colors.white,
                side: isOutlined ? BorderSide(color: color, width: 1) : null,
                padding: EdgeInsets.symmetric(vertical: 14.h),
                shape: RoundedRectangleBorder(),
                elevation: isOutlined ? 0 : 2),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: isOutlined ? color : Colors.white),
              SizedBox(width: 8.w),
              Text(label,
                  style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: isOutlined ? color : Colors.white)),
            ])));
  }

  void _navigateToEditProfile(BuildContext context) {
    // Navigate to profile edit screen
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Edit profile feature coming soon'),
        backgroundColor: Colors.blue));
  }

  void _navigateToTradeHistory(BuildContext context) {
    Navigator.pushNamed(context, '/trade-history');
  }
}
