import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import '../../routes/app_routes.dart';
import './widgets/agent_branch_info_widget.dart';
import './widgets/communication_options_widget.dart';
import './widgets/quick_actions_widget.dart';
import './widgets/trade_statistics_widget.dart';
import './widgets/user_profile_card_widget.dart';
import './widgets/verification_badges_widget.dart';

class P2PUserProfileView extends StatefulWidget {
  const P2PUserProfileView({Key? key}) : super(key: key);

  @override
  State<P2PUserProfileView> createState() => _P2PUserProfileViewState();
}

class _P2PUserProfileViewState extends State<P2PUserProfileView> {
  Map<String, dynamic>? userProfile;
  List<Map<String, dynamic>> agentBranches = [];
  bool isLoading = true;
  String? error;
  String? currentUserCity;

  @override
  void initState() {
    super.initState();
    _loadUserProfile();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Get user ID from route arguments
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && args['userId'] != null) {
      _loadUserProfile(userId: args['userId']);
    }
  }

  Future<void> _loadUserProfile({String? userId}) async {
    try {
      setState(() {
        isLoading = true;
        error = null;
      });

      final client = SupabaseService.instance.client;

      // Get user profile data
      final profileResponse = await client.rpc('get_p2p_user_profile',
          params: {'profile_user_id': userId ?? client.auth.currentUser?.id});

      if (profileResponse.isNotEmpty) {
        userProfile = profileResponse.first;
        currentUserCity = userProfile?['city'];

        // Get nearby agent branches if city is available
        if (currentUserCity != null) {
          final agentResponse = await client.rpc('get_nearby_agent_branches',
              params: {'user_city': currentUserCity});

          agentBranches = List<Map<String, dynamic>>.from(agentResponse);
        }
      }

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = 'Failed to load profile: $e';
        isLoading = false;
      });
    }
  }

  void _showReportDialog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Report User',
                  style: GoogleFonts.inter(
                      fontSize: 18.sp, fontWeight: FontWeight.w600)),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                Text('Please select a reason for reporting this user:',
                    style: GoogleFonts.inter(fontSize: 14.sp)),
                SizedBox(height: 16.h),
                ...[
                  'Suspicious activity',
                  'Fraudulent behavior',
                  'Inappropriate content',
                  'Other'
                ]
                    .map((reason) => ListTile(
                        title: Text(reason,
                            style: GoogleFonts.inter(fontSize: 14.sp)),
                        onTap: () {
                          Navigator.pop(context);
                          _submitReport(reason);
                        }))
                    .toList(),
              ]),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Cancel',
                        style: GoogleFonts.inter(color: Colors.grey))),
              ]);
        });
  }

  void _submitReport(String reason) {
    // Show confirmation
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Report submitted successfully'),
        backgroundColor: Colors.green));
  }

  void _startTrade() {
    Navigator.pushNamed(context, AppRoutes.createTrade, arguments: {
      'counterpartyId': userProfile?['profile_id'],
      'counterpartyName': userProfile?['display_name'],
      'counterpartyCity': userProfile?['city'],
    });
  }

  void _sendMessage() {
    Navigator.pushNamed(context, AppRoutes.inAppChat, arguments: {
      'recipientId': userProfile?['profile_id'],
      'recipientName': userProfile?['display_name'],
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black.withAlpha(128),
        body: SafeArea(
            child: Center(
                child: Container(
                    margin:
                        EdgeInsets.symmetric(horizontal: 16.w, vertical: 40.h),
                    decoration: BoxDecoration(color: Colors.white, boxShadow: [
                      BoxShadow(
                          color: Colors.black.withAlpha(26),
                          blurRadius: 20,
                          offset: const Offset(0, 10)),
                    ]),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      // Header with close button
                      Container(
                          decoration: BoxDecoration(
                              border: Border(
                                  bottom: BorderSide(
                                      color: Colors.grey.shade200, width: 1))),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('User Profile',
                                    style: GoogleFonts.inter(
                                        fontSize: 18.sp,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black87)),
                                IconButton(
                                    onPressed: () => Navigator.pop(context),
                                    icon: Icon(Icons.close,
                                        color: Colors.grey.shade600)),
                              ])),

                      // Content
                      Flexible(
                          child: SingleChildScrollView(child: _buildContent())),
                    ])))));
  }

  Widget _buildContent() {
    if (isLoading) {
      return Container(
          height: 200.h,
          child: Center(
              child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.blue))));
    }

    if (error != null) {
      return Container(
          height: 200.h,
          child: Center(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                Icon(Icons.error_outline, color: Colors.red),
                SizedBox(height: 16.h),
                Text(error!,
                    style:
                        GoogleFonts.inter(fontSize: 14.sp, color: Colors.red),
                    textAlign: TextAlign.center),
                SizedBox(height: 16.h),
                ElevatedButton(
                    onPressed: () => _loadUserProfile(), child: Text('Retry')),
              ])));
    }

    if (userProfile == null) {
      return Container(
          height: 200.h,
          child: Center(
              child: Text('User profile not found',
                  style:
                      GoogleFonts.inter(fontSize: 16.sp, color: Colors.grey))));
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      // User Profile Card
      UserProfileCardWidget(
          displayName: userProfile!['display_name'] ?? 'Unknown User',
          city: userProfile!['city'] ?? 'Unknown City',
          reliabilityScore:
              userProfile!['reliability_score']?.toDouble() ?? 0.0,
          isOnline: userProfile!['is_online'] ?? false,
          lastSeen: userProfile!['last_seen']),

      SizedBox(height: 20.h),

      // Verification Badges
      VerificationBadgesWidget(
          verificationBadges: List<String>.from(
              userProfile!['verification_badges']
                      ?.where((badge) => badge != null) ??
                  [])),

      SizedBox(height: 20.h),

      // Trade Statistics
      TradeStatisticsWidget(
          successfulTrades: userProfile!['successful_trades'] ?? 0,
          totalTrades: userProfile!['total_trades'] ?? 0,
          completionRate: userProfile!['completion_rate']?.toDouble() ?? 0.0,
          averageResponseTime: userProfile!['average_response_time']),

      SizedBox(height: 20.h),

      // Agent Branch Information
      if (agentBranches.isNotEmpty)
        AgentBranchInfoWidget(
            agentBranches: agentBranches, userCity: currentUserCity ?? ''),

      SizedBox(height: 20.h),

      // Communication Options
      CommunicationOptionsWidget(
          onSendMessage: _sendMessage,
          isCurrentUser: userProfile!['profile_id'] ==
              SupabaseService.instance.client.auth.currentUser?.id),

      SizedBox(height: 24.h),

      // Quick Actions
      QuickActionsWidget(
          onStartTrade: _startTrade,
          onSendMessage: _sendMessage,
          onReportUser: _showReportDialog,
          isCurrentUser: userProfile!['profile_id'] ==
              SupabaseService.instance.client.auth.currentUser?.id),
    ]);
  }
}
