import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/agent_search_filter_widget.dart';

class AgentNetworkManagement extends StatefulWidget {
  const AgentNetworkManagement({super.key});

  @override
  State<AgentNetworkManagement> createState() => _AgentNetworkManagementState();
}

class _AgentNetworkManagementState extends State<AgentNetworkManagement>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _searchQuery = '';
  Map<String, dynamic> _filters = {
    'status': 'all',
    'city': 'all',
    'verification': 'all',
    'performance': 'all',
  };
  List<String> _selectedAgents = [];
  bool _showBulkOperations = false;
  bool _showAddAgentModal = false;
  int _currentTabIndex = 0;

  final List<Map<String, dynamic>> _mockAgents = [
    {
      'id': 'agent_001',
      'name': 'Rajnikant Aagnya Hawala',
      'city': 'Surat',
      'locations': ['Surat Ring Road', 'Mumbai Fort'],
      'status': 'active',
      'verification': 'verified',
      'rating': 4.8,
      'totalTrades': 245,
      'completionRate': 98.5,
      'revenue': 125000,
      'joinedDate': '2023-01-15',
      'lastActive': '2 hours ago',
      'specializations': ['Crypto', 'Fiat'],
      'operationalHours': '09:00 - 21:00',
      'avatar':
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    },
    {
      'id': 'agent_002',
      'name': 'Priya Sharma Trading',
      'city': 'Mumbai',
      'locations': ['Mumbai Central', 'Andheri West'],
      'status': 'active',
      'verification': 'pending',
      'rating': 4.6,
      'totalTrades': 189,
      'completionRate': 96.2,
      'revenue': 98500,
      'joinedDate': '2023-03-20',
      'lastActive': '1 hour ago',
      'specializations': ['Digital Assets', 'Quick Exchange'],
      'operationalHours': '10:00 - 20:00',
      'avatar':
          'https://images.unsplash.com/photo-1494790108755-2616b612f464?w=150&h=150&fit=crop&crop=face',
    },
    {
      'id': 'agent_003',
      'name': 'Arjun Patel Exchange',
      'city': 'Delhi',
      'locations': ['Connaught Place', 'Karol Bagh'],
      'status': 'suspended',
      'verification': 'verified',
      'rating': 4.2,
      'totalTrades': 156,
      'completionRate': 94.8,
      'revenue': 78000,
      'joinedDate': '2023-02-10',
      'lastActive': '1 day ago',
      'specializations': ['Traditional Exchange'],
      'operationalHours': '11:00 - 19:00',
      'avatar':
          'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _tabController.addListener(() {
      setState(() {
        _currentTabIndex = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Agent Network Management',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.analytics_outlined),
            onPressed: () => _showAnalyticsDialog(),
          ),
          IconButton(
            icon: Icon(Icons.tune),
            onPressed: () => _showAutoMatchingConfig(),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: Icon(Icons.account_tree),
              text: 'Agent Network',
            ),
            Tab(
              icon: Icon(Icons.location_city),
              text: 'Locations',
            ),
            Tab(
              icon: Icon(Icons.analytics),
              text: 'Analytics',
            ),
            Tab(
              icon: Icon(Icons.settings),
              text: 'Configuration',
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search and Filters Section
            AgentSearchFilterWidget(
              searchQuery: _searchQuery,
              filters: _filters,
              onSearchChanged: (query) => setState(() => _searchQuery = query),
              onFiltersChanged: (filters) => setState(() => _filters = filters),
            ),

            // Bulk Operations Bar
            if (_showBulkOperations)
              _buildBulkOperationsBar(),

            // Tab Content
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildAgentNetworkTab(),
                  _buildLocationManagementTab(),
                  _buildAnalyticsTab(),
                  _buildConfigurationTab(),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: _currentTabIndex == 0
          ? FloatingActionButton.extended(
              onPressed: () => setState(() => _showAddAgentModal = true),
              icon: Icon(Icons.person_add),
              label: Text('Add Agent'),
            )
          : null,
      bottomSheet: _showAddAgentModal
          ? _buildAddAgentModal()
          : null,
    );
  }

  Widget _buildBulkOperationsBar() {
    return Container(
      padding: EdgeInsets.all(3.w),
      color: Theme.of(context).primaryColor.withOpacity(0.1),
      child: Row(
        children: [
          Text('${_selectedAgents.length} selected'),
          Spacer(),
          TextButton(
            onPressed: () => _handleBulkAction('verify'),
            child: Text('Verify'),
          ),
          TextButton(
            onPressed: () => _handleBulkAction('suspend'),
            child: Text('Suspend'),
          ),
          IconButton(
            onPressed: () => setState(() {
              _showBulkOperations = false;
              _selectedAgents.clear();
            }),
            icon: Icon(Icons.close),
          ),
        ],
      ),
    );
  }

  Widget _buildAddAgentModal() {
    return Container(
      height: 80.h,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(5.w)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Text('Add New Agent', style: Theme.of(context).textTheme.titleLarge),
              Spacer(),
              IconButton(
                onPressed: () => setState(() => _showAddAgentModal = false),
                icon: Icon(Icons.close),
              ),
            ],
          ),
          // Add agent form content here
          Expanded(
            child: Center(
              child: Text('Add Agent Form Coming Soon'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAgentNetworkTab() {
    final filteredAgents = _getFilteredAgents();

    return Column(
      children: [
        // City-wise Organization Header
        Container(
          padding: EdgeInsets.all(4.w),
          child: Row(
            children: [
              Icon(Icons.location_city,
                  size: 5.w, color: AppTheme.primaryLight),
              SizedBox(width: 2.w),
              Text(
                'Geographic Distribution View',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              Spacer(),
              TextButton.icon(
                onPressed: () => _toggleBulkOperations(),
                icon: Icon(Icons.checklist),
                label: Text('Bulk Select'),
              ),
            ],
          ),
        ),

        // Agent Cards by City
        Expanded(
          child: filteredAgents.isEmpty
              ? _buildEmptyState()
              : _buildAgentsList(filteredAgents),
        ),
      ],
    );
  }

  Widget _buildAgentsList(List<Map<String, dynamic>> agents) {
    return ListView.builder(
      padding: EdgeInsets.all(4.w),
      itemCount: agents.length,
      itemBuilder: (context, index) {
        final agent = agents[index];
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(agent['avatar']),
            ),
            title: Text(agent['name']),
            subtitle: Text('${agent['city']} • ${agent['status']}'),
            trailing: _showBulkOperations
                ? Checkbox(
                    value: _selectedAgents.contains(agent['id']),
                    onChanged: (value) => _handleAgentSelection(agent['id'], value ?? false),
                  )
                : PopupMenuButton(
                    itemBuilder: (context) => [
                      PopupMenuItem(value: 'edit', child: Text('Edit')),
                      PopupMenuItem(value: 'suspend', child: Text('Suspend')),
                      PopupMenuItem(value: 'analytics', child: Text('Analytics')),
                    ],
                    onSelected: (action) => _handleAgentAction(action.toString(), agent['id']),
                  ),
          ),
        );
      },
    );
  }

  Widget _buildLocationManagementTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'City-wise Location Distribution',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          SizedBox(height: 3.w),
          _buildLocationStatsCards(),
          SizedBox(height: 4.w),
          _buildLocationCapacityIndicators(),
          SizedBox(height: 4.w),
          _buildOperationalHoursConfig(),
        ],
      ),
    );
  }

  Widget _buildAnalyticsTab() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Text('Network Analytics', style: Theme.of(context).textTheme.titleLarge),
          SizedBox(height: 4.w),
          Expanded(
            child: Center(
              child: Text('Analytics widgets will be implemented here'),
            ),
          ),
          ElevatedButton(
            onPressed: () => _exportAnalytics(),
            child: Text('Export Data'),
          ),
        ],
      ),
    );
  }

  Widget _buildConfigurationTab() {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          Text('Auto-matching Configuration', style: Theme.of(context).textTheme.titleLarge),
          SizedBox(height: 4.w),
          Expanded(
            child: Center(
              child: Text('Configuration options will be implemented here'),
            ),
          ),
          ElevatedButton(
            onPressed: () => _saveAutoMatchingConfig({}),
            child: Text('Save Configuration'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.people_outline,
            size: 15.w,
            color: Colors.grey,
          ),
          SizedBox(height: 3.w),
          Text(
            'No agents found',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: Colors.grey,
                ),
          ),
          SizedBox(height: 2.w),
          Text(
            'Try adjusting your search filters',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationStatsCards() {
    final cities = ['Surat', 'Mumbai', 'Delhi', 'Pune'];

    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 1.2,
        crossAxisSpacing: 3.w,
        mainAxisSpacing: 3.w,
      ),
      itemCount: cities.length,
      itemBuilder: (context, index) {
        final city = cities[index];
        final agentCount = _mockAgents.where((a) => a['city'] == city).length;

        return Card(
          child: Padding(
            padding: EdgeInsets.all(3.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.location_on, color: AppTheme.primaryLight),
                    SizedBox(width: 2.w),
                    Expanded(
                      child: Text(
                        city,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.w),
                Text(
                  '$agentCount Agents',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
                Text(
                  '85% Capacity',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.getSuccessColor(true),
                      ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildLocationCapacityIndicators() {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Location Capacity Overview',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            SizedBox(height: 3.w),
            _buildCapacityBar('Surat Ring Road', 0.9, Colors.red),
            _buildCapacityBar('Mumbai Fort', 0.7, Colors.orange),
            _buildCapacityBar('Delhi Central', 0.5, Colors.green),
            _buildCapacityBar('Pune Station', 0.3, Colors.green),
          ],
        ),
      ),
    );
  }

  Widget _buildCapacityBar(String location, double capacity, Color color) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 1.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(location, style: Theme.of(context).textTheme.bodyMedium),
              Text('${(capacity * 100).toInt()}%'),
            ],
          ),
          SizedBox(height: 1.w),
          LinearProgressIndicator(
            value: capacity,
            backgroundColor: Colors.grey[300],
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ],
      ),
    );
  }

  Widget _buildOperationalHoursConfig() {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Operational Hours Configuration',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            SizedBox(height: 3.w),
            ListTile(
              leading: Icon(Icons.schedule),
              title: Text('Standard Hours'),
              subtitle: Text('09:00 AM - 09:00 PM'),
              trailing: Icon(Icons.edit),
              onTap: () => _editOperationalHours('standard'),
            ),
            ListTile(
              leading: Icon(Icons.schedule_outlined),
              title: Text('Extended Hours'),
              subtitle: Text('24/7 Premium Service'),
              trailing: Icon(Icons.edit),
              onTap: () => _editOperationalHours('extended'),
            ),
          ],
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredAgents() {
    return _mockAgents.where((agent) {
      final matchesSearch = _searchQuery.isEmpty ||
          agent['name'].toLowerCase().contains(_searchQuery.toLowerCase()) ||
          agent['city'].toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesStatus =
          _filters['status'] == 'all' || agent['status'] == _filters['status'];

      final matchesCity =
          _filters['city'] == 'all' || agent['city'] == _filters['city'];

      final matchesVerification = _filters['verification'] == 'all' ||
          agent['verification'] == _filters['verification'];

      return matchesSearch &&
          matchesStatus &&
          matchesCity &&
          matchesVerification;
    }).toList();
  }

  void _toggleBulkOperations() {
    setState(() {
      _showBulkOperations = !_showBulkOperations;
      if (!_showBulkOperations) {
        _selectedAgents.clear();
      }
    });
  }

  void _handleAgentSelection(String agentId, bool isSelected) {
    setState(() {
      if (isSelected) {
        _selectedAgents.add(agentId);
      } else {
        _selectedAgents.remove(agentId);
      }
    });
  }

  void _handleAgentAction(String action, String agentId) {
    switch (action) {
      case 'edit':
        _editAgent(agentId);
        break;
      case 'suspend':
        _suspendAgent(agentId);
        break;
      case 'analytics':
        _viewAgentAnalytics(agentId);
        break;
      case 'locations':
        _manageAgentLocations(agentId);
        break;
    }
  }

  void _handleBulkAction(String action) {
    switch (action) {
      case 'verify':
        _bulkVerifyAgents();
        break;
      case 'suspend':
        _bulkSuspendAgents();
        break;
      case 'reassign':
        _bulkReassignLocations();
        break;
      case 'policy_update':
        _bulkUpdatePolicies();
        break;
    }
  }

  void _handleAgentAdded(Map<String, dynamic> newAgent) {
    setState(() {
      _mockAgents.add(newAgent);
      _showAddAgentModal = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Agent ${newAgent['name']} added successfully'),
        backgroundColor: AppTheme.getSuccessColor(true),
      ),
    );
  }

  void _editAgent(String agentId) {
    // Implementation for editing agent
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Edit agent: $agentId')),
    );
  }

  void _suspendAgent(String agentId) {
    setState(() {
      final agentIndex = _mockAgents.indexWhere((a) => a['id'] == agentId);
      if (agentIndex != -1) {
        _mockAgents[agentIndex]['status'] =
            _mockAgents[agentIndex]['status'] == 'suspended'
                ? 'active'
                : 'suspended';
      }
    });
  }

  void _viewAgentAnalytics(String agentId) {
    // Implementation for viewing analytics
  }

  void _manageAgentLocations(String agentId) {
    Navigator.pushNamed(context, AppRoutes.agentLocationAssignment,
        arguments: agentId);
  }

  void _bulkVerifyAgents() {
    for (final agentId in _selectedAgents) {
      final agentIndex = _mockAgents.indexWhere((a) => a['id'] == agentId);
      if (agentIndex != -1) {
        _mockAgents[agentIndex]['verification'] = 'verified';
      }
    }
    _clearBulkSelection();
  }

  void _bulkSuspendAgents() {
    for (final agentId in _selectedAgents) {
      final agentIndex = _mockAgents.indexWhere((a) => a['id'] == agentId);
      if (agentIndex != -1) {
        _mockAgents[agentIndex]['status'] = 'suspended';
      }
    }
    _clearBulkSelection();
  }

  void _bulkReassignLocations() {
    // Implementation for bulk location reassignment
    _clearBulkSelection();
  }

  void _bulkUpdatePolicies() {
    // Implementation for bulk policy updates
    _clearBulkSelection();
  }

  void _clearBulkSelection() {
    setState(() {
      _selectedAgents.clear();
      _showBulkOperations = false;
    });
  }

  void _showAnalyticsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Network Analytics'),
        content: Text('Detailed analytics view coming soon...'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showAutoMatchingConfig() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (context) => Container(
        height: 60.h,
        padding: EdgeInsets.all(4.w),
        child: Column(
          children: [
            Text('Auto-matching Configuration', style: Theme.of(context).textTheme.titleLarge),
            SizedBox(height: 4.w),
            Expanded(
              child: Center(
                child: Text('Configuration options coming soon'),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _saveAutoMatchingConfig({});
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _exportAnalytics() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Analytics exported successfully')),
    );
  }

  void _saveAutoMatchingConfig(Map<String, dynamic> config) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Auto-matching configuration saved')),
    );
  }

  void _editOperationalHours(String type) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Edit $type Hours'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              decoration: InputDecoration(labelText: 'Start Time'),
            ),
            SizedBox(height: 2.w),
            TextField(
              decoration: InputDecoration(labelText: 'End Time'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Operational hours updated')),
              );
            },
            child: Text('Save'),
          ),
        ],
      ),
    );
  }
}