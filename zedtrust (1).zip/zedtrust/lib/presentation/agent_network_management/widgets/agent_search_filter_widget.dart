import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../theme/app_theme.dart';

class AgentSearchFilterWidget extends StatelessWidget {
  final String searchQuery;
  final Map<String, dynamic> filters;
  final Function(String) onSearchChanged;
  final Function(Map<String, dynamic>) onFiltersChanged;

  const AgentSearchFilterWidget({
    super.key,
    required this.searchQuery,
    required this.filters,
    required this.onSearchChanged,
    required this.onFiltersChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(13),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search Bar
          TextField(
            onChanged: onSearchChanged,
            decoration: InputDecoration(
              hintText: 'Search agents by name or city...',
              prefixIcon: Icon(Icons.search),
              suffixIcon: searchQuery.isNotEmpty
                  ? IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () => onSearchChanged(''),
                    )
                  : null,
            ),
          ),

          SizedBox(height: 3.w),

          // Filter Chips Row
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildFilterChip(
                  context,
                  'Status',
                  filters['status'],
                  ['all', 'active', 'suspended', 'pending'],
                  'status',
                ),
                SizedBox(width: 2.w),
                _buildFilterChip(
                  context,
                  'City',
                  filters['city'],
                  ['all', 'Surat', 'Mumbai', 'Delhi', 'Pune'],
                  'city',
                ),
                SizedBox(width: 2.w),
                _buildFilterChip(
                  context,
                  'Verification',
                  filters['verification'],
                  ['all', 'verified', 'pending', 'rejected'],
                  'verification',
                ),
                SizedBox(width: 2.w),
                _buildFilterChip(
                  context,
                  'Performance',
                  filters['performance'],
                  ['all', 'high', 'medium', 'low'],
                  'performance',
                ),
                SizedBox(width: 2.w),
                // Reset Filters Button
                if (_hasActiveFilters())
                  ActionChip(
                    label: Text('Reset'),
                    onPressed: _resetFilters,
                    backgroundColor: AppTheme.errorLight.withAlpha(26),
                    labelStyle: TextStyle(
                      color: AppTheme.errorLight,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(
    BuildContext context,
    String label,
    String currentValue,
    List<String> options,
    String filterKey,
  ) {
    return FilterChip(
      label: Text(_getDisplayValue(label, currentValue)),
      selected: currentValue != 'all',
      onSelected: (selected) =>
          _showFilterDialog(context, label, options, filterKey),
      selectedColor: AppTheme.primaryLight.withAlpha(51),
      backgroundColor: Colors.grey.withAlpha(26),
    );
  }

  String _getDisplayValue(String label, String value) {
    if (value == 'all') return label;
    return '$label: ${value[0].toUpperCase()}${value.substring(1)}';
  }

  void _showFilterDialog(
    BuildContext context,
    String title,
    List<String> options,
    String filterKey,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Select $title'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: options.map((option) {
            return RadioListTile<String>(
              title: Text(
                  option == 'all' ? 'All ${title}s' : option.toUpperCase()),
              value: option,
              groupValue: filters[filterKey],
              onChanged: (value) {
                final updatedFilters = Map<String, dynamic>.from(filters);
                updatedFilters[filterKey] = value;
                onFiltersChanged(updatedFilters);
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  bool _hasActiveFilters() {
    return filters.values.any((value) => value != 'all');
  }

  void _resetFilters() {
    final resetFilters = {
      'status': 'all',
      'city': 'all',
      'verification': 'all',
      'performance': 'all',
    };
    onFiltersChanged(resetFilters);
  }
}
