import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import
import '../../../core/services/zotrust_smart_contract_service.dart';

class TradesListWidget extends StatefulWidget {
  final List<TradeData> activeTrades;
  final List<TradeData> pastTrades;
  final String? userCity;
  final Function(TradeData) onTradeSelected;

  const TradesListWidget({
    super.key,
    required this.activeTrades,
    required this.pastTrades,
    this.userCity,
    required this.onTradeSelected,
  });

  @override
  State<TradesListWidget> createState() => _TradesListWidgetState();
}

class _TradesListWidgetState extends State<TradesListWidget>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildHeader(),
        SizedBox(height: 3.w),
        _buildTabBar(),
        SizedBox(height: 4.w),
        _buildTradesList(),
      ],
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Icon(
          Icons.list_alt,
          color: Colors.white,
          size: 6.w,
        ),
        SizedBox(width: 3.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Your Trades',
                style: GoogleFonts.inter(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              if (widget.userCity != null)
                Text(
                  'Filtered by ${widget.userCity}',
                  style: GoogleFonts.inter(
                    fontSize: 11.sp,
                    color: Colors.cyan.shade400,
                  ),
                ),
            ],
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.w),
          decoration: BoxDecoration(
            color: Colors.grey.shade800,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '${widget.activeTrades.length + widget.pastTrades.length}',
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTabBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade900,
        borderRadius: BorderRadius.circular(25),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(
            colors: [Colors.cyan.shade400, Colors.blue.shade600],
          ),
        ),
        labelColor: Colors.white,
        unselectedLabelColor: Colors.grey.shade400,
        labelStyle: GoogleFonts.inter(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
        ),
        tabs: [
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.access_time, size: 4.w),
                SizedBox(width: 2.w),
                Text('Active (${widget.activeTrades.length})'),
              ],
            ),
          ),
          Tab(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.history, size: 4.w),
                SizedBox(width: 2.w),
                Text('Past (${widget.pastTrades.length})'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradesList() {
    return SizedBox(
      height: 60.h,
      child: TabBarView(
        controller: _tabController,
        children: [
          _buildTradesTab(widget.activeTrades, isActive: true),
          _buildTradesTab(widget.pastTrades, isActive: false),
        ],
      ),
    );
  }

  Widget _buildTradesTab(List<TradeData> trades, {required bool isActive}) {
    if (trades.isEmpty) {
      return _buildEmptyState(isActive);
    }

    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: trades.length,
      itemBuilder: (context, index) {
        final trade = trades[index];
        return _buildTradeCard(trade);
      },
    );
  }

  Widget _buildEmptyState(bool isActive) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            isActive ? Icons.hourglass_empty : Icons.history,
            size: 15.w,
            color: Colors.grey.shade600,
          ),
          SizedBox(height: 4.w),
          Text(
            isActive ? 'No Active Trades' : 'No Past Trades',
            style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade500,
            ),
          ),
          SizedBox(height: 2.w),
          Text(
            isActive
                ? 'Your active trades will appear here'
                : 'Your trading history will appear here',
            textAlign: TextAlign.center,
            style: GoogleFonts.inter(
              fontSize: 12.sp,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradeCard(TradeData trade) {
    final statusColor = _getStatusColor(trade.status);
    final isUserBuyer =
        trade.buyer.toLowerCase().contains('buyer'); // Mock check

    return GestureDetector(
      onTap: () => widget.onTradeSelected(trade),
      child: Container(
        margin: EdgeInsets.only(bottom: 3.w),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Colors.grey.shade900,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: statusColor.withAlpha(77),
            width: 1,
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: statusColor.withAlpha(26),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getStatusIcon(trade.status),
                    color: statusColor,
                    size: 5.w,
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            'Trade #${trade.tradeId}',
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 2.w, vertical: 0.5.w),
                            decoration: BoxDecoration(
                              color: isUserBuyer
                                  ? Colors.green.shade600.withAlpha(51)
                                  : Colors.blue.shade600.withAlpha(51),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              isUserBuyer ? 'BUYER' : 'SELLER',
                              style: GoogleFonts.inter(
                                fontSize: 9.sp,
                                fontWeight: FontWeight.w600,
                                color: isUserBuyer
                                    ? Colors.green.shade300
                                    : Colors.blue.shade300,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        ZoTrustSmartContractService.instance
                                .formatAmount(trade.amount) +
                            ' USDC',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 2.w, vertical: 1.w),
                      decoration: BoxDecoration(
                        color: statusColor.withAlpha(26),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        trade.status.toUpperCase(),
                        style: GoogleFonts.inter(
                          fontSize: 10.sp,
                          fontWeight: FontWeight.w600,
                          color: statusColor,
                        ),
                      ),
                    ),
                    SizedBox(height: 1.w),
                    Text(
                      _formatDate(trade.createdAt),
                      style: GoogleFonts.inter(
                        fontSize: 9.sp,
                        color: Colors.grey.shade400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 3.w),
            _buildTradeProgress(trade),
          ],
        ),
      ),
    );
  }

  Widget _buildTradeProgress(TradeData trade) {
    final steps = ['Created', 'Funded', 'In Progress', 'Completed'];
    final currentIndex = steps.indexOf(trade.status);

    return Row(
      children: steps.map((step) {
        final index = steps.indexOf(step);
        final isActive = index <= currentIndex;
        final isCurrent = index == currentIndex;

        return Expanded(
          child: Row(
            children: [
              Container(
                width: 3.w,
                height: 3.w,
                decoration: BoxDecoration(
                  color: isActive ? Colors.cyan.shade400 : Colors.grey.shade600,
                  shape: BoxShape.circle,
                  border: isCurrent
                      ? Border.all(
                          color: Colors.cyan.shade400,
                          width: 2,
                        )
                      : null,
                ),
              ),
              if (index < steps.length - 1)
                Expanded(
                  child: Container(
                    height: 2,
                    color:
                        isActive ? Colors.cyan.shade400 : Colors.grey.shade600,
                  ),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'created':
        return Colors.blue.shade400;
      case 'funded':
        return Colors.orange.shade400;
      case 'in progress':
        return Colors.purple.shade400;
      case 'completed':
        return Colors.green.shade400;
      case 'cancelled':
        return Colors.red.shade400;
      default:
        return Colors.grey.shade400;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'created':
        return Icons.fiber_new;
      case 'funded':
        return Icons.account_balance;
      case 'in progress':
        return Icons.sync;
      case 'completed':
        return Icons.check_circle;
      case 'cancelled':
        return Icons.cancel;
      default:
        return Icons.help_outline;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 7) {
      return '${date.day}/${date.month}/${date.year}';
    } else if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }
}