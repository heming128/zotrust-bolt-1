import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../core/services/supabase_service.dart';
import '../../../theme/app_theme.dart';

class CityWiseAgentMatchingWidget extends StatefulWidget {
  final Function(Map<String, dynamic>) onAgentSelected;

  const CityWiseAgentMatchingWidget({
    super.key,
    required this.onAgentSelected,
  });

  @override
  State<CityWiseAgentMatchingWidget> createState() =>
      _CityWiseAgentMatchingWidgetState();
}

class _CityWiseAgentMatchingWidgetState
    extends State<CityWiseAgentMatchingWidget> with TickerProviderStateMixin {
  final SupabaseService _supabaseService = SupabaseService.instance;

  String _selectedRole = 'buyer';
  String? _selectedCity;
  String? _selectedArea;
  List<String> _availableCities = [];
  List<String> _availableAreas = [];
  List<Map<String, dynamic>> _matchingAgents = [];
  bool _isLoading = false;

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadCities();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadCities() async {
    setState(() => _isLoading = true);
    try {
      final cities = await _supabaseService.getAvailableCities();
      setState(() {
        _availableCities = cities;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadAreasForCity(String city) async {
    try {
      // Use existing getAgentLocationsByCity method to get areas
      final locations = await _supabaseService.client
          .from('agent_locations')
          .select('area')
          .eq('city', city)
          .eq('is_active', true);
      
      final areas = locations
          .map((item) => item['area'].toString())
          .where((area) => area.isNotEmpty)
          .toSet()
          .toList();
      
      setState(() {
        _availableAreas = areas;
        _selectedArea = null;
      });
    } catch (e) {
      setState(() => _availableAreas = []);
    }
  }

  Future<void> _searchMatchingAgents() async {
    if (_selectedCity == null) return;

    setState(() => _isLoading = true);

    try {
      // Use existing methods to get agents with locations
      String query = '''
        *,
        agent_locations!inner(
          id,
          city,
          area,
          display_alias,
          address_line,
          is_active,
          enable_buyer_matching,
          enable_seller_matching
        )
      ''';
      
      var queryBuilder = _supabaseService.client
          .from('agents')
          .select(query)
          .eq('is_verified', true)
          .eq('agent_locations.city', _selectedCity!)
          .eq('agent_locations.is_active', true);
      
      // Filter by role-specific matching
      if (_selectedRole == 'buyer') {
        queryBuilder = queryBuilder.eq('agent_locations.enable_buyer_matching', true);
      } else {
        queryBuilder = queryBuilder.eq('agent_locations.enable_seller_matching', true);
      }
      
      // Filter by area if selected
      if (_selectedArea != null) {
        queryBuilder = queryBuilder.eq('agent_locations.area', _selectedArea!);
      }
      
      final response = await queryBuilder.order('rating', ascending: false);
      final agents = List<Map<String, dynamic>>.from(response);

      setState(() {
        _matchingAgents = agents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _matchingAgents = [];
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            margin: EdgeInsets.only(top: 12.h),
            width: 40.w,
            height: 4.h,
            decoration: BoxDecoration(
              color: AppTheme.getNeutralColor(true),
              borderRadius: BorderRadius.circular(2.sp),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(20.sp),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(12.sp),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryLight.withAlpha(26),
                    borderRadius: BorderRadius.circular(12.sp),
                  ),
                  child: Icon(
                    Icons.location_searching,
                    color: AppTheme.primaryLight,
                    size: 24.sp,
                  ),
                ),
                SizedBox(width: 16.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'City-wise Agent Matching',
                        style: GoogleFonts.inter(
                          fontSize: 18.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        'Find agents by location and role',
                        style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Icon(
                    Icons.close,
                    size: 24.sp,
                    color: AppTheme.textSecondaryLight,
                  ),
                ),
              ],
            ),
          ),

          // Role Selection Tabs
          Container(
            margin: EdgeInsets.symmetric(horizontal: 20.w),
            decoration: BoxDecoration(
              color: isDark ? AppTheme.cardDark : AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(12.sp),
              border: Border.all(
                color: AppTheme.getNeutralColor(!isDark).withAlpha(51),
              ),
            ),
            child: TabBar(
              controller: _tabController,
              onTap: (index) {
                setState(() {
                  _selectedRole = index == 0 ? 'buyer' : 'seller';
                });
                _searchMatchingAgents();
              },
              indicator: BoxDecoration(
                color: AppTheme.primaryLight,
                borderRadius: BorderRadius.circular(10.sp),
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: AppTheme.textSecondaryLight,
              labelStyle: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
              ),
              unselectedLabelStyle: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
              ),
              tabs: [
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.shopping_cart, size: 16.sp),
                      SizedBox(width: 8.w),
                      Text('Buyer'),
                    ],
                  ),
                ),
                Tab(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.sell, size: 16.sp),
                      SizedBox(width: 8.w),
                      Text('Seller'),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 20.h),

          // Search Filters
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // City Selection
                Text(
                  'Select City',
                  style: GoogleFonts.inter(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textPrimaryLight,
                  ),
                ),
                SizedBox(height: 8.h),
                Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(12.sp),
                    border: Border.all(
                      color: AppTheme.getNeutralColor(true),
                    ),
                  ),
                  child: DropdownButtonFormField<String>(
                    value: _selectedCity,
                    decoration: InputDecoration(
                      hintText: 'Choose your city',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.w,
                        vertical: 16.h,
                      ),
                      prefixIcon: Icon(
                        Icons.location_city,
                        color: AppTheme.primaryLight,
                        size: 20.sp,
                      ),
                    ),
                    items: _availableCities.map((city) {
                      return DropdownMenuItem(
                        value: city,
                        child: Text(city),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => _selectedCity = value);
                      if (value != null) {
                        _loadAreasForCity(value);
                        _searchMatchingAgents();
                      }
                    },
                  ),
                ),

                SizedBox(height: 16.h),

                // Area Selection (Optional)
                if (_availableAreas.isNotEmpty) ...[
                  Text(
                    'Select Area (Optional)',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textPrimaryLight,
                    ),
                  ),
                  SizedBox(height: 8.h),
                  Container(
                    decoration: BoxDecoration(
                      color: Theme.of(context).scaffoldBackgroundColor,
                      borderRadius: BorderRadius.circular(12.sp),
                      border: Border.all(
                        color: AppTheme.getNeutralColor(true),
                      ),
                    ),
                    child: DropdownButtonFormField<String>(
                      value: _selectedArea,
                      decoration: InputDecoration(
                        hintText: 'Choose specific area',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 16.w,
                          vertical: 16.h,
                        ),
                        prefixIcon: Icon(
                          Icons.location_on,
                          color: AppTheme.primaryLight,
                          size: 20.sp,
                        ),
                      ),
                      items: _availableAreas.map((area) {
                        return DropdownMenuItem(
                          value: area,
                          child: Text(area),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() => _selectedArea = value);
                        _searchMatchingAgents();
                      },
                    ),
                  ),
                  SizedBox(height: 16.h),
                ],
              ],
            ),
          ),

          // Results Section
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _selectedCity == null
                    ? _buildSelectCityPrompt()
                    : _matchingAgents.isEmpty
                        ? _buildNoResultsState()
                        : _buildAgentsList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectCityPrompt() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.location_searching,
            size: 64.sp,
            color: AppTheme.textSecondaryLight,
          ),
          SizedBox(height: 16.h),
          Text(
            'Select a City to Find Agents',
            style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Choose your city to discover hawala agents\navailable for ${_selectedRole == 'buyer' ? 'buying' : 'selling'}',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              color: AppTheme.textSecondaryLight,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            size: 64.sp,
            color: AppTheme.textSecondaryLight,
          ),
          SizedBox(height: 16.h),
          Text(
            'No Agents Found',
            style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'No hawala agents available for ${_selectedRole == 'buyer' ? 'buyers' : 'sellers'} in\n${_selectedArea != null ? '$_selectedArea, ' : ''}$_selectedCity',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              color: AppTheme.textSecondaryLight,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 24.h),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _selectedArea = null;
              });
              _searchMatchingAgents();
            },
            icon: Icon(Icons.refresh, size: 16.sp),
            label: Text('Search All Areas'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryLight,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAgentsList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Results Header
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w),
          child: Row(
            children: [
              Icon(
                _selectedRole == 'buyer' ? Icons.shopping_cart : Icons.sell,
                color: AppTheme.primaryLight,
                size: 20.sp,
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: Text(
                  'Agents for ${_selectedRole == 'buyer' ? 'Buyers' : 'Sellers'} in $_selectedCity',
                  style: GoogleFonts.inter(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimaryLight,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 6.h),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withAlpha(26),
                  borderRadius: BorderRadius.circular(20.sp),
                ),
                child: Text(
                  '${_matchingAgents.length} Found',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryLight,
                  ),
                ),
              ),
            ],
          ),
        ),

        SizedBox(height: 16.h),

        // Agents List
        Expanded(
          child: ListView.builder(
            padding: EdgeInsets.symmetric(horizontal: 20.w),
            itemCount: _matchingAgents.length,
            itemBuilder: (context, index) {
              final agent = _matchingAgents[index];
              return _buildAgentCard(agent);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildAgentCard(Map<String, dynamic> agent) {
    final locations = agent['agent_locations'] as List<dynamic>? ?? [];
    final matchingLocation = locations.firstWhere(
      (loc) =>
          loc['city'] == _selectedCity &&
          (_selectedArea == null || loc['area'] == _selectedArea),
      orElse: () => locations.isNotEmpty ? locations.first : null,
    );

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16.sp),
        border: Border.all(
          color: AppTheme.getNeutralColor(
              Theme.of(context).brightness == Brightness.light),
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight.withAlpha(13),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16.sp),
          onTap: () => widget.onAgentSelected(agent),
          child: Padding(
            padding: EdgeInsets.all(16.sp),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Agent Header
                Row(
                  children: [
                    // Agent Avatar
                    Container(
                      width: 48.w,
                      height: 48.h,
                      decoration: BoxDecoration(
                        color: agent['is_verified'] == true
                            ? AppTheme.successLight.withAlpha(26)
                            : AppTheme.warningLight.withAlpha(26),
                        borderRadius: BorderRadius.circular(24.sp),
                        border: Border.all(
                          color: agent['is_verified'] == true
                              ? AppTheme.successLight
                              : AppTheme.warningLight,
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        Icons.person,
                        color: agent['is_verified'] == true
                            ? AppTheme.successLight
                            : AppTheme.warningLight,
                        size: 24.sp,
                      ),
                    ),

                    SizedBox(width: 12.w),

                    // Agent Info
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  agent['alias'] ?? agent['name'] ?? 'Unknown',
                                  style: GoogleFonts.inter(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              if (agent['is_verified'] == true)
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 6.w, vertical: 2.h),
                                  decoration: BoxDecoration(
                                    color: AppTheme.successLight,
                                    borderRadius: BorderRadius.circular(4.sp),
                                  ),
                                  child: Text(
                                    'VERIFIED',
                                    style: GoogleFonts.inter(
                                      fontSize: 8.sp,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          SizedBox(height: 4.h),
                          Row(
                            children: [
                              // Rating
                              Row(
                                children: [
                                  Icon(
                                    Icons.star,
                                    color: AppTheme.warningLight,
                                    size: 14.sp,
                                  ),
                                  SizedBox(width: 4.w),
                                  Text(
                                    '${agent['rating']?.toStringAsFixed(1) ?? '0.0'}',
                                    style: GoogleFonts.inter(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(width: 16.w),
                              // Location count
                              Row(
                                children: [
                                  Icon(
                                    Icons.location_on,
                                    color: AppTheme.primaryLight,
                                    size: 14.sp,
                                  ),
                                  SizedBox(width: 4.w),
                                  Text(
                                    '${locations.length} Branch${locations.length != 1 ? 'es' : ''}',
                                    style: GoogleFonts.inter(
                                      fontSize: 12.sp,
                                      color: AppTheme.textSecondaryLight,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                SizedBox(height: 12.h),

                // Location Details
                if (matchingLocation != null)
                  Container(
                    padding: EdgeInsets.all(12.sp),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight.withAlpha(13),
                      borderRadius: BorderRadius.circular(8.sp),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          color: AppTheme.primaryLight,
                          size: 16.sp,
                        ),
                        SizedBox(width: 8.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                matchingLocation['display_alias'] ?? 'Branch',
                                style: GoogleFonts.inter(
                                  fontSize: 13.sp,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.primaryLight,
                                ),
                              ),
                              if (matchingLocation['area'] != null)
                                Text(
                                  '${matchingLocation['area']}, ${matchingLocation['city']}',
                                  style: GoogleFonts.inter(
                                    fontSize: 12.sp,
                                    color: AppTheme.textSecondaryLight,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                SizedBox(height: 12.h),

                // Action Row
                Row(
                  children: [
                    // Contact Button
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          // Handle contact action
                        },
                        icon: Icon(Icons.phone, size: 16.sp),
                        label: Text('Contact'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppTheme.primaryLight,
                          side: BorderSide(color: AppTheme.primaryLight),
                          padding: EdgeInsets.symmetric(vertical: 8.h),
                        ),
                      ),
                    ),

                    SizedBox(width: 12.w),

                    // Select Button
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => widget.onAgentSelected(agent),
                        icon: Icon(Icons.check, size: 16.sp),
                        label: Text('Select'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryLight,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(vertical: 8.h),
                        ),
                      ),
                    ),
                  ],
                ),

                // Service Tags
                if (agent['agent_type'] != null)
                  Padding(
                    padding: EdgeInsets.only(top: 8.h),
                    child: Wrap(
                      spacing: 8.w,
                      runSpacing: 4.h,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color:
                                AppTheme.getNeutralColor(false).withAlpha(26),
                            borderRadius: BorderRadius.circular(4.sp),
                          ),
                          child: Text(
                            agent['agent_type']?.toUpperCase() ?? 'HAWALA',
                            style: GoogleFonts.inter(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textSecondaryLight,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 8.w, vertical: 4.h),
                          decoration: BoxDecoration(
                            color: (_selectedRole == 'buyer'
                                    ? AppTheme.successLight
                                    : AppTheme.warningLight)
                                .withAlpha(26),
                            borderRadius: BorderRadius.circular(4.sp),
                          ),
                          child: Text(
                            '${_selectedRole.toUpperCase()} FRIENDLY',
                            style: GoogleFonts.inter(
                              fontSize: 10.sp,
                              fontWeight: FontWeight.w600,
                              color: _selectedRole == 'buyer'
                                  ? AppTheme.successLight
                                  : AppTheme.warningLight,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}