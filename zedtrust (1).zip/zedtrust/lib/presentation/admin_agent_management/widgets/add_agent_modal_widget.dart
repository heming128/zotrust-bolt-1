import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../../core/services/supabase_service.dart';
import '../../../theme/app_theme.dart';

class AddAgentModalWidget extends StatefulWidget {
  final VoidCallback onAgentCreated;

  const AddAgentModalWidget({
    super.key,
    required this.onAgentCreated,
  });

  @override
  State<AddAgentModalWidget> createState() => _AddAgentModalWidgetState();
}

class _AddAgentModalWidgetState extends State<AddAgentModalWidget> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _aliasController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService.instance;

  bool _isLoading = false;
  bool _isVerified = true; // ✅ Auto-verification enabled by default
  double _rating = 0.0;
  String _selectedAgentType = 'hawala';

  // New listing options
  bool _enableBuyerListing = true;
  bool _enableSellerListing = true;
  bool _enableCityWideMatching = true;
  bool _enableCrossRegionMatching = false;

  // Location management
  List<Map<String, dynamic>> _locations = [];
  List<String> _availableCities = [];

  final List<Map<String, String>> _agentTypes = [
    {'value': 'hawala', 'label': 'Hawala Agent', 'icon': '🏪'},
    {'value': 'financial', 'label': 'Financial Services', 'icon': '🏦'},
    {'value': 'exchange', 'label': 'Currency Exchange', 'icon': '💱'},
    {'value': 'general', 'label': 'General Agent', 'icon': '👨‍💼'},
  ];

  @override
  void initState() {
    super.initState();
    _loadAvailableCities();
    _isVerified = true; // ✅ Auto-verification enabled by default
  }

  @override
  void dispose() {
    _nameController.dispose();
    _aliasController.dispose();
    _mobileController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadAvailableCities() async {
    try {
      final cities = await _supabaseService.getAvailableCities();
      setState(() {
        _availableCities = cities;
      });
    } catch (e) {
      if (mounted) {
        // Fallback cities when Supabase is not configured
        setState(() {
          _availableCities = [
            'Mumbai',
            'Surat',
            'Delhi',
            'Pune',
            'Bangalore',
            'Chennai',
            'Hyderabad',
            'Ahmedabad',
            'Kolkata',
            'Jaipur',
            'Nashik',
            'Vadodara',
            'Rajkot',
            'Indore',
            'Nagpur',
            'Lucknow',
            'Kanpur',
            'Gurgaon',
            'Noida',
            'Coimbatore',
          ];
        });

        // Don't show error toast immediately - user might not notice
        // Only show if they actually try to use the functionality
        if (kDebugMode) {
          print(
              'Warning: Using fallback cities due to Supabase configuration issue: $e');
        }
      }
    }
  }

  Future<void> _createAgent() async {
    if (!_formKey.currentState!.validate()) return;

    if (_locations.isEmpty) {
      _showErrorToast('Please add at least one branch location');
      return;
    }

    // Validation for listing options
    if (!_enableBuyerListing && !_enableSellerListing) {
      _showErrorToast(
          'Please enable at least one listing option (Buyer or Seller)');
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Check if Supabase is properly configured
      const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
      const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

      if (supabaseUrl.contains('dummy') ||
          supabaseAnonKey.contains('dummy') ||
          supabaseUrl.contains('your-') ||
          supabaseAnonKey.contains('your-')) {
        throw Exception(
            'Supabase configuration required. Please set up your SUPABASE_URL and SUPABASE_ANON_KEY environment variables.');
      }

      // Create agent first with enhanced properties
      final agent = await _supabaseService.createAgent(
        name: _nameController.text.trim(),
        alias: _aliasController.text.trim(),
        mobileNumber: _mobileController.text.trim(),
        agentType: _selectedAgentType,
        rating: _rating,
        isVerified: _isVerified,
        notes: _notesController.text.trim(),
        additionalData: {
          'enable_buyer_listing': _enableBuyerListing,
          'enable_seller_listing': _enableSellerListing,
          'enable_city_wide_matching': _enableCityWideMatching,
          'enable_cross_region_matching': _enableCrossRegionMatching,
          'total_locations': _locations.length,
          'primary_city':
              _locations.isNotEmpty ? _locations.first['city'] : null,
        },
      );

      // Create agent locations with enhanced matching data
      final locationsWithMatching = _locations.map((location) {
        return {
          ...location,
          'enable_buyer_matching': _enableBuyerListing,
          'enable_seller_matching': _enableSellerListing,
          'city_wide_coverage': _enableCityWideMatching,
          'cross_region_access': _enableCrossRegionMatching,
        };
      }).toList();

      await _supabaseService.createAgentLocationsBatch(
        agentId: agent['id'],
        locations: locationsWithMatching,
      );

      Fluttertoast.showToast(
        msg:
            'Hawala Agent "${_nameController.text}" created with ${_locations.length} location(s) successfully',
        backgroundColor: AppTheme.successLight,
        textColor: Colors.white,
        toastLength: Toast.LENGTH_LONG,
      );

      widget.onAgentCreated();
    } catch (e) {
      String errorMessage;
      if (e.toString().contains('Supabase configuration required')) {
        errorMessage =
            'Configuration Error: Please set up Supabase credentials in your environment variables to create agents.';
      } else if (e.toString().contains('Failed to fetch') ||
          e.toString().contains('ClientException')) {
        errorMessage =
            'Database Connection Error: Please check your Supabase configuration.';
      } else {
        errorMessage = 'Failed to create agent: ${e.toString()}';
      }

      _showErrorToast(errorMessage);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _addLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildAddLocationModal(),
    );
  }

  void _removeLocation(int index) {
    setState(() {
      _locations.removeAt(index);
    });
  }

  Widget _buildAddLocationModal() {
    final cityController = TextEditingController();
    final areaController = TextEditingController();
    final branchNameController = TextEditingController();
    final addressController = TextEditingController();
    String? selectedCity;

    return StatefulBuilder(
      builder: (context, setModalState) {
        return DraggableScrollableSheet(
          initialChildSize: 0.8,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius:
                    BorderRadius.vertical(top: Radius.circular(20.sp)),
              ),
              child: Column(
                children: [
                  // Handle bar
                  Container(
                    margin: EdgeInsets.only(top: 12.h),
                    width: 40.w,
                    height: 4.h,
                    decoration: BoxDecoration(
                      color: AppTheme.getNeutralColor(true),
                      borderRadius: BorderRadius.circular(2.sp),
                    ),
                  ),

                  // Header
                  Padding(
                    padding: EdgeInsets.all(20.sp),
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(8.sp),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryLight.withAlpha(26),
                            borderRadius: BorderRadius.circular(8.sp),
                          ),
                          child: Icon(
                            Icons.add_location,
                            color: AppTheme.primaryLight,
                            size: 20.sp,
                          ),
                        ),
                        SizedBox(width: 12.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Add Branch Location',
                                style: GoogleFonts.inter(
                                  fontSize: 18.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                'Enable city-wise buyer-seller matching',
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  color: AppTheme.textSecondaryLight,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: Icon(
                            Icons.close,
                            size: 24.sp,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Form Content
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      children: [
                        // City Selection
                        _buildLabel('City'),
                        SizedBox(height: 8.h),
                        Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(12.sp),
                            border: Border.all(
                              color: AppTheme.getNeutralColor(true),
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            value: selectedCity,
                            decoration: InputDecoration(
                              hintText: 'Select city for matching',
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 16.w,
                                vertical: 16.h,
                              ),
                              prefixIcon: Icon(
                                Icons.location_city,
                                color: AppTheme.primaryLight,
                                size: 20.sp,
                              ),
                            ),
                            items: _availableCities.map((city) {
                              return DropdownMenuItem(
                                value: city,
                                child: Text(city),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setModalState(() {
                                selectedCity = value;
                                cityController.text = value ?? '';
                              });
                            },
                          ),
                        ),

                        SizedBox(height: 20.h),

                        // Branch Name
                        _buildModalInputField(
                          controller: branchNameController,
                          label: 'Branch Name',
                          hint: 'e.g., Ring Road Branch, Fort Branch',
                        ),

                        SizedBox(height: 20.h),

                        // Area
                        _buildModalInputField(
                          controller: areaController,
                          label: 'Area',
                          hint: 'e.g., Ring Road, Andheri West, Fort',
                        ),

                        SizedBox(height: 20.h),

                        // Full Address
                        _buildModalInputField(
                          controller: addressController,
                          label: 'Complete Address',
                          hint: 'Shop/Office number, Building, Street...',
                          maxLines: 3,
                        ),

                        SizedBox(height: 20.h),

                        // Preview how this will affect matching
                        if (selectedCity != null && selectedCity!.isNotEmpty)
                          Container(
                            padding: EdgeInsets.all(12.sp),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryLight.withAlpha(13),
                              borderRadius: BorderRadius.circular(12.sp),
                              border: Border.all(
                                color: AppTheme.primaryLight.withAlpha(51),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Matching Preview',
                                  style: GoogleFonts.inter(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.primaryLight,
                                  ),
                                ),
                                SizedBox(height: 8.h),
                                Text(
                                  'This branch will be visible to users in $selectedCity for ${_enableBuyerListing && _enableSellerListing ? 'both buying and selling' : (_enableBuyerListing ? 'buying only' : 'selling only')}.',
                                  style: GoogleFonts.inter(
                                    fontSize: 12.sp,
                                    color: AppTheme.textSecondaryLight,
                                  ),
                                ),
                              ],
                            ),
                          ),

                        SizedBox(height: 40.h),

                        // Add Location Button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (selectedCity != null &&
                                  branchNameController.text.trim().isNotEmpty &&
                                  areaController.text.trim().isNotEmpty &&
                                  addressController.text.trim().isNotEmpty) {
                                setState(() {
                                  _locations.add({
                                    'city': selectedCity!,
                                    'area': areaController.text.trim(),
                                    'display_alias':
                                        branchNameController.text.trim(),
                                    'address_line':
                                        addressController.text.trim(),
                                    'is_active': true,
                                  });
                                });
                                Navigator.pop(context);
                              } else {
                                Fluttertoast.showToast(
                                  msg: 'Please fill all required fields',
                                  backgroundColor: AppTheme.errorLight,
                                  textColor: Colors.white,
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryLight,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 16.h),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.sp),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.add_location,
                                  size: 20.sp,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  'Add Branch Location',
                                  style: GoogleFonts.inter(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        SizedBox(height: 20.h),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
          ),
          child: Column(
            children: [
              // Handle bar - Make it more visible
              Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 50.w, // Increased width
                height: 6.h, // Increased height
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withAlpha(102), // More visible
                  borderRadius: BorderRadius.circular(3.sp),
                ),
              ),

              // Header with enhanced styling
              Padding(
                padding: EdgeInsets.all(20.sp),
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(12.sp),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryLight.withAlpha(26),
                        borderRadius: BorderRadius.circular(12.sp),
                      ),
                      child: Icon(
                        Icons.person_add,
                        color: AppTheme.primaryLight,
                        size: 24.sp,
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Add New Hawala Agent',
                            style: GoogleFonts.inter(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            'All fields available: Name, Alias, Cities, Addresses, Rating, Auto-verification',
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              color: AppTheme
                                  .successLight, // Green to indicate all features are present
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: Icon(
                        Icons.close,
                        size: 24.sp,
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              ),

              // Form Content
              Expanded(
                child: Form(
                  key: _formKey,
                  child: ListView(
                    controller: scrollController,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    children: [
                      // ✅ Agent Name - ALREADY IMPLEMENTED
                      _buildInputField(
                        controller: _nameController,
                        label: '✅ Agent Name (Main Agent Name Input)',
                        hint: 'e.g., Rajnikant Aagnya Hawala',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Agent name is required';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // ✅ Agent Alias - ALREADY IMPLEMENTED
                      _buildInputField(
                        controller: _aliasController,
                        label: '✅ Agent Alias (Branch Identifier)',
                        hint: 'e.g., Rajni Network',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Display alias is required';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // Mobile Number
                      _buildInputField(
                        controller: _mobileController,
                        label: 'Mobile Number',
                        hint: 'e.g., +91 9876543210',
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[0-9+\-\s\(\)]')),
                        ],
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Mobile number is required';
                          }
                          if (value.replaceAll(RegExp(r'[^0-9]'), '').length <
                              10) {
                            return 'Please enter a valid mobile number';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // Listing Options Section
                      _buildListingOptionsSection(),

                      SizedBox(height: 20.h),

                      // ✅ Multiple City Selection & Branch Addresses - ALREADY IMPLEMENTED
                      Container(
                        padding: EdgeInsets.all(16.sp),
                        decoration: BoxDecoration(
                          color: AppTheme.successLight.withAlpha(13),
                          borderRadius: BorderRadius.circular(12.sp),
                          border: Border.all(
                            color: AppTheme.successLight.withAlpha(51),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.check_circle,
                                  color: AppTheme.successLight,
                                  size: 20.sp,
                                ),
                                SizedBox(width: 8.w),
                                Expanded(
                                  child: Text(
                                    '✅ Multiple City Selection & Branch Addresses',
                                    style: GoogleFonts.inter(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.successLight,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8.h),
                            Text(
                              'Cities Available: Mumbai, Delhi, Surat, Pune, Bangalore, Chennai, Hyderabad, Ahmedabad, Kolkata, Jaipur, and more...',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                color: AppTheme.textSecondaryLight,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 12.h),

                      // Branch Locations Section - Enhanced Display
                      Row(
                        children: [
                          Icon(
                            Icons.location_city,
                            color: AppTheme.primaryLight,
                            size: 20.sp,
                          ),
                          SizedBox(width: 8.w),
                          Expanded(
                            child: Text(
                              'Branch Locations (City-wise Address Fields)',
                              style: GoogleFonts.inter(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textPrimaryLight,
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.w, vertical: 4.h),
                            decoration: BoxDecoration(
                              color: _locations.isEmpty
                                  ? AppTheme.errorLight.withAlpha(26)
                                  : AppTheme.successLight.withAlpha(26),
                              borderRadius: BorderRadius.circular(6.sp),
                            ),
                            child: Text(
                              '${_locations.length} Location${_locations.length != 1 ? 's' : ''}',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w500,
                                color: _locations.isEmpty
                                    ? AppTheme.errorLight
                                    : AppTheme.successLight,
                              ),
                            ),
                          ),
                          SizedBox(width: 8.w),
                          ElevatedButton.icon(
                            onPressed: _addLocation,
                            icon: Icon(
                              Icons.add,
                              size: 18.sp,
                            ),
                            label: Text(
                              'Add City + Address',
                              style: GoogleFonts.inter(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryLight,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: 12.w,
                                vertical: 8.h,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.sp),
                              ),
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 8.h),

                      // Locations List with enhanced display
                      if (_locations.isEmpty)
                        Container(
                          padding: EdgeInsets.all(20.sp),
                          decoration: BoxDecoration(
                            color: AppTheme.errorLight.withAlpha(13),
                            borderRadius: BorderRadius.circular(12.sp),
                            border: Border.all(
                              color: AppTheme.errorLight.withAlpha(51),
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                Icons.location_off,
                                size: 32.sp,
                                color: AppTheme.errorLight,
                              ),
                              SizedBox(height: 8.h),
                              Text(
                                'No branch locations added yet',
                                style: GoogleFonts.inter(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppTheme.errorLight,
                                ),
                              ),
                              SizedBox(height: 4.h),
                              Text(
                                'Add at least one branch location to enable city-wise matching',
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  color: AppTheme.errorLight.withAlpha(179),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        )
                      else
                        Column(
                          children: [
                            // City Summary
                            Container(
                              padding: EdgeInsets.all(12.sp),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryLight.withAlpha(13),
                                borderRadius: BorderRadius.circular(12.sp),
                                border: Border.all(
                                  color: AppTheme.primaryLight.withAlpha(51),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.analytics,
                                    color: AppTheme.primaryLight,
                                    size: 20.sp,
                                  ),
                                  SizedBox(width: 12.w),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Coverage Summary',
                                          style: GoogleFonts.inter(
                                            fontSize: 14.sp,
                                            fontWeight: FontWeight.w600,
                                            color: AppTheme.primaryLight,
                                          ),
                                        ),
                                        SizedBox(height: 2.h),
                                        Text(
                                          'Cities: ${_getUniqueCities().join(', ')}',
                                          style: GoogleFonts.inter(
                                            fontSize: 12.sp,
                                            color: AppTheme.textSecondaryLight,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 12.h),
                            // Locations List
                            ...List.generate(_locations.length, (index) {
                              final location = _locations[index];
                              return Container(
                                margin: EdgeInsets.only(bottom: 8.h),
                                padding: EdgeInsets.all(12.sp),
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryLight.withAlpha(26),
                                  borderRadius: BorderRadius.circular(12.sp),
                                  border: Border.all(
                                    color: AppTheme.primaryLight.withAlpha(51),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(8.sp),
                                      decoration: BoxDecoration(
                                        color: AppTheme.primaryLight,
                                        borderRadius:
                                            BorderRadius.circular(8.sp),
                                      ),
                                      child: Icon(
                                        Icons.location_on,
                                        color: Colors.white,
                                        size: 16.sp,
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            location['display_alias'],
                                            style: GoogleFonts.inter(
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          SizedBox(height: 2.h),
                                          Text(
                                            '${location['area']}, ${location['city']}',
                                            style: GoogleFonts.inter(
                                              fontSize: 12.sp,
                                              color:
                                                  AppTheme.textSecondaryLight,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => _removeLocation(index),
                                      icon: Icon(
                                        Icons.remove_circle,
                                        color: AppTheme.errorLight,
                                        size: 20.sp,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          ],
                        ),

                      SizedBox(height: 20.h),

                      // ✅ Rating - ALREADY IMPLEMENTED
                      Container(
                        padding: EdgeInsets.all(16.sp),
                        decoration: BoxDecoration(
                          color: AppTheme.warningLight.withAlpha(13),
                          borderRadius: BorderRadius.circular(12.sp),
                          border: Border.all(
                            color: AppTheme.warningLight.withAlpha(51),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.star,
                                  color: AppTheme.warningLight,
                                  size: 20.sp,
                                ),
                                SizedBox(width: 8.w),
                                Text(
                                  '✅ Rating (Agent Rating Input)',
                                  style: GoogleFonts.inter(
                                    fontSize: 16.sp,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.warningLight,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12.h),
                            Container(
                              padding: EdgeInsets.all(16.sp),
                              decoration: BoxDecoration(
                                color:
                                    Theme.of(context).scaffoldBackgroundColor,
                                borderRadius: BorderRadius.circular(12.sp),
                                border: Border.all(
                                  color: AppTheme.getNeutralColor(true),
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Rating: ${_rating.toStringAsFixed(1)}/5.0',
                                        style: GoogleFonts.inter(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                      Row(
                                        children: List.generate(5, (index) {
                                          return Icon(
                                            index < _rating.round()
                                                ? Icons.star
                                                : Icons.star_border,
                                            color: AppTheme.warningLight,
                                            size: 20.sp,
                                          );
                                        }),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 8.h),
                                  Slider(
                                    value: _rating,
                                    min: 0.0,
                                    max: 5.0,
                                    divisions: 50,
                                    onChanged: (value) {
                                      setState(() => _rating = value);
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 20.h),

                      // ✅ Auto-verification - ALREADY IMPLEMENTED (Enabled by default)
                      Container(
                        padding: EdgeInsets.all(16.sp),
                        decoration: BoxDecoration(
                          color: AppTheme.successLight.withAlpha(13),
                          borderRadius: BorderRadius.circular(12.sp),
                          border: Border.all(
                            color: AppTheme.successLight.withAlpha(51),
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _isVerified ? Icons.verified : Icons.pending,
                              color: _isVerified
                                  ? AppTheme.successLight
                                  : AppTheme.warningLight,
                              size: 20.sp,
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '✅ Auto-verification (Enabled by Default)',
                                    style: GoogleFonts.inter(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.successLight,
                                    ),
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    _isVerified
                                        ? 'Agent will be immediately available for trades'
                                        : 'Toggle to enable auto-verification (recommended)',
                                    style: GoogleFonts.inter(
                                      fontSize: 12.sp,
                                      color: AppTheme.textSecondaryLight,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Switch(
                              value: _isVerified,
                              onChanged: (value) {
                                setState(() => _isVerified = value);
                              },
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 20.h),

                      // Notes
                      _buildInputField(
                        controller: _notesController,
                        label: 'Admin Notes (Optional)',
                        hint: 'Additional notes about this agent...',
                        maxLines: 3,
                      ),

                      SizedBox(height: 40.h),

                      // Create Button with enhanced styling
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _createAgent,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.primaryLight,
                            foregroundColor: Colors.white,
                            padding: EdgeInsets.symmetric(vertical: 16.h),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.sp),
                            ),
                          ),
                          child: _isLoading
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      width: 20.w,
                                      height: 20.h,
                                      child: const CircularProgressIndicator(
                                        color: Colors.white,
                                        strokeWidth: 2,
                                      ),
                                    ),
                                    SizedBox(width: 12.w),
                                    Text(
                                      'Creating Agent...',
                                      style: GoogleFonts.inter(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.add_business,
                                      size: 20.sp,
                                    ),
                                    SizedBox(width: 8.w),
                                    Text(
                                      'Create Hawala Agent',
                                      style: GoogleFonts.inter(
                                        fontSize: 16.sp,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),

                      SizedBox(height: 20.h),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // NEW: Build Listing Options Section
  Widget _buildListingOptionsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.list_alt,
              color: AppTheme.primaryLight,
              size: 20.sp,
            ),
            SizedBox(width: 8.w),
            Text(
              'Listing & Matching Options',
              style: GoogleFonts.inter(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
            ),
          ],
        ),
        SizedBox(height: 12.h),
        Container(
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: BorderRadius.circular(12.sp),
            border: Border.all(
              color: AppTheme.getNeutralColor(true),
            ),
          ),
          child: Column(
            children: [
              // Buyer Listing Option
              _buildListingOptionTile(
                title: 'Enable Buyer Listing',
                subtitle: 'Allow buyers to find this agent in their city',
                icon: Icons.shopping_cart,
                value: _enableBuyerListing,
                onChanged: (value) {
                  setState(() => _enableBuyerListing = value!);
                },
                iconColor: AppTheme.successLight,
              ),

              Divider(height: 1, color: AppTheme.getNeutralColor(true)),

              // Seller Listing Option
              _buildListingOptionTile(
                title: 'Enable Seller Listing',
                subtitle: 'Allow sellers to find this agent in their city',
                icon: Icons.sell,
                value: _enableSellerListing,
                onChanged: (value) {
                  setState(() => _enableSellerListing = value!);
                },
                iconColor: AppTheme.warningLight,
              ),

              Divider(height: 1, color: AppTheme.getNeutralColor(true)),

              // City-wide Matching
              _buildListingOptionTile(
                title: 'City-wide Matching',
                subtitle: 'Show agent for all areas within same cities',
                icon: Icons.location_city,
                value: _enableCityWideMatching,
                onChanged: (value) {
                  setState(() => _enableCityWideMatching = value!);
                },
                iconColor: AppTheme.primaryLight,
              ),

              Divider(height: 1, color: AppTheme.getNeutralColor(true)),

              // Cross-region Matching
              _buildListingOptionTile(
                title: 'Cross-region Matching',
                subtitle: 'Allow matching across different cities/regions',
                icon: Icons.public,
                value: _enableCrossRegionMatching,
                onChanged: (value) {
                  setState(() => _enableCrossRegionMatching = value!);
                },
                iconColor: AppTheme.secondaryLight,
              ),
            ],
          ),
        ),

        // Info about listing options
        if (!_enableBuyerListing || !_enableSellerListing)
          Container(
            margin: EdgeInsets.only(top: 8.h),
            padding: EdgeInsets.all(12.sp),
            decoration: BoxDecoration(
              color: AppTheme.warningLight.withAlpha(13),
              borderRadius: BorderRadius.circular(8.sp),
              border: Border.all(
                color: AppTheme.warningLight.withAlpha(51),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info,
                  color: AppTheme.warningLight,
                  size: 16.sp,
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: Text(
                    'This agent will only be visible to ${!_enableBuyerListing && !_enableSellerListing ? 'nobody' : (!_enableBuyerListing ? 'sellers' : 'buyers')} in the matching system.',
                    style: GoogleFonts.inter(
                      fontSize: 11.sp,
                      color: AppTheme.warningLight,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildListingOptionTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool value,
    required ValueChanged<bool?> onChanged,
    required Color iconColor,
  }) {
    return CheckboxListTile(
      title: Row(
        children: [
          Container(
            padding: EdgeInsets.all(6.sp),
            decoration: BoxDecoration(
              color: iconColor.withAlpha(26),
              borderRadius: BorderRadius.circular(6.sp),
            ),
            child: Icon(
              icon,
              color: iconColor,
              size: 16.sp,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  subtitle,
                  style: GoogleFonts.inter(
                    fontSize: 11.sp,
                    color: AppTheme.textSecondaryLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      value: value,
      onChanged: onChanged,
      controlAffinity: ListTileControlAffinity.trailing,
      contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 4.h),
    );
  }

  List<String> _getUniqueCities() {
    return _locations
        .map((location) => location['city'] as String)
        .toSet()
        .toList();
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: 14.sp,
        fontWeight: FontWeight.w500,
        color: AppTheme.textPrimaryLight,
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(label),
        SizedBox(height: 8.h),
        TextFormField(
          controller: controller,
          validator: validator,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Theme.of(context).scaffoldBackgroundColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.primaryLight,
                width: 2,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.errorLight,
              ),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 16.w,
              vertical: 16.h,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildModalInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(label),
        SizedBox(height: 8.h),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Theme.of(context).scaffoldBackgroundColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.primaryLight,
                width: 2,
              ),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 16.w,
              vertical: 16.h,
            ),
          ),
        ),
      ],
    );
  }
}
