import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../theme/app_theme.dart';

class BulkActionsWidget extends StatelessWidget {
  final int selectedCount;
  final VoidCallback onVerifyAll;
  final VoidCallback onClearSelection;

  const BulkActionsWidget({
    super.key,
    required this.selectedCount,
    required this.onVerifyAll,
    required this.onClearSelection,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: AppTheme.primaryLight.withAlpha(26),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.getNeutralColor(true),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // Selection Info
          Expanded(
            child: Text(
              '$selectedCount agent${selectedCount != 1 ? 's' : ''} selected',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: AppTheme.primaryLight,
              ),
            ),
          ),

          // Clear Selection
          TextButton(
            onPressed: onClearSelection,
            child: Text(
              'Clear',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),

          SizedBox(width: 8.w),

          // Bulk Verify Button
          ElevatedButton.icon(
            onPressed: onVerifyAll,
            icon: Icon(
              Icons.verified,
              size: 16.sp,
            ),
            label: Text(
              'Verify All',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.successLight,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              minimumSize: Size.zero,
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
          ),
        ],
      ),
    );
  }
}
