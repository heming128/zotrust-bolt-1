import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/supabase_service.dart';
import './widgets/add_agent_modal_widget.dart';

class AdminAgentManagement extends StatefulWidget {
  const AdminAgentManagement({super.key});

  @override
  State<AdminAgentManagement> createState() => _AdminAgentManagementState();
}

class _AdminAgentManagementState extends State<AdminAgentManagement> {
  final TextEditingController _searchController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService.instance;

  List<Map<String, dynamic>> _agents = [];
  List<Map<String, dynamic>> _filteredAgents = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadAgents();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadAgents() async {
    setState(() => _isLoading = true);

    try {
      // Check if Supabase is properly configured before making API calls
      const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
      const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

      if (supabaseUrl.contains('dummy') ||
          supabaseAnonKey.contains('dummy') ||
          supabaseUrl.contains('your-') ||
          supabaseAnonKey.contains('your-')) {
        setState(() {
          _agents = [];
          _filteredAgents = [];
          _isLoading = false;
        });

        if (kDebugMode) {
          print('Warning: Supabase not configured - using empty agent list');
        }
        return;
      }

      final agents = await _supabaseService.getAllAgentsWithLocationCounts();
      setState(() {
        _agents = agents;
        _filteredAgents = agents;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _agents = [];
        _filteredAgents = [];
        _isLoading = false;
      });

      if (kDebugMode) {
        print('Error loading agents: $e');
      }

      // Only show error toast if it's not a configuration issue
      if (!e.toString().contains('Failed to fetch') &&
          !e.toString().contains('dummy')) {
        _showErrorToast('Failed to load agents: $e');
      }
    }
  }

  void _filterAgents() {
    setState(() {
      _filteredAgents = _agents.where((agent) {
        final matchesSearch = agent['name']
                .toString()
                .toLowerCase()
                .contains(_searchController.text.toLowerCase()) ||
            agent['alias']
                .toString()
                .toLowerCase()
                .contains(_searchController.text.toLowerCase());
        return matchesSearch;
      }).toList();
    });
  }

  Future<void> _updateAgentVerification(String agentId, bool isVerified) async {
    try {
      await _supabaseService.updateAgentVerification(
        agentId: agentId,
        isVerified: isVerified,
      );
      _showSuccessToast('Agent verification updated');
      _loadAgents(); // Refresh data
    } catch (e) {
      _showErrorToast('Failed to update verification: $e');
    }
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  void _showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      backgroundColor: AppTheme.successLight,
      textColor: Colors.white,
    );
  }

  void _showAddAgentModal() {
    // Show configuration warning if Supabase is not set up
    const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
    const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

    if (supabaseUrl.contains('dummy') ||
        supabaseAnonKey.contains('dummy') ||
        supabaseUrl.contains('your-') ||
        supabaseAnonKey.contains('your-')) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Row(
            children: [
              Icon(Icons.warning, color: AppTheme.warningLight),
              SizedBox(width: 12.w),
              Text('Configuration Required'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Supabase database is not configured. To create and manage agents, please:',
                style: GoogleFonts.inter(fontSize: 14.sp),
              ),
              SizedBox(height: 12.h),
              Text(
                '1. Set up your Supabase project\n2. Update SUPABASE_URL in env.json\n3. Update SUPABASE_ANON_KEY in env.json',
                style: GoogleFonts.inter(
                  fontSize: 13.sp,
                  color: AppTheme.textSecondaryLight,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showAddAgentModalAnyway();
              },
              child: Text('Demo Mode'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryLight,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        ),
      );
      return;
    }

    // Normal modal if Supabase is configured
    _showAddAgentModalAnyway();
  }

  void _showAddAgentModalAnyway() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: true,
      enableDrag: true,
      builder: (context) => AddAgentModalWidget(
        onAgentCreated: () {
          Navigator.pop(context);
          _loadAgents(); // Refresh the agent list
          _showSuccessToast('Agent created successfully!');
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Agent Management',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).textTheme.titleLarge?.color,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).iconTheme.color,
            size: 20.sp,
          ),
        ),
        actions: [
          // Add refresh button
          IconButton(
            onPressed: _loadAgents,
            icon: Icon(
              Icons.refresh,
              color: AppTheme.primaryLight,
              size: 24.sp,
            ),
            tooltip: 'Refresh agents',
          ),
        ],
      ),
      body: Column(
        children: [
          // Enhanced Search Bar
          Padding(
            padding: EdgeInsets.all(16.sp),
            child: TextField(
              controller: _searchController,
              onChanged: (_) => _filterAgents(),
              decoration: InputDecoration(
                hintText: 'Search agents by name or alias...',
                prefixIcon: Icon(
                  Icons.search,
                  color: AppTheme.primaryLight,
                  size: 20.sp,
                ),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        onPressed: () {
                          _searchController.clear();
                          _filterAgents();
                        },
                        icon: Icon(Icons.clear, size: 20.sp),
                      )
                    : null,
                filled: true,
                fillColor: Theme.of(context).cardColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.sp),
                  borderSide: BorderSide.none,
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.sp),
                  borderSide: BorderSide(
                    color: AppTheme.primaryLight,
                    width: 2,
                  ),
                ),
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 16.w,
                  vertical: 16.h,
                ),
              ),
            ),
          ),

          // Enhanced Agent Stats
          if (_agents.isNotEmpty)
            Container(
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12.sp),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(13),
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildEnhancedStat(
                    'Total',
                    _agents.length,
                    Icons.people,
                    AppTheme.primaryLight,
                  ),
                  Container(
                    width: 1,
                    height: 40.h,
                    color: AppTheme.getNeutralColor(true),
                  ),
                  _buildEnhancedStat(
                    'Verified',
                    _agents.where((a) => a['is_verified'] == true).length,
                    Icons.verified,
                    AppTheme.successLight,
                  ),
                  Container(
                    width: 1,
                    height: 40.h,
                    color: AppTheme.getNeutralColor(true),
                  ),
                  _buildEnhancedStat(
                    'With Locations',
                    _agents
                        .where((a) => (a['agent_locations'] as List).isNotEmpty)
                        .length,
                    Icons.location_city,
                    AppTheme.warningLight,
                  ),
                ],
              ),
            ),

          SizedBox(height: 16.h),

          // Agent List
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredAgents.isEmpty
                    ? _buildEmptyState()
                    : RefreshIndicator(
                        onRefresh: _loadAgents,
                        child: ListView.builder(
                          padding: EdgeInsets.symmetric(horizontal: 16.w),
                          itemCount: _filteredAgents.length,
                          itemBuilder: (context, index) {
                            final agent = _filteredAgents[index];
                            return _buildEnhancedAgentCard(agent);
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddAgentModal,
        backgroundColor: AppTheme.primaryLight,
        foregroundColor: Colors.white,
        icon: Icon(Icons.add_business),
        label: Text(
          'Add Agent',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  Widget _buildEnhancedStat(
    String label,
    int count,
    IconData icon,
    Color color,
  ) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(8.sp),
          decoration: BoxDecoration(
            color: color.withAlpha(26),
            borderRadius: BorderRadius.circular(8.sp),
          ),
          child: Icon(icon, color: color, size: 20.sp),
        ),
        SizedBox(height: 8.h),
        Text(
          count.toString(),
          style: GoogleFonts.inter(
            fontSize: 20.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 11.sp,
            color: AppTheme.textSecondaryLight,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  Widget _buildEnhancedAgentCard(Map<String, dynamic> agent) {
    final isVerified = agent['is_verified'] == true;
    final locations = agent['agent_locations'] as List;
    final locationCount = locations.length;

    // Get unique cities
    final cities =
        locations.map((loc) => loc['city'].toString()).toSet().toList();

    return Card(
      margin: EdgeInsets.only(bottom: 12.h),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.sp)),
      child: Padding(
        padding: EdgeInsets.all(16.sp),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Row
            Row(
              children: [
                // Agent Avatar with Status
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 24.sp,
                      backgroundColor: AppTheme.primaryLight.withAlpha(26),
                      child: Icon(
                        Icons.person,
                        color: AppTheme.primaryLight,
                        size: 24.sp,
                      ),
                    ),
                    if (isVerified)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: EdgeInsets.all(2.sp),
                          decoration: BoxDecoration(
                            color: AppTheme.successLight,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Theme.of(context).cardColor,
                              width: 2,
                            ),
                          ),
                          child: Icon(
                            Icons.check,
                            color: Colors.white,
                            size: 12.sp,
                          ),
                        ),
                      ),
                  ],
                ),
                SizedBox(width: 16.w),

                // Agent Details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        agent['name'] ?? 'Unknown Agent',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight,
                        ),
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        agent['alias'] ?? '',
                        style: GoogleFonts.inter(
                          fontSize: 13.sp,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                      SizedBox(height: 4.h),
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 8.w,
                              vertical: 2.h,
                            ),
                            decoration: BoxDecoration(
                              color: isVerified
                                  ? AppTheme.successLight.withAlpha(26)
                                  : AppTheme.warningLight.withAlpha(26),
                              borderRadius: BorderRadius.circular(4.sp),
                            ),
                            child: Text(
                              isVerified ? 'Verified' : 'Pending',
                              style: GoogleFonts.inter(
                                fontSize: 10.sp,
                                fontWeight: FontWeight.w500,
                                color: isVerified
                                    ? AppTheme.successLight
                                    : AppTheme.warningLight,
                              ),
                            ),
                          ),
                          SizedBox(width: 8.w),
                          Text(
                            '${agent['agent_type']?.toString().toUpperCase() ?? 'HAWALA'}',
                            style: GoogleFonts.inter(
                              fontSize: 10.sp,
                              color: AppTheme.textSecondaryLight,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // Verification Switch
                Switch(
                  value: isVerified,
                  onChanged: (value) =>
                      _updateAgentVerification(agent['id'], value),
                  activeColor: AppTheme.successLight,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ],
            ),

            SizedBox(height: 12.h),

            // Location Information
            Container(
              padding: EdgeInsets.all(12.sp),
              decoration: BoxDecoration(
                color: AppTheme.primaryLight.withAlpha(13),
                borderRadius: BorderRadius.circular(8.sp),
                border: Border.all(color: AppTheme.primaryLight.withAlpha(51)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.location_city,
                        color: AppTheme.primaryLight,
                        size: 16.sp,
                      ),
                      SizedBox(width: 8.w),
                      Text(
                        'Branch Coverage',
                        style: GoogleFonts.inter(
                          fontSize: 13.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.primaryLight,
                        ),
                      ),
                      Spacer(),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 6.w,
                          vertical: 2.h,
                        ),
                        decoration: BoxDecoration(
                          color: locationCount > 0
                              ? AppTheme.successLight.withAlpha(26)
                              : AppTheme.errorLight.withAlpha(26),
                          borderRadius: BorderRadius.circular(4.sp),
                        ),
                        child: Text(
                          '$locationCount Location${locationCount != 1 ? 's' : ''}',
                          style: GoogleFonts.inter(
                            fontSize: 10.sp,
                            fontWeight: FontWeight.w500,
                            color: locationCount > 0
                                ? AppTheme.successLight
                                : AppTheme.errorLight,
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (cities.isNotEmpty) ...[
                    SizedBox(height: 8.h),
                    Text(
                      'Cities: ${cities.join(', ')}',
                      style: GoogleFonts.inter(
                        fontSize: 11.sp,
                        color: AppTheme.textSecondaryLight,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  if (locationCount == 0)
                    Padding(
                      padding: EdgeInsets.only(top: 4.h),
                      child: Text(
                        'No branch locations configured',
                        style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          color: AppTheme.errorLight,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // Mobile Number (if available)
            if (agent['mobile'] != null &&
                agent['mobile'].toString().isNotEmpty)
              Padding(
                padding: EdgeInsets.only(top: 8.h),
                child: Row(
                  children: [
                    Icon(
                      Icons.phone,
                      color: AppTheme.textSecondaryLight,
                      size: 14.sp,
                    ),
                    SizedBox(width: 6.w),
                    Text(
                      agent['mobile'].toString(),
                      style: GoogleFonts.inter(
                        fontSize: 11.sp,
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(32.sp),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(24.sp),
              decoration: BoxDecoration(
                color: AppTheme.primaryLight.withAlpha(13),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.people_outline,
                size: 64.sp,
                color: AppTheme.primaryLight,
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              'No Agents Found',
              style: GoogleFonts.inter(
                fontSize: 20.sp,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
            ),
            SizedBox(height: 8.h),
            Text(
              _searchController.text.isNotEmpty
                  ? 'No agents match your search criteria.\nTry adjusting your search terms.'
                  : 'Create your first Hawala agent to get started\nwith city-wise branch management.',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: AppTheme.textSecondaryLight,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 32.h),
            ElevatedButton.icon(
              onPressed: _showAddAgentModal,
              icon: Icon(Icons.add_business),
              label: Text('Add New Agent'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryLight,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 24.w, vertical: 16.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.sp),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}