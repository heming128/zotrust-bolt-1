import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class GasFeeWidget extends StatefulWidget {
  final String selectedRole;
  final String amount;

  const GasFeeWidget({
    Key? key,
    required this.selectedRole,
    required this.amount,
  }) : super(key: key);

  @override
  State<GasFeeWidget> createState() => _GasFeeWidgetState();
}

class _GasFeeWidgetState extends State<GasFeeWidget> {
  bool _isLoading = true;
  double _estimatedGasFee = 0.0;
  String _networkStatus = 'normal';

  @override
  void initState() {
    super.initState();
    _estimateGasFee();
  }

  @override
  void didUpdateWidget(GasFeeWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.amount != widget.amount ||
        oldWidget.selectedRole != widget.selectedRole) {
      _estimateGasFee();
    }
  }

  Future<void> _estimateGasFee() async {
    setState(() => _isLoading = true);

    // Simulate gas fee estimation
    await Future.delayed(const Duration(seconds: 1));

    // Mock gas fee calculation based on network congestion
    final baseGasFee = widget.selectedRole == 'selling'
        ? 0.003
        : 0.001; // Selling requires more gas for escrow
    final congestionMultiplier = _getNetworkCongestionMultiplier();

    setState(() {
      _estimatedGasFee = baseGasFee * congestionMultiplier;
      _isLoading = false;
    });
  }

  double _getNetworkCongestionMultiplier() {
    // Mock network congestion logic
    final hour = DateTime.now().hour;
    if (hour >= 8 && hour <= 18) {
      _networkStatus = 'high';
      return 2.5;
    } else if (hour >= 19 && hour <= 22) {
      _networkStatus = 'medium';
      return 1.8;
    } else {
      _networkStatus = 'low';
      return 1.2;
    }
  }

  Color _getNetworkStatusColor() {
    switch (_networkStatus) {
      case 'high':
        return AppTheme.lightTheme.colorScheme.error;
      case 'medium':
        return AppTheme.getWarningColor(true);
      case 'low':
        return AppTheme.getSuccessColor(true);
      default:
        return AppTheme.lightTheme.colorScheme.onSurfaceVariant;
    }
  }

  String _getNetworkStatusText() {
    switch (_networkStatus) {
      case 'high':
        return 'High Congestion';
      case 'medium':
        return 'Medium Congestion';
      case 'low':
        return 'Low Congestion';
      default:
        return 'Normal';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Smart Contract Preview',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                decoration: BoxDecoration(
                  color: _getNetworkStatusColor().withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(1.w),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 2.w,
                      height: 2.w,
                      decoration: BoxDecoration(
                        color: _getNetworkStatusColor(),
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 1.w),
                    Text(
                      _getNetworkStatusText(),
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: _getNetworkStatusColor(),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),

          // Contract Function
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primaryContainer
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(2.w),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'code',
                  color: AppTheme.lightTheme.colorScheme.primary,
                  size: 5.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.selectedRole == 'selling'
                            ? 'lockUSDC()'
                            : 'createTrade()',
                        style:
                            AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.primary,
                          fontFamily: 'monospace',
                        ),
                      ),
                      Text(
                        widget.selectedRole == 'selling'
                            ? 'Lock USDC in escrow contract'
                            : 'Create new trade request',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          SizedBox(height: 2.h),

          // Gas Fee Estimation
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Estimated Gas Fee',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              _isLoading
                  ? SizedBox(
                      width: 4.w,
                      height: 4.w,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.lightTheme.colorScheme.primary,
                        ),
                      ),
                    )
                  : Row(
                      children: [
                        Text(
                          '${_estimatedGasFee.toStringAsFixed(6)} MATIC',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: AppTheme.lightTheme.colorScheme.onSurface,
                            fontFamily: 'monospace',
                          ),
                        ),
                        SizedBox(width: 2.w),
                        GestureDetector(
                          onTap: _estimateGasFee,
                          child: CustomIconWidget(
                            iconName: 'refresh',
                            color: AppTheme.lightTheme.colorScheme.primary,
                            size: 4.w,
                          ),
                        ),
                      ],
                    ),
            ],
          ),

          SizedBox(height: 1.h),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'USD Equivalent',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                '\$${(_estimatedGasFee * 0.85).toStringAsFixed(3)}', // Mock MATIC to USD rate
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),

          SizedBox(height: 2.h),

          // Network Info
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surfaceContainerHighest
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2.w),
            ),
            child: Row(
              children: [
                CustomIconWidget(
                  iconName: 'account_tree',
                  color: AppTheme.getSuccessColor(true),
                  size: 5.w,
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Polygon PoS Network',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      Text(
                        'Fast, low-cost transactions',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color:
                        AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.w),
                  ),
                  child: Text(
                    'Connected',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.getSuccessColor(true),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
