import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../dashboard/widgets/platform_fees_widget.dart';

class AmountInputWidget extends StatefulWidget {
  final TextEditingController controller;
  final String? errorText;
  final Function(String) onChanged;
  final String? selectedRole;

  const AmountInputWidget({
    Key? key,
    required this.controller,
    this.errorText,
    required this.onChanged,
    this.selectedRole,
  }) : super(key: key);

  @override
  State<AmountInputWidget> createState() => _AmountInputWidgetState();
}

class _AmountInputWidgetState extends State<AmountInputWidget> {
  bool _showFeesBreakdown = false;

  @override
  Widget build(BuildContext context) {
    final amount = double.tryParse(widget.controller.text) ?? 0.0;
    final hasValidAmount = amount > 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Trade Amount',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 2.h),

        // Amount Input Field
        Container(
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: widget.errorText != null
                  ? AppTheme.lightTheme.colorScheme.error
                  : AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
            ),
          ),
          child: TextFormField(
            controller: widget.controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              hintText: '0.00',
              hintStyle: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant
                    .withValues(alpha: 0.5),
              ),
              prefixIcon: Padding(
                padding: EdgeInsets.all(4.w),
                child: Text(
                  'USDC',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.lightTheme.primaryColor,
                  ),
                ),
              ),
              suffixIcon: hasValidAmount && widget.selectedRole != null
                  ? IconButton(
                      onPressed: () {
                        setState(() {
                          _showFeesBreakdown = !_showFeesBreakdown;
                        });
                      },
                      icon: CustomIconWidget(
                        iconName: _showFeesBreakdown
                            ? 'visibility_off'
                            : 'visibility',
                        color: AppTheme.lightTheme.primaryColor,
                        size: 5.w,
                      ),
                    )
                  : null,
              border: InputBorder.none,
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 4.w, vertical: 3.h),
            ),
            onChanged: widget.onChanged,
          ),
        ),

        // Error message
        if (widget.errorText != null) ...[
          SizedBox(height: 1.h),
          Text(
            widget.errorText!,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              color: AppTheme.lightTheme.colorScheme.error,
            ),
          ),
        ],

        // Platform Fees Preview
        if (hasValidAmount && widget.selectedRole != null) ...[
          SizedBox(height: 2.h),
          PlatformFeesWidget(
            amount: amount,
            role: widget.selectedRole == 'buying' ? 'buyer' : 'seller',
            isExpanded: _showFeesBreakdown,
            onToggle: () {
              setState(() {
                _showFeesBreakdown = !_showFeesBreakdown;
              });
            },
          ),
        ],

        // Quick amount buttons
        if (!hasValidAmount) ...[
          SizedBox(height: 3.h),
          Text(
            'Quick Select',
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
          SizedBox(height: 1.h),
          Wrap(
            spacing: 2.w,
            children: [50, 100, 250, 500, 1000].map((amount) {
              return GestureDetector(
                onTap: () {
                  widget.controller.text = amount.toString();
                  widget.onChanged(amount.toString());
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color:
                        AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: AppTheme.lightTheme.primaryColor
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  child: Text(
                    '\$${amount}',
                    style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                      color: AppTheme.lightTheme.primaryColor,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }
}
