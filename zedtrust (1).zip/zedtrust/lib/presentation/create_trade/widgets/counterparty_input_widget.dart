import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class CounterpartyInputWidget extends StatefulWidget {
  final TextEditingController controller;
  final String? errorText;
  final Function(String) onChanged;
  final VoidCallback onQrScan;

  const CounterpartyInputWidget({
    Key? key,
    required this.controller,
    this.errorText,
    required this.onChanged,
    required this.onQrScan,
  }) : super(key: key);

  @override
  State<CounterpartyInputWidget> createState() =>
      _CounterpartyInputWidgetState();
}

class _CounterpartyInputWidgetState extends State<CounterpartyInputWidget> {
  bool _isValidAddress = false;

  void _validateAddress(String address) {
    // Basic Ethereum address validation (0x followed by 40 hex characters)
    final isValid = RegExp(r'^0x[a-fA-F0-9]{40}$').hasMatch(address);
    setState(() {
      _isValidAddress = isValid;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: widget.errorText != null
              ? AppTheme.lightTheme.colorScheme.error
              : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Counterparty Wallet Address',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: widget.controller,
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    fontFamily: 'monospace',
                    color: AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                  decoration: InputDecoration(
                    hintText: '0x1234...abcd',
                    hintStyle:
                        AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant
                          .withValues(alpha: 0.5),
                      fontFamily: 'monospace',
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2.w),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.3),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2.w),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.3),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2.w),
                      borderSide: BorderSide(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        width: 2,
                      ),
                    ),
                    suffixIcon: _isValidAddress
                        ? CustomIconWidget(
                            iconName: 'check_circle',
                            color: AppTheme.getSuccessColor(true),
                            size: 6.w,
                          )
                        : null,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 3.w, vertical: 2.h),
                  ),
                  onChanged: (value) {
                    _validateAddress(value);
                    widget.onChanged(value);
                  },
                ),
              ),
              SizedBox(width: 3.w),
              GestureDetector(
                onTap: widget.onQrScan,
                child: Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                  child: CustomIconWidget(
                    iconName: 'qr_code_scanner',
                    color: Colors.white,
                    size: 6.w,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Row(
            children: [
              CustomIconWidget(
                iconName: 'info',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 4.w,
              ),
              SizedBox(width: 2.w),
              Expanded(
                child: Text(
                  'Enter the wallet address of the person you\'re trading with',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],
          ),
          if (widget.errorText != null) ...[
            SizedBox(height: 1.h),
            Text(
              widget.errorText!,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.error,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
