import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/asset_selector_widget.dart';
import './widgets/fiat_selector_widget.dart';
import './widgets/market_chart_widget.dart';
import './widgets/price_input_widget.dart';
import './widgets/price_type_selector_widget.dart';
import './widgets/trade_type_selector_widget.dart';

class SetTypePrice extends StatefulWidget {
  const SetTypePrice({Key? key}) : super(key: key);

  @override
  State<SetTypePrice> createState() => _SetTypePriceState();
}

class _SetTypePriceState extends State<SetTypePrice> {
  String _selectedTradeType = 'Buy';
  String _selectedAsset = 'USDT';
  String _selectedFiat = 'INR';
  bool _isFixedPrice = true;
  String _priceValue = '87.06';

  bool get _isFormValid =>
      _priceValue.isNotEmpty && double.tryParse(_priceValue) != null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      elevation: 0,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          color: AppTheme.lightTheme.colorScheme.onSurface,
          size: 24,
        ),
      ),
      title: Text(
        'Post Ad',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppTheme.lightTheme.primaryColor,
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _buildBody() {
    return SafeArea(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Progress indicator
                  _buildProgressIndicator(),

                  SizedBox(height: 3.h),

                  // Trade Type Selector
                  TradeTypeSelectorWidget(
                    selectedType: _selectedTradeType,
                    onTypeChanged: (type) {
                      setState(() {
                        _selectedTradeType = type;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Asset Selector
                  AssetSelectorWidget(
                    selectedAsset: _selectedAsset,
                    onAssetChanged: (asset) {
                      setState(() {
                        _selectedAsset = asset;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Fiat Selector
                  FiatSelectorWidget(
                    selectedFiat: _selectedFiat,
                    onFiatChanged: (fiat) {
                      setState(() {
                        _selectedFiat = fiat;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Price Type Selector
                  PriceTypeSelectorWidget(
                    isFixed: _isFixedPrice,
                    onPriceTypeChanged: (isFixed) {
                      setState(() {
                        _isFixedPrice = isFixed;
                      });
                    },
                  ),

                  SizedBox(height: 2.h),

                  // Price Input
                  PriceInputWidget(
                    priceValue: _priceValue,
                    onPriceChanged: (price) {
                      setState(() {
                        _priceValue = price;
                      });
                    },
                    fiatCurrency: _selectedFiat,
                  ),

                  SizedBox(height: 2.h),

                  // Market Chart
                  MarketChartWidget(
                    asset: _selectedAsset,
                    fiat: _selectedFiat,
                  ),

                  SizedBox(height: 2.h),
                ],
              ),
            ),
          ),

          // Continue Button
          Container(
            padding: EdgeInsets.all(4.w),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isFormValid ? _onContinuePressed : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: _isFormValid
                      ? AppTheme.lightTheme.primaryColor
                      : AppTheme.getNeutralColor(true),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 0,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Continue',
                      style:
                          AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(width: 2.w),
                    CustomIconWidget(
                      iconName: 'arrow_forward',
                      color: Colors.white,
                      size: 20,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Step 1 of 2',
          style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
        SizedBox(height: 1.h),
        LinearProgressIndicator(
          value: 0.5,
          backgroundColor:
              AppTheme.getNeutralColor(true).withValues(alpha: 0.3),
          valueColor: AlwaysStoppedAnimation<Color>(
            AppTheme.lightTheme.primaryColor,
          ),
        ),
      ],
    );
  }

  void _onContinuePressed() {
    final adData = {
      'tradeType': _selectedTradeType,
      'asset': _selectedAsset,
      'fiat': _selectedFiat,
      'priceType': _isFixedPrice ? 'Fixed' : 'Float',
      'price': _priceValue,
    };

    Navigator.pushNamed(
      context,
      AppRoutes.setAmountMethod,
      arguments: adData,
    );
  }
}
