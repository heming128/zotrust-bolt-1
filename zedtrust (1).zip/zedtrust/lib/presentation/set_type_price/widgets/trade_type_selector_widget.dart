import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TradeTypeSelectorWidget extends StatelessWidget {
  final String selectedType;
  final Function(String) onTypeChanged;

  const TradeTypeSelectorWidget({
    Key? key,
    required this.selectedType,
    required this.onTypeChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'I want to',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.primaryColor,
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => onTypeChanged('Buy'),
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      decoration: BoxDecoration(
                        color: selectedType == 'Buy'
                            ? Colors.green
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'trending_up',
                            color: selectedType == 'Buy'
                                ? Colors.white
                                : Colors.green,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Buy',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: selectedType == 'Buy'
                                  ? Colors.white
                                  : Colors.green,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 1.w),
                Expanded(
                  child: GestureDetector(
                    onTap: () => onTypeChanged('Sell'),
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 2.h),
                      decoration: BoxDecoration(
                        color: selectedType == 'Sell'
                            ? Colors.red
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'trending_down',
                            color: selectedType == 'Sell'
                                ? Colors.white
                                : Colors.red,
                            size: 20,
                          ),
                          SizedBox(width: 2.w),
                          Text(
                            'Sell',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: selectedType == 'Sell'
                                  ? Colors.white
                                  : Colors.red,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 2.h),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: selectedType == 'Buy'
                  ? Colors.green.withValues(alpha: 0.1)
                  : Colors.red.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              selectedType == 'Buy'
                  ? 'You have selected Buy (you want to buy USDT for INR)'
                  : 'You have selected Sell (you want to sell USDT for INR)',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: selectedType == 'Buy' ? Colors.green : Colors.red,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
