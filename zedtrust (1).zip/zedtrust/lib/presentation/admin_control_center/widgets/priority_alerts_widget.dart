import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class PriorityAlertsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> alerts;
  final Function(String alertId) onResolveAlert;

  const PriorityAlertsWidget({
    Key? key,
    required this.alerts,
    required this.onResolveAlert,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF475569)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.priority_high,
                color: Colors.red[400],
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Priority Alerts',
                  style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: alerts.isEmpty
                      ? Colors.green[900]?.withAlpha(77)
                      : Colors.red[900]?.withAlpha(77),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color:
                        alerts.isEmpty ? Colors.green[700]! : Colors.red[700]!,
                  ),
                ),
                child: Text(
                  alerts.isEmpty ? 'All Clear' : '${alerts.length} Pending',
                  style: GoogleFonts.inter(
                    color: alerts.isEmpty ? Colors.green[400] : Colors.red[400],
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (alerts.isEmpty) ...[
            Center(
              child: Column(
                children: [
                  Icon(
                    Icons.check_circle_outline,
                    color: Colors.green[400],
                    size: 48,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'No Priority Alerts',
                    style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: Colors.green[400],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'All systems operating normally',
                    style: GoogleFonts.inter(
                      fontSize: 12,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            ...alerts.map((alert) => _buildAlertItem(alert)).toList(),
          ],
        ],
      ),
    );
  }

  Widget _buildAlertItem(Map<String, dynamic> alert) {
    final priority = alert['priority'] as String;
    final timestamp = alert['timestamp'] as DateTime;

    Color priorityColor;
    IconData priorityIcon;

    switch (priority) {
      case 'critical':
        priorityColor = Colors.red;
        priorityIcon = Icons.error;
        break;
      case 'high':
        priorityColor = Colors.orange;
        priorityIcon = Icons.warning;
        break;
      case 'medium':
        priorityColor = Colors.yellow;
        priorityIcon = Icons.info;
        break;
      default:
        priorityColor = Colors.blue;
        priorityIcon = Icons.notification_important;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: priorityColor.withAlpha(128)),
        boxShadow: priority == 'critical'
            ? [BoxShadow(color: priorityColor.withAlpha(77), blurRadius: 8)]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: priorityColor.withAlpha(51),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  priorityIcon,
                  color: priorityColor,
                  size: 16,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          alert['title'],
                          style: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: priorityColor.withAlpha(51),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: priorityColor),
                          ),
                          child: Text(
                            priority.toUpperCase(),
                            style: GoogleFonts.inter(
                              color: priorityColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      alert['message'],
                      style: GoogleFonts.inter(
                        fontSize: 12,
                        color: Colors.grey[400],
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                children: [
                  Text(
                    _getTimeAgo(timestamp),
                    style: GoogleFonts.inter(
                      fontSize: 10,
                      color: Colors.grey[500],
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 32,
                    child: ElevatedButton(
                      onPressed: () => onResolveAlert(alert['id']),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: priorityColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                        elevation: 0,
                      ),
                      child: Text(
                        _getActionText(alert['action']),
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          if (alert['type'] == 'agent_application') ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue[900]?.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue[700]!),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.person_add,
                    color: Colors.blue[400],
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'New agent verification required - Documents submitted',
                      style: GoogleFonts.inter(
                        color: Colors.blue[400],
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
          if (alert['type'] == 'disputed_trade') ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red[900]?.withAlpha(26),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red[700]!),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.gavel,
                    color: Colors.red[400],
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Trade dispute requires immediate administrative intervention',
                      style: GoogleFonts.inter(
                        color: Colors.red[400],
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getTimeAgo(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }

  String _getActionText(String action) {
    switch (action) {
      case 'review':
        return 'Review';
      case 'resolve':
        return 'Resolve';
      case 'investigate':
        return 'Check';
      default:
        return 'Action';
    }
  }
}
