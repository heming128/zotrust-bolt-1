import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SystemHealthDashboardWidget extends StatelessWidget {
  final Map<String, dynamic> metrics;
  final VoidCallback onRefresh;

  const SystemHealthDashboardWidget({
    Key? key,
    required this.metrics,
    required this.onRefresh,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF475569)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.help_outline,
                color: Colors.blue[400],
                size: 28,
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'System Health Dashboard',
                      style: GoogleFonts.inter(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Real-time platform monitoring and critical metrics',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        color: Colors.grey[400],
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: onRefresh,
                icon: Icon(
                  Icons.refresh,
                  color: Colors.grey[400],
                ),
                tooltip: 'Refresh Metrics',
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Critical Metrics Grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 1.3,
            ),
            itemCount: 4,
            itemBuilder: (context, index) {
              final metricsData = [
                {
                  'title': 'Total Agents',
                  'value': '${metrics['totalAgents'] ?? 0}',
                  'subtitle': 'Active Network',
                  'icon': Icons.people,
                  'color': const Color(0xFF10B981),
                  'trend': '+12%',
                },
                {
                  'title': 'Pending Reviews',
                  'value': '${metrics['pendingVerifications'] ?? 0}',
                  'subtitle': 'Require Attention',
                  'icon': Icons.pending_actions,
                  'color': const Color(0xFFF59E0B),
                  'trend': '-3%',
                },
                {
                  'title': 'Trade Volume',
                  'value': '₹${_formatCurrency(metrics['tradeVolume'] ?? 0)}',
                  'subtitle': 'Today',
                  'icon': Icons.trending_up,
                  'color': const Color(0xFF3B82F6),
                  'trend': '+28%',
                },
                {
                  'title': 'System Status',
                  'value': _getStatusText(metrics['platformStatus']),
                  'subtitle': 'Overall Health',
                  'icon': Icons.health_and_safety,
                  'color': _getStatusColor(metrics['platformStatus']),
                  'trend': '99.9%',
                },
              ];

              return _buildMetricCard(metricsData[index]);
            },
          ),

          const SizedBox(height: 24),

          // Detailed Performance Metrics
          Row(
            children: [
              Expanded(
                child: _buildDetailedMetric(
                  title: 'Active Agents',
                  value: '${metrics['activeAgents'] ?? 0}',
                  total: '${metrics['totalAgents'] ?? 0}',
                  percentage: _calculatePercentage(
                    metrics['activeAgents'] ?? 0,
                    metrics['totalAgents'] ?? 1,
                  ),
                  color: Colors.green,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildDetailedMetric(
                  title: 'Trade Completion',
                  value: '${metrics['completionRate'] ?? 0}%',
                  total: '100%',
                  percentage: (metrics['completionRate'] ?? 0) / 100,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildDetailedMetric(
                  title: 'Response Time',
                  value: '${metrics['avgResponseTime'] ?? 0}ms',
                  total: '< 200ms',
                  percentage: 1.0 -
                      ((metrics['avgResponseTime'] ?? 0) / 200).clamp(0.0, 1.0),
                  color: Colors.purple,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildDetailedMetric(
                  title: 'System Uptime',
                  value: '${metrics['systemUptime'] ?? 0}%',
                  total: '100%',
                  percentage: (metrics['systemUptime'] ?? 0) / 100,
                  color: Colors.indigo,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMetricCard(Map<String, dynamic> metric) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF374151)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                metric['icon'],
                color: metric['color'],
                size: 24,
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: metric['color'].withAlpha(51),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  metric['trend'],
                  style: GoogleFonts.inter(
                    color: metric['color'],
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            metric['value'],
            style: GoogleFonts.inter(
              fontSize: 24,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            metric['title'],
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Colors.grey[300],
            ),
          ),
          Text(
            metric['subtitle'],
            style: GoogleFonts.inter(
              fontSize: 10,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetailedMetric({
    required String title,
    required String value,
    required String total,
    required double percentage,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF374151)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.grey[400],
            ),
          ),

          const SizedBox(height: 8),

          Row(
            children: [
              Text(
                value,
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 4),
              Text(
                '/ $total',
                style: GoogleFonts.inter(
                  fontSize: 12,
                  color: Colors.grey[500],
                ),
              ),
            ],
          ),

          const SizedBox(height: 12),

          // Progress Bar
          Container(
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[800],
              borderRadius: BorderRadius.circular(2),
            ),
            child: FractionallySizedBox(
              alignment: Alignment.centerLeft,
              widthFactor: percentage.clamp(0.0, 1.0),
              child: Container(
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatCurrency(int amount) {
    if (amount >= 10000000) {
      return '${(amount / 10000000).toStringAsFixed(1)}Cr';
    } else if (amount >= 100000) {
      return '${(amount / 100000).toStringAsFixed(1)}L';
    } else if (amount >= 1000) {
      return '${(amount / 1000).toStringAsFixed(1)}K';
    }
    return amount.toString();
  }

  String _getStatusText(dynamic status) {
    switch (status) {
      case 'operational':
        return 'Operational';
      case 'maintenance':
        return 'Maintenance';
      case 'degraded':
        return 'Degraded';
      default:
        return 'Unknown';
    }
  }

  Color _getStatusColor(dynamic status) {
    switch (status) {
      case 'operational':
        return const Color(0xFF10B981);
      case 'maintenance':
        return const Color(0xFFF59E0B);
      case 'degraded':
        return const Color(0xFFEF4444);
      default:
        return Colors.grey;
    }
  }

  double _calculatePercentage(int value, int total) {
    if (total == 0) return 0.0;
    return value / total;
  }
}