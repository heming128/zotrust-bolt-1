import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for advanced filtering options and agent display eligibility rules
class AdvancedFilteringWidget extends StatefulWidget {
  final ValueChanged<Map<String, dynamic>> onFiltersChanged;

  const AdvancedFilteringWidget({
    super.key,
    required this.onFiltersChanged,
  });

  @override
  State<AdvancedFilteringWidget> createState() =>
      _AdvancedFilteringWidgetState();
}

class _AdvancedFilteringWidgetState extends State<AdvancedFilteringWidget> {
  // Completion rate filtering
  bool _enableCompletionThreshold = false;
  double _minCompletionRate = 80.0;

  // Geographic restrictions
  bool _enableGeographicFilters = false;
  List<String> _allowedRegions = [];
  List<String> _blockedRegions = [];

  // Specialization requirements
  bool _enableSpecializationFilters = false;
  List<String> _requiredSpecializations = [];

  // Experience and volume filters
  bool _enableExperienceFilters = false;
  int _minTotalTrades = 10;
  int _minMonthlyTrades = 5;
  int _minAccountAgeDays = 30;

  // Rating and reputation filters
  bool _enableReputationFilters = false;
  double _minRating = 3.5;
  int _maxNegativeReports = 2;
  bool _requireVerifiedIdentity = true;

  // Available options (mock data)
  final List<String> _availableRegions = [
    'North America',
    'Europe',
    'Asia Pacific',
    'South America',
    'Africa',
    'Middle East'
  ];

  final List<String> _availableSpecializations = [
    'Bitcoin Trading',
    'Ethereum Trading',
    'DeFi Tokens',
    'Stablecoins',
    'NFT Trading',
    'Cross-border Remittance',
    'High Volume Trading'
  ];

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.tertiaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.tune,
                    color: colors.tertiary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Advanced Filtering Options',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Set eligibility requirements and restrictions for agent display',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Filter Sections
            _buildFilterSection(
              'Completion Rate Threshold',
              'Set minimum trade completion rate for agent visibility',
              Icons.check_circle_outline,
              _enableCompletionThreshold,
              (value) => setState(() => _enableCompletionThreshold = value),
              colors,
              isDark,
              content: _enableCompletionThreshold
                  ? _buildCompletionRateControls(colors)
                  : null,
            ),

            const SizedBox(height: 20),

            _buildFilterSection(
              'Geographic Restrictions',
              'Control agent visibility by geographic regions',
              Icons.public,
              _enableGeographicFilters,
              (value) => setState(() => _enableGeographicFilters = value),
              colors,
              isDark,
              content: _enableGeographicFilters
                  ? _buildGeographicControls(colors, isDark)
                  : null,
            ),

            const SizedBox(height: 20),

            _buildFilterSection(
              'Specialization Requirements',
              'Filter agents by trading specializations',
              Icons.stars,
              _enableSpecializationFilters,
              (value) => setState(() => _enableSpecializationFilters = value),
              colors,
              isDark,
              content: _enableSpecializationFilters
                  ? _buildSpecializationControls(colors, isDark)
                  : null,
            ),

            const SizedBox(height: 20),

            _buildFilterSection(
              'Experience Filters',
              'Set minimum experience and activity requirements',
              Icons.trending_up,
              _enableExperienceFilters,
              (value) => setState(() => _enableExperienceFilters = value),
              colors,
              isDark,
              content: _enableExperienceFilters
                  ? _buildExperienceControls(colors)
                  : null,
            ),

            const SizedBox(height: 20),

            _buildFilterSection(
              'Reputation Filters',
              'Advanced reputation and trust requirements',
              Icons.verified_user,
              _enableReputationFilters,
              (value) => setState(() => _enableReputationFilters = value),
              colors,
              isDark,
              content: _enableReputationFilters
                  ? _buildReputationControls(colors, isDark)
                  : null,
            ),

            const SizedBox(height: 24),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _resetFilters,
                    child: Text('Reset All Filters'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _applyFilters,
                    child: Text('Apply Filters'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterSection(
    String title,
    String description,
    IconData icon,
    bool isEnabled,
    ValueChanged<bool> onToggle,
    ColorScheme colors,
    bool isDark, {
    Widget? content,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isEnabled
            ? colors.primaryContainer.withAlpha(26)
            : colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isEnabled
              ? colors.primary.withAlpha(77)
              : colors.outline.withAlpha(51),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isEnabled
                      ? colors.primaryContainer
                      : colors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: isEnabled ? colors.primary : colors.onSurfaceVariant,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: isEnabled,
                onChanged: onToggle,
              ),
            ],
          ),
          if (content != null) ...[
            const SizedBox(height: 16),
            content,
          ],
        ],
      ),
    );
  }

  Widget _buildCompletionRateControls(ColorScheme colors) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Minimum Completion Rate',
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: colors.onSurface,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: colors.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${_minCompletionRate.toStringAsFixed(0)}%',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: colors.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Slider(
            value: _minCompletionRate,
            min: 50.0,
            max: 100.0,
            divisions: 10,
            onChanged: (value) => setState(() => _minCompletionRate = value),
          ),
        ],
      ),
    );
  }

  Widget _buildGeographicControls(ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Allowed Regions',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _availableRegions.map((region) {
              final isSelected = _allowedRegions.contains(region);
              return FilterChip(
                label: Text(region),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _allowedRegions.add(region);
                      _blockedRegions.remove(region);
                    } else {
                      _allowedRegions.remove(region);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 16),
          Text(
            'Blocked Regions',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _availableRegions.map((region) {
              final isSelected = _blockedRegions.contains(region);
              return FilterChip(
                label: Text(region),
                selected: isSelected,
                selectedColor: colors.errorContainer,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _blockedRegions.add(region);
                      _allowedRegions.remove(region);
                    } else {
                      _blockedRegions.remove(region);
                    }
                  });
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSpecializationControls(ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Required Specializations',
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _availableSpecializations.map((spec) {
              final isSelected = _requiredSpecializations.contains(spec);
              return FilterChip(
                label: Text(spec),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _requiredSpecializations.add(spec);
                    } else {
                      _requiredSpecializations.remove(spec);
                    }
                  });
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildExperienceControls(ColorScheme colors) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          _buildSliderControl(
            'Minimum Total Trades',
            _minTotalTrades.toDouble(),
            1.0,
            100.0,
            (value) => setState(() => _minTotalTrades = value.round()),
            '$_minTotalTrades trades',
            colors,
          ),
          const SizedBox(height: 16),
          _buildSliderControl(
            'Minimum Monthly Trades',
            _minMonthlyTrades.toDouble(),
            1.0,
            50.0,
            (value) => setState(() => _minMonthlyTrades = value.round()),
            '$_minMonthlyTrades trades/month',
            colors,
          ),
          const SizedBox(height: 16),
          _buildSliderControl(
            'Minimum Account Age',
            _minAccountAgeDays.toDouble(),
            1.0,
            365.0,
            (value) => setState(() => _minAccountAgeDays = value.round()),
            '$_minAccountAgeDays days',
            colors,
          ),
        ],
      ),
    );
  }

  Widget _buildReputationControls(ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          _buildSliderControl(
            'Minimum Rating',
            _minRating,
            1.0,
            5.0,
            (value) => setState(() => _minRating = value),
            '${_minRating.toStringAsFixed(1)} ⭐',
            colors,
          ),
          const SizedBox(height: 16),
          _buildSliderControl(
            'Maximum Negative Reports',
            _maxNegativeReports.toDouble(),
            0.0,
            10.0,
            (value) => setState(() => _maxNegativeReports = value.round()),
            '$_maxNegativeReports reports',
            colors,
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Require Verified Identity',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                  ),
                ),
              ),
              Switch(
                value: _requireVerifiedIdentity,
                onChanged: (value) =>
                    setState(() => _requireVerifiedIdentity = value),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSliderControl(
    String label,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
    String displayValue,
    ColorScheme colors,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              label,
              style: GoogleFonts.inter(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: colors.onSurface,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                displayValue,
                style: GoogleFonts.inter(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: colors.primary,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Slider(
          value: value,
          min: min,
          max: max,
          divisions: (max - min).round(),
          onChanged: onChanged,
        ),
      ],
    );
  }

  void _resetFilters() {
    setState(() {
      _enableCompletionThreshold = false;
      _minCompletionRate = 80.0;
      _enableGeographicFilters = false;
      _allowedRegions.clear();
      _blockedRegions.clear();
      _enableSpecializationFilters = false;
      _requiredSpecializations.clear();
      _enableExperienceFilters = false;
      _minTotalTrades = 10;
      _minMonthlyTrades = 5;
      _minAccountAgeDays = 30;
      _enableReputationFilters = false;
      _minRating = 3.5;
      _maxNegativeReports = 2;
      _requireVerifiedIdentity = true;
    });
    _applyFilters();
  }

  void _applyFilters() {
    final filters = <String, dynamic>{
      'completionThreshold': {
        'enabled': _enableCompletionThreshold,
        'minRate': _minCompletionRate,
      },
      'geographic': {
        'enabled': _enableGeographicFilters,
        'allowedRegions': _allowedRegions,
        'blockedRegions': _blockedRegions,
      },
      'specialization': {
        'enabled': _enableSpecializationFilters,
        'required': _requiredSpecializations,
      },
      'experience': {
        'enabled': _enableExperienceFilters,
        'minTotalTrades': _minTotalTrades,
        'minMonthlyTrades': _minMonthlyTrades,
        'minAccountAge': _minAccountAgeDays,
      },
      'reputation': {
        'enabled': _enableReputationFilters,
        'minRating': _minRating,
        'maxReports': _maxNegativeReports,
        'requireVerification': _requireVerifiedIdentity,
      },
    };

    widget.onFiltersChanged(filters);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle,
                color: AppTheme.getSuccessColor(
                    Theme.of(context).brightness == Brightness.light)),
            const SizedBox(width: 12),
            Text('Advanced filters applied successfully'),
          ],
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
