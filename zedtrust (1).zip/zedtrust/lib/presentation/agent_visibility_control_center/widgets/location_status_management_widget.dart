import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for managing location status and visibility per city/branch
class LocationStatusManagementWidget extends StatefulWidget {
  final List<String> selectedLocationIds;
  final ValueChanged<List<String>> onSelectionChanged;

  const LocationStatusManagementWidget({
    super.key,
    required this.selectedLocationIds,
    required this.onSelectionChanged,
  });

  @override
  State<LocationStatusManagementWidget> createState() =>
      _LocationStatusManagementWidgetState();
}

class _LocationStatusManagementWidgetState
    extends State<LocationStatusManagementWidget> {
  String _filterCity = 'all';
  String _filterStatus = 'all';

  // Mock data - replace with Supabase query
  final List<Map<String, dynamic>> _locations = [
    {
      'id': '1',
      'city': 'New York',
      'branch': 'Manhattan Central',
      'address': '123 Wall Street',
      'isActive': true,
      'agentCount': 8,
      'activeAgents': 6,
      'lastUpdated': '2 hours ago',
      'visibleInP2P': true,
    },
    {
      'id': '2',
      'city': 'New York',
      'branch': 'Brooklyn Heights',
      'address': '456 Atlantic Ave',
      'isActive': false,
      'agentCount': 4,
      'activeAgents': 2,
      'lastUpdated': '3 days ago',
      'visibleInP2P': false,
    },
    {
      'id': '3',
      'city': 'Los Angeles',
      'branch': 'Downtown',
      'address': '789 Spring Street',
      'isActive': true,
      'agentCount': 12,
      'activeAgents': 10,
      'lastUpdated': '1 hour ago',
      'visibleInP2P': true,
    },
    {
      'id': '4',
      'city': 'Chicago',
      'branch': 'Loop District',
      'address': '321 LaSalle Street',
      'isActive': true,
      'agentCount': 6,
      'activeAgents': 5,
      'lastUpdated': '30 minutes ago',
      'visibleInP2P': true,
    },
  ];

  List<String> get _cities {
    final cities = _locations.map((l) => l['city'] as String).toSet().toList();
    cities.sort();
    return ['all', ...cities];
  }

  List<Map<String, dynamic>> get _filteredLocations {
    return _locations.where((location) {
      final matchesCity =
          _filterCity == 'all' || location['city'] == _filterCity;
      final matchesStatus = _filterStatus == 'all' ||
          (_filterStatus == 'active' && location['isActive']) ||
          (_filterStatus == 'inactive' && !location['isActive']) ||
          (_filterStatus == 'visible' && location['visibleInP2P']) ||
          (_filterStatus == 'hidden' && !location['visibleInP2P']);

      return matchesCity && matchesStatus;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.secondaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.location_city,
                    color: colors.secondary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Location Status Management',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'City-wise breakdown of active/inactive locations with bulk status updates',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Filter Controls
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _filterCity,
                    decoration: InputDecoration(
                      labelText: 'Filter by City',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    items: _cities
                        .map((city) => DropdownMenuItem(
                              value: city,
                              child: Text(city == 'all' ? 'All Cities' : city),
                            ))
                        .toList(),
                    onChanged: (value) => setState(() => _filterCity = value!),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _filterStatus,
                    decoration: InputDecoration(
                      labelText: 'Filter by Status',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    items: [
                      DropdownMenuItem(
                          value: 'all', child: Text('All Statuses')),
                      DropdownMenuItem(
                          value: 'active', child: Text('Active Only')),
                      DropdownMenuItem(
                          value: 'inactive', child: Text('Inactive Only')),
                      DropdownMenuItem(
                          value: 'visible', child: Text('Visible in P2P')),
                      DropdownMenuItem(
                          value: 'hidden', child: Text('Hidden from P2P')),
                    ],
                    onChanged: (value) =>
                        setState(() => _filterStatus = value!),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // City Summary Cards
            _buildCitySummary(colors, isDark),

            const SizedBox(height: 24),

            // Location List Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: colors.surfaceContainerLow,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Checkbox(
                    value: widget.selectedLocationIds.length ==
                        _filteredLocations.length,
                    onChanged: (value) {
                      if (value == true) {
                        widget.onSelectionChanged(_filteredLocations
                            .map((l) => l['id'] as String)
                            .toList());
                      } else {
                        widget.onSelectionChanged([]);
                      }
                    },
                  ),
                  Expanded(
                    flex: 3,
                    child: Text('Location',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text('Status',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text('Agents',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text('Visibility',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Actions',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Location List
            Container(
              constraints: const BoxConstraints(maxHeight: 400),
              child: ListView.builder(
                itemCount: _filteredLocations.length,
                itemBuilder: (context, index) {
                  final location = _filteredLocations[index];
                  return _buildLocationRow(location, colors, isDark);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCitySummary(ColorScheme colors, bool isDark) {
    // Group locations by city
    final cityGroups = <String, List<Map<String, dynamic>>>{};
    for (final location in _locations) {
      final city = location['city'] as String;
      cityGroups.putIfAbsent(city, () => []).add(location);
    }

    return Wrap(
      spacing: 16,
      runSpacing: 12,
      children: cityGroups.entries.map((entry) {
        final city = entry.key;
        final locations = entry.value;
        final activeCount = locations.where((l) => l['isActive']).length;
        final totalAgents =
            locations.fold(0, (sum, l) => sum + (l['agentCount'] as int));

        return Container(
          width: 200,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: colors.surfaceContainerLow,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: colors.outline.withAlpha(51)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                city,
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '$activeCount/${locations.length}',
                        style: GoogleFonts.inter(
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: colors.primary,
                        ),
                      ),
                      Text(
                        'Active Locations',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        '$totalAgents',
                        style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: colors.secondary,
                        ),
                      ),
                      Text(
                        'Total Agents',
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildLocationRow(
      Map<String, dynamic> location, ColorScheme colors, bool isDark) {
    final isSelected = widget.selectedLocationIds.contains(location['id']);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isSelected
            ? colors.secondaryContainer.withAlpha(51)
            : colors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? colors.secondary.withAlpha(77)
              : colors.outline.withAlpha(51),
        ),
      ),
      child: Row(
        children: [
          Checkbox(
            value: isSelected,
            onChanged: (value) {
              final newSelection =
                  List<String>.from(widget.selectedLocationIds);
              if (value == true) {
                newSelection.add(location['id']);
              } else {
                newSelection.remove(location['id']);
              }
              widget.onSelectionChanged(newSelection);
            },
          ),
          // Location Info
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${location['city']} — ${location['branch']}',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  location['address'],
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Status
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: location['isActive']
                        ? AppTheme.getSuccessColor(isDark).withAlpha(26)
                        : colors.error.withAlpha(26),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    location['isActive'] ? 'Active' : 'Inactive',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: location['isActive']
                          ? AppTheme.getSuccessColor(isDark)
                          : colors.error,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Updated ${location['lastUpdated']}',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Agent Count
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${location['activeAgents']}/${location['agentCount']}',
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: colors.primary,
                  ),
                ),
                Text(
                  'Active/Total',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Visibility Toggle
          Expanded(
            flex: 2,
            child: Row(
              children: [
                Switch(
                  value: location['visibleInP2P'],
                  onChanged: (value) {
                    // TODO: Update visibility in Supabase
                    setState(() {
                      location['visibleInP2P'] = value;
                    });
                  },
                ),
                const SizedBox(width: 8),
                Text(
                  location['visibleInP2P'] ? 'Visible' : 'Hidden',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: location['visibleInP2P']
                        ? colors.secondary
                        : colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Actions
          Expanded(
            flex: 1,
            child: PopupMenuButton<String>(
              icon: Icon(Icons.more_vert, color: colors.onSurfaceVariant),
              onSelected: (action) => _handleLocationAction(action, location),
              itemBuilder: (context) => [
                PopupMenuItem(value: 'edit', child: Text('Edit Location')),
                PopupMenuItem(value: 'activate', child: Text('Toggle Status')),
                PopupMenuItem(value: 'agents', child: Text('Manage Agents')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _handleLocationAction(String action, Map<String, dynamic> location) {
    // TODO: Implement location actions
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Action "$action" for ${location['branch']}'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
