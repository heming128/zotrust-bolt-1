import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


/// Widget for configuring global visibility rules
class VisibilityRulesConfigurationWidget extends StatefulWidget {
  final bool hideUnverified;
  final bool hideInactive;
  final Function(bool? hideUnverified, bool? hideInactive) onRulesChanged;

  const VisibilityRulesConfigurationWidget({
    super.key,
    required this.hideUnverified,
    required this.hideInactive,
    required this.onRulesChanged,
  });

  @override
  State<VisibilityRulesConfigurationWidget> createState() =>
      _VisibilityRulesConfigurationWidgetState();
}

class _VisibilityRulesConfigurationWidgetState
    extends State<VisibilityRulesConfigurationWidget> {
  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.rule,
                    color: colors.primary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Visibility Rules Configuration',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Configure which agents and locations are displayed to users',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Rule Configuration Options
            _buildRuleOption(
              'Hide Unverified Agents',
              'Agents without complete verification will not appear in P2P selection',
              Icons.verified_user,
              widget.hideUnverified,
              (value) => widget.onRulesChanged(value, null),
              colors,
              isDark,
            ),

            const SizedBox(height: 16),

            _buildRuleOption(
              'Hide Inactive Locations',
              'Location branches marked as inactive will be filtered out',
              Icons.location_off,
              widget.hideInactive,
              (value) => widget.onRulesChanged(null, value),
              colors,
              isDark,
            ),

            const SizedBox(height: 24),

            // Impact Preview
            _buildImpactPreview(colors, isDark),
          ],
        ),
      ),
    );
  }

  Widget _buildRuleOption(
    String title,
    String description,
    IconData icon,
    bool value,
    ValueChanged<bool> onChanged,
    ColorScheme colors,
    bool isDark,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: value
              ? colors.primary.withAlpha(77)
              : colors.outline.withAlpha(51),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: value
                  ? colors.primaryContainer
                  : colors.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: value ? colors.primary : colors.onSurfaceVariant,
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  description,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Switch(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildImpactPreview(ColorScheme colors, bool isDark) {
    // Calculate impact based on current settings
    int totalAgents = 32;
    int unverifiedAgents = 8;
    int visibleAgents =
        widget.hideUnverified ? totalAgents - unverifiedAgents : totalAgents;

    int totalLocations = 12;
    int inactiveLocations = 4;
    int visibleLocations = widget.hideInactive
        ? totalLocations - inactiveLocations
        : totalLocations;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.preview,
                color: colors.primary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                'Rules Impact Preview',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildImpactCard(
                  'Visible Agents',
                  visibleAgents.toString(),
                  '$unverifiedAgents hidden',
                  Icons.people,
                  colors,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildImpactCard(
                  'Visible Locations',
                  visibleLocations.toString(),
                  '$inactiveLocations hidden',
                  Icons.location_on,
                  colors,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildImpactCard(
    String title,
    String count,
    String subtitle,
    IconData icon,
    ColorScheme colors,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: colors.primary,
            size: 24,
          ),
          const SizedBox(height: 8),
          Text(
            count,
            style: GoogleFonts.inter(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: colors.primary,
            ),
          ),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: colors.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
