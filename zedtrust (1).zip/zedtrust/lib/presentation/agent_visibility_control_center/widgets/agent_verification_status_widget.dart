import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for managing agent verification status and visibility
class AgentVerificationStatusWidget extends StatefulWidget {
  final List<String> selectedAgentIds;
  final ValueChanged<List<String>> onSelectionChanged;

  const AgentVerificationStatusWidget({
    super.key,
    required this.selectedAgentIds,
    required this.onSelectionChanged,
  });

  @override
  State<AgentVerificationStatusWidget> createState() =>
      _AgentVerificationStatusWidgetState();
}

class _AgentVerificationStatusWidgetState
    extends State<AgentVerificationStatusWidget> {
  String _filterStatus = 'all';
  String _searchQuery = '';

  // Mock data - replace with Supabase query
  final List<Map<String, dynamic>> _agents = [
    {
      'id': '1',
      'name': 'Sarah Johnson',
      'email': 'sarah@example.com',
      'verified': true,
      'rating': 4.8,
      'completionRate': 98,
      'lastActive': '2 hours ago',
      'location': 'New York',
      'visibleInP2P': true,
    },
    {
      'id': '2',
      'name': 'Mike Chen',
      'email': 'mike@example.com',
      'verified': false,
      'rating': 4.2,
      'completionRate': 85,
      'lastActive': '1 day ago',
      'location': 'Los Angeles',
      'visibleInP2P': false,
    },
    {
      'id': '3',
      'name': 'Emma Wilson',
      'email': 'emma@example.com',
      'verified': true,
      'rating': 4.9,
      'completionRate': 100,
      'lastActive': '30 minutes ago',
      'location': 'Chicago',
      'visibleInP2P': true,
    },
  ];

  List<Map<String, dynamic>> get _filteredAgents {
    return _agents.where((agent) {
      final matchesSearch = _searchQuery.isEmpty ||
          agent['name'].toLowerCase().contains(_searchQuery.toLowerCase()) ||
          agent['email'].toLowerCase().contains(_searchQuery.toLowerCase()) ||
          agent['location'].toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesFilter = _filterStatus == 'all' ||
          (_filterStatus == 'verified' && agent['verified']) ||
          (_filterStatus == 'unverified' && !agent['verified']) ||
          (_filterStatus == 'visible' && agent['visibleInP2P']) ||
          (_filterStatus == 'hidden' && !agent['visibleInP2P']);

      return matchesSearch && matchesFilter;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.primaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.verified_user,
                    color: colors.primary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Agent Verification Status',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Manage agent visibility based on verification status',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Search and Filter Bar
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Search agents by name, email, or location...',
                      prefixIcon:
                          Icon(Icons.search, color: colors.onSurfaceVariant),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    onChanged: (value) => setState(() => _searchQuery = value),
                  ),
                ),
                const SizedBox(width: 16),
                DropdownButton<String>(
                  value: _filterStatus,
                  items: [
                    DropdownMenuItem(value: 'all', child: Text('All Agents')),
                    DropdownMenuItem(
                        value: 'verified', child: Text('Verified Only')),
                    DropdownMenuItem(
                        value: 'unverified', child: Text('Unverified Only')),
                    DropdownMenuItem(
                        value: 'visible', child: Text('Visible in P2P')),
                    DropdownMenuItem(
                        value: 'hidden', child: Text('Hidden from P2P')),
                  ],
                  onChanged: (value) => setState(() => _filterStatus = value!),
                  borderRadius: BorderRadius.circular(12),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Agent List Header
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: colors.surfaceContainerLow,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Checkbox(
                    value: widget.selectedAgentIds.length ==
                        _filteredAgents.length,
                    onChanged: (value) {
                      if (value == true) {
                        widget.onSelectionChanged(_filteredAgents
                            .map((a) => a['id'] as String)
                            .toList());
                      } else {
                        widget.onSelectionChanged([]);
                      }
                    },
                  ),
                  Expanded(
                    flex: 3,
                    child: Text('Agent',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text('Verification',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 2,
                    child: Text('P2P Display',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                  Expanded(
                    flex: 1,
                    child: Text('Actions',
                        style: GoogleFonts.inter(
                            fontSize: 12, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Agent List
            Container(
              constraints: const BoxConstraints(maxHeight: 400),
              child: ListView.builder(
                itemCount: _filteredAgents.length,
                itemBuilder: (context, index) {
                  final agent = _filteredAgents[index];
                  return _buildAgentRow(agent, colors, isDark);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAgentRow(
      Map<String, dynamic> agent, ColorScheme colors, bool isDark) {
    final isSelected = widget.selectedAgentIds.contains(agent['id']);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:
            isSelected ? colors.primaryContainer.withAlpha(51) : colors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isSelected
              ? colors.primary.withAlpha(77)
              : colors.outline.withAlpha(51),
        ),
      ),
      child: Row(
        children: [
          Checkbox(
            value: isSelected,
            onChanged: (value) {
              final newSelection = List<String>.from(widget.selectedAgentIds);
              if (value == true) {
                newSelection.add(agent['id']);
              } else {
                newSelection.remove(agent['id']);
              }
              widget.onSelectionChanged(newSelection);
            },
          ),
          // Agent Info
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  agent['name'],
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${agent['location']} • ${agent['lastActive']}',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Verification Status
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: agent['verified']
                            ? AppTheme.getSuccessColor(isDark).withAlpha(26)
                            : AppTheme.getWarningColor(isDark).withAlpha(26),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        agent['verified'] ? 'Verified' : 'Pending',
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: agent['verified']
                              ? AppTheme.getSuccessColor(isDark)
                              : AppTheme.getWarningColor(isDark),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  '${agent['rating']} ⭐ • ${agent['completionRate']}%',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w400,
                    color: colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // P2P Display Status
          Expanded(
            flex: 2,
            child: Row(
              children: [
                Switch(
                  value: agent['visibleInP2P'],
                  onChanged: (value) {
                    // TODO: Update visibility in Supabase
                    setState(() {
                      agent['visibleInP2P'] = value;
                    });
                  },
                ),
                const SizedBox(width: 8),
                Text(
                  agent['visibleInP2P'] ? 'Visible' : 'Hidden',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: agent['visibleInP2P']
                        ? colors.primary
                        : colors.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          // Actions
          Expanded(
            flex: 1,
            child: PopupMenuButton<String>(
              icon: Icon(Icons.more_vert, color: colors.onSurfaceVariant),
              onSelected: (action) => _handleAgentAction(action, agent),
              itemBuilder: (context) => [
                PopupMenuItem(value: 'view', child: Text('View Profile')),
                PopupMenuItem(value: 'verify', child: Text('Verify Agent')),
                PopupMenuItem(value: 'hide', child: Text('Hide from P2P')),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _handleAgentAction(String action, Map<String, dynamic> agent) {
    // TODO: Implement agent actions
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Action "$action" for ${agent['name']}'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
