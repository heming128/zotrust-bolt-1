import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../../theme/app_theme.dart';

/// Widget for analytics dashboard showing impact of visibility rules
class AnalyticsDashboardWidget extends StatefulWidget {
  final String selectedRange;
  final ValueChanged<String> onRangeChanged;

  const AnalyticsDashboardWidget({
    super.key,
    required this.selectedRange,
    required this.onRangeChanged,
  });

  @override
  State<AnalyticsDashboardWidget> createState() =>
      _AnalyticsDashboardWidgetState();
}

class _AnalyticsDashboardWidgetState extends State<AnalyticsDashboardWidget> {
  // Mock data for analytics
  final Map<String, Map<String, dynamic>> _analyticsData = {
    '7days': {
      'tradeVolume': [120, 135, 128, 142, 158, 145, 162],
      'userExperience': [4.2, 4.3, 4.1, 4.4, 4.5, 4.3, 4.6],
      'agentUtilization': [68, 72, 65, 75, 78, 73, 80],
      'visibilityImpact': {'positive': 23, 'negative': 5, 'neutral': 8},
    },
    '30days': {
      'tradeVolume': [
        2100,
        2250,
        2180,
        2320,
        2450,
        2380,
        2520,
        2490,
        2650,
        2580,
        2720,
        2890,
        2840,
        2950,
        3020
      ],
      'userExperience': [
        4.1,
        4.2,
        4.0,
        4.3,
        4.4,
        4.2,
        4.5,
        4.4,
        4.6,
        4.5,
        4.7,
        4.6,
        4.8,
        4.7,
        4.9
      ],
      'agentUtilization': [
        65,
        68,
        62,
        70,
        73,
        68,
        75,
        72,
        78,
        74,
        80,
        77,
        82,
        79,
        85
      ],
      'visibilityImpact': {'positive': 89, 'negative': 12, 'neutral': 24},
    },
    '90days': {
      'tradeVolume': [
        6200,
        6500,
        6800,
        7100,
        7400,
        7200,
        7600,
        7800,
        8100,
        8300,
        8600,
        8400
      ],
      'userExperience': [
        3.9,
        4.0,
        4.1,
        4.2,
        4.3,
        4.1,
        4.4,
        4.5,
        4.6,
        4.7,
        4.8,
        4.9
      ],
      'agentUtilization': [60, 63, 65, 68, 70, 67, 72, 74, 77, 79, 82, 85],
      'visibilityImpact': {'positive': 234, 'negative': 28, 'neutral': 67},
    },
  };

  Map<String, dynamic> get _currentData =>
      _analyticsData[widget.selectedRange] ?? _analyticsData['7days']!;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.tertiaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.analytics,
                    color: colors.tertiary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Analytics Dashboard',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Impact of visibility rules on trade volume and user experience',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                DropdownButton<String>(
                  value: widget.selectedRange,
                  items: [
                    DropdownMenuItem(
                        value: '7days', child: Text('Last 7 Days')),
                    DropdownMenuItem(
                        value: '30days', child: Text('Last 30 Days')),
                    DropdownMenuItem(
                        value: '90days', child: Text('Last 90 Days')),
                  ],
                  onChanged: (value) => widget.onRangeChanged(value!),
                  borderRadius: BorderRadius.circular(12),
                ),
              ],
            ),

            const SizedBox(height: 32),

            // Key Metrics Cards
            _buildMetricsRow(colors, isDark),

            const SizedBox(height: 32),

            // Charts Section
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 2,
                  child: _buildTradeVolumeChart(colors, isDark),
                ),
                const SizedBox(width: 24),
                Expanded(
                  child: _buildVisibilityImpactChart(colors, isDark),
                ),
              ],
            ),

            const SizedBox(height: 32),

            // Additional Metrics
            Row(
              children: [
                Expanded(
                  child: _buildUserExperienceChart(colors, isDark),
                ),
                const SizedBox(width: 24),
                Expanded(
                  child: _buildAgentUtilizationChart(colors, isDark),
                ),
              ],
            ),

            const SizedBox(height: 32),

            // Insights and Recommendations
            _buildInsightsSection(colors, isDark),
          ],
        ),
      ),
    );
  }

  Widget _buildMetricsRow(ColorScheme colors, bool isDark) {
    final tradeData = _currentData['tradeVolume'] as List<int>;
    final experienceData = _currentData['userExperience'] as List<double>;
    final utilizationData = _currentData['agentUtilization'] as List<int>;

    final avgTrades =
        (tradeData.reduce((a, b) => a + b) / tradeData.length).round();
    final avgExperience =
        experienceData.reduce((a, b) => a + b) / experienceData.length;
    final avgUtilization =
        (utilizationData.reduce((a, b) => a + b) / utilizationData.length)
            .round();
    final totalRuleChanges =
        (_currentData['visibilityImpact'] as Map<String, int>)
            .values
            .reduce((a, b) => a + b);

    return Row(
      children: [
        Expanded(
          child: _buildMetricCard(
            'Avg Daily Trades',
            avgTrades.toString(),
            '+12%',
            Icons.trending_up,
            colors.primary,
            colors,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildMetricCard(
            'User Experience',
            avgExperience.toStringAsFixed(1),
            '+0.3',
            Icons.star,
            AppTheme.getSuccessColor(isDark),
            colors,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildMetricCard(
            'Agent Utilization',
            '${avgUtilization}%',
            '+8%',
            Icons.people,
            colors.secondary,
            colors,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _buildMetricCard(
            'Rule Changes',
            totalRuleChanges.toString(),
            'Period total',
            Icons.rule,
            colors.tertiary,
            colors,
          ),
        ),
      ],
    );
  }

  Widget _buildMetricCard(
    String title,
    String value,
    String change,
    IconData icon,
    Color accentColor,
    ColorScheme colors,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accentColor.withAlpha(26),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(icon, color: accentColor, size: 20),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.getSuccessColor(
                          colors.brightness == Brightness.light)
                      .withAlpha(26),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  change,
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.getSuccessColor(
                        colors.brightness == Brightness.light),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 24,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: colors.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradeVolumeChart(ColorScheme colors, bool isDark) {
    final data = _currentData['tradeVolume'] as List<int>;

    return Container(
      height: 300,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Trade Volume Trend',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: LineChart(
              LineChartData(
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(show: false),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: data
                        .asMap()
                        .entries
                        .map(
                            (e) => FlSpot(e.key.toDouble(), e.value.toDouble()))
                        .toList(),
                    isCurved: true,
                    color: colors.primary,
                    barWidth: 3,
                    dotData: FlDotData(show: false),
                    belowBarData: BarAreaData(
                      show: true,
                      color: colors.primary.withAlpha(26),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVisibilityImpactChart(ColorScheme colors, bool isDark) {
    final data = _currentData['visibilityImpact'] as Map<String, int>;

    return Container(
      height: 300,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Visibility Impact',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: PieChart(
              PieChartData(
                sections: [
                  PieChartSectionData(
                    color: AppTheme.getSuccessColor(isDark),
                    value: data['positive']!.toDouble(),
                    title: '${data['positive']}',
                    radius: 50,
                    titleStyle: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  ),
                  PieChartSectionData(
                    color: colors.error,
                    value: data['negative']!.toDouble(),
                    title: '${data['negative']}',
                    radius: 50,
                    titleStyle: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  ),
                  PieChartSectionData(
                    color: colors.outline,
                    value: data['neutral']!.toDouble(),
                    title: '${data['neutral']}',
                    radius: 50,
                    titleStyle: GoogleFonts.inter(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white),
                  ),
                ],
                centerSpaceRadius: 40,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildLegendItem(
                  'Positive', AppTheme.getSuccessColor(isDark), colors),
              _buildLegendItem('Negative', colors.error, colors),
              _buildLegendItem('Neutral', colors.outline, colors),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildUserExperienceChart(ColorScheme colors, bool isDark) {
    final data = _currentData['userExperience'] as List<double>;

    return Container(
      height: 250,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'User Experience Rating',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: BarChart(
              BarChartData(
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(show: false),
                borderData: FlBorderData(show: false),
                barGroups: data.asMap().entries.map((e) {
                  return BarChartGroupData(
                    x: e.key,
                    barRods: [
                      BarChartRodData(
                        toY: e.value,
                        color: AppTheme.getSuccessColor(isDark),
                        width: 16,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  );
                }).toList(),
                maxY: 5.0,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAgentUtilizationChart(ColorScheme colors, bool isDark) {
    final data = _currentData['agentUtilization'] as List<int>;

    return Container(
      height: 250,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Agent Utilization Rate',
            style: GoogleFonts.inter(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: LineChart(
              LineChartData(
                gridData: FlGridData(show: false),
                titlesData: FlTitlesData(show: false),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  LineChartBarData(
                    spots: data
                        .asMap()
                        .entries
                        .map(
                            (e) => FlSpot(e.key.toDouble(), e.value.toDouble()))
                        .toList(),
                    isCurved: true,
                    color: colors.secondary,
                    barWidth: 3,
                    dotData: FlDotData(show: true),
                  ),
                ],
                maxY: 100,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color, ColorScheme colors) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(6),
          ),
        ),
        const SizedBox(width: 6),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 12,
            fontWeight: FontWeight.w400,
            color: colors.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildInsightsSection(ColorScheme colors, bool isDark) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colors.primaryContainer.withAlpha(26),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.primary.withAlpha(77)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.lightbulb_outline,
                color: colors.primary,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Insights & Recommendations',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 16,
            runSpacing: 12,
            children: [
              _buildInsightCard(
                'Trade Volume Up 12%',
                'Visibility rules are improving trade matching efficiency',
                Icons.trending_up,
                AppTheme.getSuccessColor(isDark),
                colors,
              ),
              _buildInsightCard(
                'User Experience Improved',
                'Better agent quality leads to higher satisfaction ratings',
                Icons.star,
                colors.primary,
                colors,
              ),
              _buildInsightCard(
                'Agent Utilization Optimized',
                'More efficient distribution of trade requests across agents',
                Icons.people,
                colors.secondary,
                colors,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInsightCard(
    String title,
    String description,
    IconData icon,
    Color accentColor,
    ColorScheme colors,
  ) {
    return Container(
      width: 280,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: accentColor, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: colors.onSurface,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: colors.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}