import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../theme/app_theme.dart';

/// Widget for configuring automatic hiding rules based on rating, activity, etc.
class AutoHideRulesWidget extends StatefulWidget {
  final bool enabled;
  final ValueChanged<Map<String, dynamic>> onSettingsChanged;

  const AutoHideRulesWidget({
    super.key,
    required this.enabled,
    required this.onSettingsChanged,
  });

  @override
  State<AutoHideRulesWidget> createState() => _AutoHideRulesWidgetState();
}

class _AutoHideRulesWidgetState extends State<AutoHideRulesWidget> {
  // Rule settings
  bool _hideByRating = false;
  double _minRating = 3.0;

  bool _hideByCompletion = false;
  double _minCompletionRate = 70.0;

  bool _hideByInactivity = false;
  int _maxInactiveDays = 30;

  bool _hideByReports = false;
  int _maxReports = 3;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors.tertiaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.auto_fix_high,
                    color: colors.tertiary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Auto-Hide Rules Configuration',
                        style: GoogleFonts.inter(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Automatically hide agents based on performance and activity metrics',
                        style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: colors.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: widget.enabled,
                  onChanged: (value) => _updateSettings({'enabled': value}),
                ),
              ],
            ),

            const SizedBox(height: 24),

            // Rules Configuration (only show if enabled)
            if (widget.enabled) ...[
              _buildRuleSection(
                'Rating-Based Hiding',
                'Hide agents with ratings below threshold',
                Icons.star,
                _hideByRating,
                (value) => setState(() => _hideByRating = value),
                colors,
                isDark,
                additionalWidget: _hideByRating
                    ? _buildSliderControl(
                        'Minimum Rating',
                        _minRating,
                        1.0,
                        5.0,
                        (value) => setState(() => _minRating = value),
                        '${_minRating.toStringAsFixed(1)} ⭐',
                        colors,
                      )
                    : null,
              ),

              const SizedBox(height: 20),

              _buildRuleSection(
                'Completion Rate Hiding',
                'Hide agents with low trade completion rates',
                Icons.check_circle,
                _hideByCompletion,
                (value) => setState(() => _hideByCompletion = value),
                colors,
                isDark,
                additionalWidget: _hideByCompletion
                    ? _buildSliderControl(
                        'Minimum Completion Rate',
                        _minCompletionRate,
                        0.0,
                        100.0,
                        (value) => setState(() => _minCompletionRate = value),
                        '${_minCompletionRate.toStringAsFixed(0)}%',
                        colors,
                      )
                    : null,
              ),

              const SizedBox(height: 20),

              _buildRuleSection(
                'Inactivity-Based Hiding',
                'Hide agents who have been inactive for extended periods',
                Icons.schedule,
                _hideByInactivity,
                (value) => setState(() => _hideByInactivity = value),
                colors,
                isDark,
                additionalWidget: _hideByInactivity
                    ? _buildSliderControl(
                        'Maximum Inactive Days',
                        _maxInactiveDays.toDouble(),
                        1.0,
                        90.0,
                        (value) =>
                            setState(() => _maxInactiveDays = value.round()),
                        '$_maxInactiveDays days',
                        colors,
                      )
                    : null,
              ),

              const SizedBox(height: 20),

              _buildRuleSection(
                'Report-Based Hiding',
                'Hide agents with multiple user reports',
                Icons.report,
                _hideByReports,
                (value) => setState(() => _hideByReports = value),
                colors,
                isDark,
                additionalWidget: _hideByReports
                    ? _buildSliderControl(
                        'Maximum Reports',
                        _maxReports.toDouble(),
                        1.0,
                        10.0,
                        (value) => setState(() => _maxReports = value.round()),
                        '$_maxReports reports',
                        colors,
                      )
                    : null,
              ),

              const SizedBox(height: 24),

              // Preview Impact
              _buildRuleImpact(colors, isDark),

              const SizedBox(height: 24),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _resetToDefaults,
                      child: Text('Reset to Defaults'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _saveRules,
                      child: Text('Apply Rules'),
                    ),
                  ),
                ],
              ),
            ] else ...[
              // Disabled state message
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: colors.surfaceContainerLow,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.auto_fix_off,
                      color: colors.onSurfaceVariant,
                      size: 48,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Auto-Hide Rules Disabled',
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Enable auto-hide rules to automatically manage agent visibility based on performance metrics',
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildRuleSection(
    String title,
    String description,
    IconData icon,
    bool isEnabled,
    ValueChanged<bool> onToggle,
    ColorScheme colors,
    bool isDark, {
    Widget? additionalWidget,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isEnabled
            ? colors.primaryContainer.withAlpha(26)
            : colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isEnabled
              ? colors.primary.withAlpha(77)
              : colors.outline.withAlpha(51),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: isEnabled
                      ? colors.primaryContainer
                      : colors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  icon,
                  color: isEnabled ? colors.primary : colors.onSurfaceVariant,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: GoogleFonts.inter(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: colors.onSurface,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      description,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: colors.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Switch(
                value: isEnabled,
                onChanged: onToggle,
              ),
            ],
          ),
          if (additionalWidget != null) ...[
            const SizedBox(height: 16),
            additionalWidget,
          ],
        ],
      ),
    );
  }

  Widget _buildSliderControl(
    String label,
    double value,
    double min,
    double max,
    ValueChanged<double> onChanged,
    String displayValue,
    ColorScheme colors,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: colors.onSurface,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: colors.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  displayValue,
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: colors.primary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: (max - min).round(),
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _buildRuleImpact(ColorScheme colors, bool isDark) {
    // Calculate estimated impact
    int affectedAgents = 0;
    if (_hideByRating) affectedAgents += 3;
    if (_hideByCompletion) affectedAgents += 5;
    if (_hideByInactivity) affectedAgents += 8;
    if (_hideByReports) affectedAgents += 2;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surfaceContainerLow,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.outline.withAlpha(51)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.analytics_outlined,
                color: colors.primary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Text(
                'Estimated Rule Impact',
                style: GoogleFonts.inter(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: colors.onSurface,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildImpactCard(
                  'Agents Affected',
                  affectedAgents.toString(),
                  'Will be hidden',
                  Icons.help_outline,
                  colors,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildImpactCard(
                  'Visible Agents',
                  (32 - affectedAgents).toString(),
                  'Will remain visible',
                  Icons.people,
                  colors,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildImpactCard(
    String title,
    String count,
    String subtitle,
    IconData icon,
    ColorScheme colors,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Icon(icon, color: colors.primary, size: 24),
          const SizedBox(height: 8),
          Text(
            count,
            style: GoogleFonts.inter(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: colors.primary,
            ),
          ),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: colors.onSurface,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: colors.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  void _updateSettings(Map<String, dynamic> settings) {
    widget.onSettingsChanged({
      'enabled': widget.enabled,
      'hideByRating': _hideByRating,
      'minRating': _minRating,
      'hideByCompletion': _hideByCompletion,
      'minCompletionRate': _minCompletionRate,
      'hideByInactivity': _hideByInactivity,
      'maxInactiveDays': _maxInactiveDays,
      'hideByReports': _hideByReports,
      'maxReports': _maxReports,
      ...settings,
    });
  }

  void _resetToDefaults() {
    setState(() {
      _hideByRating = false;
      _minRating = 3.0;
      _hideByCompletion = false;
      _minCompletionRate = 70.0;
      _hideByInactivity = false;
      _maxInactiveDays = 30;
      _hideByReports = false;
      _maxReports = 3;
    });
    _updateSettings({});
  }

  void _saveRules() {
    _updateSettings({});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle,
                color: AppTheme.getSuccessColor(
                    Theme.of(context).brightness == Brightness.light)),
            const SizedBox(width: 12),
            Text('Auto-hide rules applied successfully'),
          ],
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
