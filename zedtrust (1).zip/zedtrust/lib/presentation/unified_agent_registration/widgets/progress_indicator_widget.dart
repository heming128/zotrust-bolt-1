import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';

class ProgressIndicatorWidget extends StatelessWidget {
  final int currentStep;
  final int totalSteps;
  final String stepTitle;

  const ProgressIndicatorWidget({
    super.key,
    required this.currentStep,
    required this.totalSteps,
    required this.stepTitle,
  });

  @override
  Widget build(BuildContext context) {
    final progress = currentStep / totalSteps;

    return Container(
      padding: EdgeInsets.all(20.sp),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight.withAlpha(77),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Step counter and title
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                stepTitle,
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: 12.w,
                  vertical: 6.h,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight.withAlpha(26),
                  borderRadius: BorderRadius.circular(20.sp),
                ),
                child: Text(
                  'Step $currentStep of $totalSteps',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.primaryLight,
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: 16.h),

          // Progress bar
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Progress',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                  Text(
                    '${(progress * 100).toInt()}%',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.primaryLight,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8.h),
              ClipRRect(
                borderRadius: BorderRadius.circular(4.sp),
                child: LinearProgressIndicator(
                  value: progress,
                  backgroundColor: AppTheme.getNeutralColor(true),
                  valueColor:
                      AlwaysStoppedAnimation<Color>(AppTheme.primaryLight),
                  minHeight: 6.h,
                ),
              ),
            ],
          ),

          SizedBox(height: 12.h),

          // Completion status
          if (currentStep == totalSteps)
            Row(
              children: [
                Icon(
                  Icons.check_circle,
                  color: AppTheme.successLight,
                  size: 16.sp,
                ),
                SizedBox(width: 8.w),
                Text(
                  'Ready to register agent',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: AppTheme.successLight,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            )
          else
            Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: AppTheme.warningLight,
                  size: 16.sp,
                ),
                SizedBox(width: 8.w),
                Text(
                  'Fill all required fields to continue',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: AppTheme.warningLight,
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
