import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';

class AddressManagementWidget extends StatelessWidget {
  final List<Map<String, dynamic>> locations;
  final VoidCallback onAddLocation;
  final Function(int) onRemoveLocation;

  const AddressManagementWidget({
    super.key,
    required this.locations,
    required this.onAddLocation,
    required this.onRemoveLocation,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header with Add Button
        Row(
          children: [
            Expanded(
              child: Text(
                'Cities & Locations',
                style: GoogleFonts.inter(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimaryLight,
                ),
              ),
            ),
            TextButton.icon(
              onPressed: onAddLocation,
              icon: Icon(
                Icons.add_location_alt,
                size: 18.sp,
                color: AppTheme.primaryLight,
              ),
              label: Text(
                'Add City',
                style: GoogleFonts.inter(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.primaryLight,
                ),
              ),
            ),
          ],
        ),

        SizedBox(height: 12.h),

        // Locations List or Empty State
        if (locations.isEmpty)
          _buildEmptyState(context)
        else
          ...locations.asMap().entries.map((entry) {
            final index = entry.key;
            final location = entry.value;
            return _buildLocationCard(context, location, index);
          }).toList(),
      ],
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24.sp),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(12.sp),
        border: Border.all(
          color: AppTheme.getNeutralColor(true),
          style: BorderStyle.solid,
        ),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16.sp),
            decoration: BoxDecoration(
              color: AppTheme.primaryLight.withAlpha(26),
              borderRadius: BorderRadius.circular(50.sp),
            ),
            child: Icon(
              Icons.add_location_alt_outlined,
              size: 32.sp,
              color: AppTheme.primaryLight,
            ),
          ),
          SizedBox(height: 16.h),
          Text(
            'No locations added yet',
            style: GoogleFonts.inter(
              fontSize: 16.sp,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimaryLight,
            ),
          ),
          SizedBox(height: 8.h),
          Text(
            'Add cities where the agent operates.\nEach city can have multiple specific locations.',
            style: GoogleFonts.inter(
              fontSize: 14.sp,
              color: AppTheme.textSecondaryLight,
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20.h),
          ElevatedButton.icon(
            onPressed: onAddLocation,
            icon: Icon(
              Icons.add,
              size: 18.sp,
            ),
            label: Text(
              'Add First Location',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryLight,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(
                horizontal: 20.w,
                vertical: 12.h,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8.sp),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationCard(
      BuildContext context, Map<String, dynamic> location, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: AppTheme.primaryLight.withAlpha(26),
        borderRadius: BorderRadius.circular(12.sp),
        border: Border.all(
          color: AppTheme.primaryLight.withAlpha(51),
        ),
      ),
      child: Column(
        children: [
          // Header with city and remove button
          Container(
            padding: EdgeInsets.all(16.sp),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8.sp),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryLight,
                    borderRadius: BorderRadius.circular(8.sp),
                  ),
                  child: Icon(
                    Icons.location_city,
                    color: Colors.white,
                    size: 20.sp,
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${location['area']}, ${location['city']}',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight,
                        ),
                      ),
                      if (location['operational_hours'] != null)
                        Text(
                          location['operational_hours'],
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => onRemoveLocation(index),
                  icon: Icon(
                    Icons.remove_circle_outline,
                    color: AppTheme.errorLight,
                    size: 24.sp,
                  ),
                  tooltip: 'Remove location',
                ),
              ],
            ),
          ),

          // Location details
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16.sp),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(128),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(12.sp),
                bottomRight: Radius.circular(12.sp),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.location_on,
                      size: 16.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                    SizedBox(width: 6.w),
                    Expanded(
                      child: Text(
                        location['address_line'] ?? 'No address provided',
                        style: GoogleFonts.inter(
                          fontSize: 13.sp,
                          color: AppTheme.textPrimaryLight,
                          height: 1.3,
                        ),
                      ),
                    ),
                  ],
                ),
                if (location['landmark'] != null &&
                    location['landmark'].toString().isNotEmpty)
                  Padding(
                    padding: EdgeInsets.only(top: 8.h),
                    child: Row(
                      children: [
                        Icon(
                          Icons.place,
                          size: 16.sp,
                          color: AppTheme.textSecondaryLight,
                        ),
                        SizedBox(width: 6.w),
                        Expanded(
                          child: Text(
                            'Near ${location['landmark']}',
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              color: AppTheme.textSecondaryLight,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
