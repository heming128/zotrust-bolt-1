import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';

class AgentTypeSelectorWidget extends StatelessWidget {
  final String selectedType;
  final List<String> agentTypes;
  final ValueChanged<String> onTypeChanged;

  const AgentTypeSelectorWidget({
    super.key,
    required this.selectedType,
    required this.agentTypes,
    required this.onTypeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: BorderRadius.circular(12.sp),
        border: Border.all(
          color: AppTheme.getNeutralColor(true),
        ),
      ),
      child: Column(
        children: agentTypes.map((type) {
          final isSelected = type == selectedType;
          return Container(
            decoration: BoxDecoration(
              color: isSelected ? AppTheme.primaryLight.withAlpha(26) : null,
              borderRadius: BorderRadius.circular(12.sp),
            ),
            child: RadioListTile<String>(
              title: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8.sp),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppTheme.primaryLight
                          : AppTheme.primaryLight.withAlpha(26),
                      borderRadius: BorderRadius.circular(8.sp),
                    ),
                    child: Icon(
                      _getTypeIcon(type),
                      color: isSelected ? Colors.white : AppTheme.primaryLight,
                      size: 16.sp,
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      type,
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w500,
                        color: isSelected
                            ? AppTheme.primaryLight
                            : AppTheme.textPrimaryLight,
                      ),
                    ),
                  ),
                ],
              ),
              value: type,
              groupValue: selectedType,
              onChanged: (value) {
                if (value != null) {
                  onTypeChanged(value);
                }
              },
              controlAffinity: ListTileControlAffinity.trailing,
              activeColor: AppTheme.primaryLight,
            ),
          );
        }).toList(),
      ),
    );
  }

  IconData _getTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'cash exchange':
        return Icons.payments;
      case 'bank transfer':
        return Icons.account_balance;
      case 'mobile money':
        return Icons.phone_android;
      case 'multi-service':
        return Icons.business;
      default:
        return Icons.account_balance_wallet;
    }
  }
}
