import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../core/services/supabase_service.dart';
import '../../theme/app_theme.dart';
import './widgets/progress_indicator_widget.dart';

class UnifiedAgentRegistration extends StatefulWidget {
  const UnifiedAgentRegistration({super.key});

  @override
  State<UnifiedAgentRegistration> createState() =>
      _UnifiedAgentRegistrationState();
}

class _UnifiedAgentRegistrationState extends State<UnifiedAgentRegistration>
    with TickerProviderStateMixin {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _branchNameController = TextEditingController();
  final TextEditingController _aliasController = TextEditingController();
  final TextEditingController _mobileController = TextEditingController();
  final TextEditingController _secondaryContactController =
      TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService.instance;

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  bool _isLoading = false;
  bool _isVerified = false;
  double _rating = 4.0;
  String _selectedAgentType = 'Cash Exchange';
  int _capacityLimit = 100000;
  double _commissionRate = 2.5;
  List<String> _serviceSpecializations = [];

  // Location management
  List<Map<String, dynamic>> _locations = [];
  List<String> _availableCities = [];

  final List<String> _hawalaAgentTypes = [
    'Cash Exchange',
    'Bank Transfer',
    'Mobile Money',
    'Multi-Service'
  ];

  final List<String> _availableSpecializations = [
    'International Transfers',
    'Domestic Transfers',
    'Business Payments',
    'Personal Remittance',
    'Bulk Transactions',
    '24/7 Service'
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    );
    _loadAvailableCities();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _nameController.dispose();
    _branchNameController.dispose();
    _aliasController.dispose();
    _mobileController.dispose();
    _secondaryContactController.dispose();
    _emailController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadAvailableCities() async {
    try {
      final cities = await _supabaseService.getAvailableCities();
      setState(() {
        _availableCities = cities;
      });
    } catch (e) {
      if (mounted) {
        _showErrorToast('Failed to load cities');
      }
    }
  }

  Future<void> _registerAgent() async {
    if (!_formKey.currentState!.validate()) return;

    if (_locations.isEmpty) {
      _showErrorToast('Please add at least one location');
      return;
    }

    if (_branchNameController.text.trim().isEmpty) {
      _showErrorToast('Branch name is required');
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Create agent with comprehensive data
      final agent = await _supabaseService.createAgent(
        name: _nameController.text.trim(),
        alias: _aliasController.text.trim(),
        mobileNumber: _mobileController.text.trim(),
        agentType: _selectedAgentType.toLowerCase().replaceAll(' ', '_'),
        rating: _rating,
        isVerified: _isVerified,
        notes: _notesController.text.trim(),
      );

      // Create agent locations
      await _supabaseService.createAgentLocationsBatch(
        agentId: agent['id'],
        locations: _locations,
      );

      _showSuccessToast(
        'Agent "${_nameController.text.trim()}" registered successfully with ${_locations.length} location(s)',
      );

      // Navigate back or clear form
      _showRegistrationSuccessModal(agent['id']);
    } catch (e) {
      _showErrorToast('Failed to register agent: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _addLocation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildAddLocationModal(),
    );
  }

  void _removeLocation(int index) {
    setState(() {
      _locations.removeAt(index);
    });
  }

  Widget _buildAddLocationModal() {
    final cityController = TextEditingController();
    final areaController = TextEditingController();
    final addressController = TextEditingController();
    final landmarkController = TextEditingController();
    String? selectedCity;
    String _operationalHours = '9:00 AM - 6:00 PM';

    return StatefulBuilder(
      builder: (context, setModalState) {
        return DraggableScrollableSheet(
          initialChildSize: 0.8,
          maxChildSize: 0.95,
          minChildSize: 0.5,
          builder: (context, scrollController) {
            return Container(
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius:
                    BorderRadius.vertical(top: Radius.circular(20.sp)),
              ),
              child: Column(
                children: [
                  // Handle bar
                  Container(
                    margin: EdgeInsets.only(top: 12.h),
                    width: 40.w,
                    height: 4.h,
                    decoration: BoxDecoration(
                      color: AppTheme.getNeutralColor(true),
                      borderRadius: BorderRadius.circular(2.sp),
                    ),
                  ),

                  // Header
                  Padding(
                    padding: EdgeInsets.all(20.sp),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Add Location',
                            style: GoogleFonts.inter(
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(context),
                          icon: Icon(
                            Icons.close,
                            size: 24.sp,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Form Content
                  Expanded(
                    child: ListView(
                      controller: scrollController,
                      padding: EdgeInsets.symmetric(horizontal: 20.w),
                      children: [
                        // City Selection
                        _buildLabel('City'),
                        SizedBox(height: 8.h),
                        Container(
                          decoration: BoxDecoration(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(12.sp),
                            border: Border.all(
                              color: AppTheme.getNeutralColor(true),
                            ),
                          ),
                          child: DropdownButtonFormField<String>(
                            value: selectedCity,
                            decoration: InputDecoration(
                              hintText: 'Select city',
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 16.w,
                                vertical: 16.h,
                              ),
                            ),
                            items: _availableCities.map((city) {
                              return DropdownMenuItem(
                                value: city,
                                child: Text(city),
                              );
                            }).toList(),
                            onChanged: (value) {
                              setModalState(() {
                                selectedCity = value;
                                cityController.text = value ?? '';
                              });
                            },
                          ),
                        ),

                        SizedBox(height: 20.h),

                        // Area
                        _buildModalInputField(
                          controller: areaController,
                          label: 'Area/Location Name',
                          hint: 'e.g., Ring Road, Fort Area, Station Road',
                        ),

                        SizedBox(height: 20.h),

                        // Full Address
                        _buildModalInputField(
                          controller: addressController,
                          label: 'Complete Address',
                          hint: 'Shop/Office number, Building, Street...',
                          maxLines: 3,
                        ),

                        SizedBox(height: 20.h),

                        // Landmark
                        _buildModalInputField(
                          controller: landmarkController,
                          label: 'Landmark (Optional)',
                          hint: 'Near Metro Station, Opposite Mall...',
                        ),

                        SizedBox(height: 20.h),

                        // Operational Hours
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildLabel('Operational Hours'),
                            SizedBox(height: 8.h),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16.w, vertical: 16.h),
                              decoration: BoxDecoration(
                                color:
                                    Theme.of(context).scaffoldBackgroundColor,
                                borderRadius: BorderRadius.circular(12.sp),
                                border: Border.all(
                                  color: AppTheme.getNeutralColor(true),
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.access_time,
                                    color: AppTheme.textSecondaryLight,
                                    size: 20.sp,
                                  ),
                                  SizedBox(width: 12.w),
                                  Text(
                                    _operationalHours,
                                    style: GoogleFonts.inter(
                                      fontSize: 14.sp,
                                      color: AppTheme.textPrimaryLight,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 40.h),

                        // Add Location Button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (selectedCity != null &&
                                  areaController.text.trim().isNotEmpty &&
                                  addressController.text.trim().isNotEmpty) {
                                setState(() {
                                  _locations.add({
                                    'city': selectedCity!,
                                    'area': areaController.text.trim(),
                                    'display_alias': areaController.text.trim(),
                                    'address_line':
                                        addressController.text.trim(),
                                    'landmark': landmarkController.text.trim(),
                                    'operational_hours': _operationalHours,
                                    'is_active': true,
                                  });
                                });
                                Navigator.pop(context);
                              } else {
                                Fluttertoast.showToast(
                                  msg: 'Please fill all required fields',
                                  backgroundColor: AppTheme.errorLight,
                                  textColor: Colors.white,
                                );
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primaryLight,
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(vertical: 16.h),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.sp),
                              ),
                            ),
                            child: Text(
                              'Add Location',
                              style: GoogleFonts.inter(
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),

                        SizedBox(height: 20.h),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showRegistrationSuccessModal(String agentId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16.sp),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.successLight.withAlpha(26),
                borderRadius: BorderRadius.circular(50.sp),
              ),
              child: Icon(
                Icons.check,
                color: AppTheme.successLight,
                size: 32.sp,
              ),
            ),
            SizedBox(height: 16.h),
            Text(
              'Agent Registered Successfully!',
              style: GoogleFonts.inter(
                fontSize: 18.sp,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 8.h),
            Text(
              'Agent ID: $agentId',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: AppTheme.textSecondaryLight,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context); // Close dialog
                      _resetForm();
                    },
                    child: Text('Add Another'),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context); // Close dialog
                      Navigator.pop(context); // Go back to management
                    },
                    child: Text('Done'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _resetForm() {
    _nameController.clear();
    _branchNameController.clear();
    _aliasController.clear();
    _mobileController.clear();
    _secondaryContactController.clear();
    _emailController.clear();
    _notesController.clear();
    setState(() {
      _selectedAgentType = 'Cash Exchange';
      _rating = 4.0;
      _isVerified = false;
      _capacityLimit = 100000;
      _commissionRate = 2.5;
      _locations.clear();
      _serviceSpecializations.clear();
    });
  }

  void _showErrorToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      backgroundColor: AppTheme.errorLight,
      textColor: Colors.white,
    );
  }

  void _showSuccessToast(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      backgroundColor: AppTheme.successLight,
      textColor: Colors.white,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Add New Agent',
          style: GoogleFonts.inter(
            fontSize: 18.sp,
            fontWeight: FontWeight.w600,
            color: Theme.of(context).textTheme.titleLarge?.color,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).iconTheme.color,
            size: 20.sp,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          SizedBox(width: 8.w),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SafeArea(
          child: Column(
            children: [
              // Progress Indicator
              ProgressIndicatorWidget(
                currentStep: 1,
                totalSteps: 1,
                stepTitle: 'Complete Registration',
              ),

              // Form Content
              Expanded(
                child: Form(
                  key: _formKey,
                  child: ListView(
                    padding: EdgeInsets.all(20.sp),
                    children: [
                      // Agent Details Section
                      _buildSectionHeader('Agent Details', Icons.person),
                      SizedBox(height: 16.h),

                      // Hawala Agent Type Selector
                      _buildLabel('Hawala Agent Type'),
                      SizedBox(height: 8.h),
                      Container(
                        decoration: BoxDecoration(
                          color: isDark
                              ? AppTheme.cardDark
                              : AppTheme.surfaceLight,
                          borderRadius: BorderRadius.circular(12.sp),
                          border: Border.all(
                            color: AppTheme.getNeutralColor(!isDark),
                          ),
                        ),
                        child: DropdownButtonFormField<String>(
                          value: _selectedAgentType,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(
                              horizontal: 16.w,
                              vertical: 16.h,
                            ),
                          ),
                          items: _hawalaAgentTypes.map((type) {
                            return DropdownMenuItem(
                              value: type,
                              child: Row(
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(6.sp),
                                    decoration: BoxDecoration(
                                      color:
                                          AppTheme.primaryLight.withAlpha(26),
                                      borderRadius: BorderRadius.circular(6.sp),
                                    ),
                                    child: Icon(
                                      Icons.account_balance,
                                      color: AppTheme.primaryLight,
                                      size: 16.sp,
                                    ),
                                  ),
                                  SizedBox(width: 12.w),
                                  Text(type),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() => _selectedAgentType = value!);
                          },
                        ),
                      ),

                      SizedBox(height: 20.h),

                      // Branch Name
                      _buildInputField(
                        controller: _branchNameController,
                        label: 'Branch Name',
                        hint: 'e.g., Ring Road Branch, Fort Branch',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Branch name is required';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // Agent Name
                      _buildInputField(
                        controller: _nameController,
                        label: 'Agent Name',
                        hint: 'e.g., Rajnikant Aagnya Hawala',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Agent name is required';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // Display Alias
                      _buildInputField(
                        controller: _aliasController,
                        label: 'Display Alias',
                        hint: 'e.g., Rajni Network',
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Display alias is required';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 32.h),

                      // Contact Information Section
                      _buildSectionHeader('Contact Information', Icons.phone),
                      SizedBox(height: 16.h),

                      // Mobile Number
                      _buildInputField(
                        controller: _mobileController,
                        label: 'Mobile Number',
                        hint: 'e.g., +91 9876543210',
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[0-9+\-\s\(\)]')),
                        ],
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Mobile number is required';
                          }
                          if (value.replaceAll(RegExp(r'[^0-9]'), '').length <
                              10) {
                            return 'Please enter a valid mobile number';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 20.h),

                      // Secondary Contact
                      _buildInputField(
                        controller: _secondaryContactController,
                        label: 'Secondary Contact (Optional)',
                        hint: 'e.g., +91 9876543211',
                        keyboardType: TextInputType.phone,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(
                              RegExp(r'[0-9+\-\s\(\)]')),
                        ],
                      ),

                      SizedBox(height: 20.h),

                      // Email
                      _buildInputField(
                        controller: _emailController,
                        label: 'Email Address (Optional)',
                        hint: 'e.g., agent@example.com',
                        keyboardType: TextInputType.emailAddress,
                      ),

                      SizedBox(height: 32.h),

                      // Address Management Section
                      _buildSectionHeader(
                          'Address Management', Icons.location_on),
                      SizedBox(height: 16.h),

                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'Cities & Locations',
                              style: GoogleFonts.inter(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w500,
                                color: AppTheme.textPrimaryLight,
                              ),
                            ),
                          ),
                          TextButton.icon(
                            onPressed: _addLocation,
                            icon: Icon(
                              Icons.add,
                              size: 18.sp,
                              color: AppTheme.primaryLight,
                            ),
                            label: Text(
                              'Add City',
                              style: GoogleFonts.inter(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w500,
                                color: AppTheme.primaryLight,
                              ),
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 8.h),

                      // Locations List
                      if (_locations.isEmpty)
                        Container(
                          padding: EdgeInsets.all(20.sp),
                          decoration: BoxDecoration(
                            color: Theme.of(context).scaffoldBackgroundColor,
                            borderRadius: BorderRadius.circular(12.sp),
                            border: Border.all(
                              color: AppTheme.getNeutralColor(true),
                            ),
                          ),
                          child: Column(
                            children: [
                              Icon(
                                Icons.add_location_alt_outlined,
                                size: 32.sp,
                                color: AppTheme.textSecondaryLight,
                              ),
                              SizedBox(height: 8.h),
                              Text(
                                'No locations added yet',
                                style: GoogleFonts.inter(
                                  fontSize: 14.sp,
                                  color: AppTheme.textSecondaryLight,
                                ),
                              ),
                              SizedBox(height: 4.h),
                              Text(
                                'Add cities and their specific locations',
                                style: GoogleFonts.inter(
                                  fontSize: 12.sp,
                                  color: AppTheme.textSecondaryLight,
                                ),
                              ),
                            ],
                          ),
                        )
                      else
                        ...List.generate(_locations.length, (index) {
                          final location = _locations[index];
                          return Container(
                            margin: EdgeInsets.only(bottom: 8.h),
                            padding: EdgeInsets.all(12.sp),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryLight.withAlpha(26),
                              borderRadius: BorderRadius.circular(12.sp),
                              border: Border.all(
                                color: AppTheme.primaryLight.withAlpha(51),
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(8.sp),
                                  decoration: BoxDecoration(
                                    color: AppTheme.primaryLight,
                                    borderRadius: BorderRadius.circular(8.sp),
                                  ),
                                  child: Icon(
                                    Icons.location_city,
                                    color: Colors.white,
                                    size: 16.sp,
                                  ),
                                ),
                                SizedBox(width: 12.w),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${location['area']}, ${location['city']}',
                                        style: GoogleFonts.inter(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      SizedBox(height: 2.h),
                                      Text(
                                        location['address_line'],
                                        style: GoogleFonts.inter(
                                          fontSize: 12.sp,
                                          color: AppTheme.textSecondaryLight,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  onPressed: () => _removeLocation(index),
                                  icon: Icon(
                                    Icons.remove_circle,
                                    color: AppTheme.errorLight,
                                    size: 20.sp,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),

                      SizedBox(height: 32.h),

                      // Advanced Settings Section
                      _buildSectionHeader('Advanced Settings', Icons.settings),
                      SizedBox(height: 16.h),

                      // Agent Capacity Limits
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Agent Capacity Limit'),
                          SizedBox(height: 8.h),
                          Container(
                            padding: EdgeInsets.all(16.sp),
                            decoration: BoxDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(12.sp),
                              border: Border.all(
                                color: AppTheme.getNeutralColor(true),
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Daily Limit: ₹${_capacityLimit.toStringAsFixed(0)}',
                                      style: GoogleFonts.inter(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Text(
                                      'Max: ₹500,000',
                                      style: GoogleFonts.inter(
                                        fontSize: 12.sp,
                                        color: AppTheme.textSecondaryLight,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 8.h),
                                Slider(
                                  value: _capacityLimit.toDouble(),
                                  min: 50000.0,
                                  max: 500000.0,
                                  divisions: 45,
                                  onChanged: (value) {
                                    setState(
                                        () => _capacityLimit = value.toInt());
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 20.h),

                      // Commission Rate
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Commission Rate Configuration'),
                          SizedBox(height: 8.h),
                          Container(
                            padding: EdgeInsets.all(16.sp),
                            decoration: BoxDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(12.sp),
                              border: Border.all(
                                color: AppTheme.getNeutralColor(true),
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Commission: ${_commissionRate.toStringAsFixed(1)}%',
                                      style: GoogleFonts.inter(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Text(
                                      'Range: 0.5% - 5.0%',
                                      style: GoogleFonts.inter(
                                        fontSize: 12.sp,
                                        color: AppTheme.textSecondaryLight,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 8.h),
                                Slider(
                                  value: _commissionRate,
                                  min: 0.5,
                                  max: 5.0,
                                  divisions: 45,
                                  onChanged: (value) {
                                    setState(() => _commissionRate = value);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 20.h),

                      // Service Specialization
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Service Specialization'),
                          SizedBox(height: 8.h),
                          Wrap(
                            spacing: 8.w,
                            runSpacing: 8.h,
                            children:
                                _availableSpecializations.map((specialization) {
                              final isSelected = _serviceSpecializations
                                  .contains(specialization);
                              return FilterChip(
                                label: Text(
                                  specialization,
                                  style: GoogleFonts.inter(
                                    fontSize: 12.sp,
                                    color: isSelected
                                        ? Colors.white
                                        : AppTheme.textPrimaryLight,
                                  ),
                                ),
                                selected: isSelected,
                                onSelected: (selected) {
                                  setState(() {
                                    if (selected) {
                                      _serviceSpecializations
                                          .add(specialization);
                                    } else {
                                      _serviceSpecializations
                                          .remove(specialization);
                                    }
                                  });
                                },
                                selectedColor: AppTheme.primaryLight,
                                backgroundColor:
                                    Theme.of(context).scaffoldBackgroundColor,
                              );
                            }).toList(),
                          ),
                        ],
                      ),

                      SizedBox(height: 20.h),

                      // Initial Rating
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Initial Agent Rating'),
                          SizedBox(height: 8.h),
                          Container(
                            padding: EdgeInsets.all(16.sp),
                            decoration: BoxDecoration(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              borderRadius: BorderRadius.circular(12.sp),
                              border: Border.all(
                                color: AppTheme.getNeutralColor(true),
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Rating: ${_rating.toStringAsFixed(1)}/5.0',
                                      style: GoogleFonts.inter(
                                        fontSize: 14.sp,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Row(
                                      children: List.generate(5, (index) {
                                        return Icon(
                                          index < _rating.round()
                                              ? Icons.star
                                              : Icons.star_border,
                                          color: AppTheme.warningLight,
                                          size: 20.sp,
                                        );
                                      }),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 8.h),
                                Slider(
                                  value: _rating,
                                  min: 0.0,
                                  max: 5.0,
                                  divisions: 50,
                                  onChanged: (value) {
                                    setState(() => _rating = value);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      SizedBox(height: 20.h),

                      // Verification Status
                      Container(
                        padding: EdgeInsets.all(16.sp),
                        decoration: BoxDecoration(
                          color: Theme.of(context).scaffoldBackgroundColor,
                          borderRadius: BorderRadius.circular(12.sp),
                          border: Border.all(
                            color: AppTheme.getNeutralColor(true),
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Verification Status',
                                    style: GoogleFonts.inter(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.w500,
                                      color: AppTheme.textPrimaryLight,
                                    ),
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    _isVerified
                                        ? 'Agent will be immediately available'
                                        : 'Agent will require manual verification',
                                    style: GoogleFonts.inter(
                                      fontSize: 12.sp,
                                      color: AppTheme.textSecondaryLight,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Switch(
                              value: _isVerified,
                              onChanged: (value) {
                                setState(() => _isVerified = value);
                              },
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 20.h),

                      // Notes
                      _buildInputField(
                        controller: _notesController,
                        label: 'Additional Notes (Optional)',
                        hint: 'Special instructions, requirements, or notes...',
                        maxLines: 3,
                      ),

                      SizedBox(height: 40.h),
                    ],
                  ),
                ),
              ),

              // Action Buttons
              Container(
                padding: EdgeInsets.all(20.sp),
                decoration: BoxDecoration(
                  color: Theme.of(context).cardColor,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.shadowLight,
                      blurRadius: 8,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed:
                            _isLoading ? null : () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          padding: EdgeInsets.symmetric(vertical: 16.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.sp),
                          ),
                        ),
                        child: Text(
                          'Cancel',
                          style: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Expanded(
                      flex: 2,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _registerAgent,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryLight,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(vertical: 16.h),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.sp),
                          ),
                        ),
                        child: _isLoading
                            ? Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(
                                    width: 16.w,
                                    height: 16.h,
                                    child: const CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  ),
                                  SizedBox(width: 12.w),
                                  Text(
                                    'Registering...',
                                    style: GoogleFonts.inter(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              )
                            : Text(
                                'Register Agent',
                                style: GoogleFonts.inter(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(8.sp),
          decoration: BoxDecoration(
            color: AppTheme.primaryLight.withAlpha(26),
            borderRadius: BorderRadius.circular(8.sp),
          ),
          child: Icon(
            icon,
            color: AppTheme.primaryLight,
            size: 20.sp,
          ),
        ),
        SizedBox(width: 12.w),
        Text(
          title,
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
      ],
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: GoogleFonts.inter(
        fontSize: 14.sp,
        fontWeight: FontWeight.w500,
        color: AppTheme.textPrimaryLight,
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(label),
        SizedBox(height: 8.h),
        TextFormField(
          controller: controller,
          validator: validator,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Theme.of(context).scaffoldBackgroundColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.primaryLight,
                width: 2,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.errorLight,
              ),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 16.w,
              vertical: 16.h,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildModalInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    int maxLines = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(label),
        SizedBox(height: 8.h),
        TextFormField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            filled: true,
            fillColor: Theme.of(context).scaffoldBackgroundColor,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.getNeutralColor(true),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.sp),
              borderSide: BorderSide(
                color: AppTheme.primaryLight,
                width: 2,
              ),
            ),
            contentPadding: EdgeInsets.symmetric(
              horizontal: 16.w,
              vertical: 16.h,
            ),
          ),
        ),
      ],
    );
  }
}
