import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:google_fonts/google_fonts.dart'; // Add this import

class CitySelectorWidget extends StatefulWidget {
  final List<Map<String, dynamic>> cities;
  final String? selectedCity;
  final Function(String) onCitySelected;
  final bool showGpsOption;
  final VoidCallback onGpsSelected;

  const CitySelectorWidget({
    super.key,
    required this.cities,
    this.selectedCity,
    required this.onCitySelected,
    this.showGpsOption = true,
    required this.onGpsSelected,
  });

  @override
  State<CitySelectorWidget> createState() => _CitySelectorWidgetState();
}

class _CitySelectorWidgetState extends State<CitySelectorWidget> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> _filteredCities = [];

  @override
  void initState() {
    super.initState();
    _filteredCities = widget.cities;
    _searchController.addListener(_filterCities);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _filterCities() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredCities = widget.cities.where((city) {
        return city['name'].toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle(),
        SizedBox(height: 3.w),
        if (widget.showGpsOption) ...[
          _buildGpsOption(),
          SizedBox(height: 3.w),
          _buildDivider(),
          SizedBox(height: 3.w),
        ],
        _buildSearchField(),
        SizedBox(height: 3.w),
        _buildCitiesGrid(),
      ],
    );
  }

  Widget _buildSectionTitle() {
    return Row(
      children: [
        Icon(
          Icons.location_on,
          color: Colors.cyan.shade400,
          size: 5.w,
        ),
        SizedBox(width: 2.w),
        Text(
          'Select Your City',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildGpsOption() {
    return GestureDetector(
      onTap: widget.onGpsSelected,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green.shade700, Colors.green.shade600],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.green.shade600.withAlpha(77),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(51),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.my_location,
                color: Colors.white,
                size: 5.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Use My Current Location',
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Automatically detect your city for better matching',
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: Colors.white,
              size: 4.w,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDivider() {
    return Row(
      children: [
        Expanded(child: Divider(color: Colors.grey.shade600)),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 3.w),
          child: Text(
            'OR CHOOSE MANUALLY',
            style: GoogleFonts.inter(
              fontSize: 10.sp,
              fontWeight: FontWeight.w500,
              color: Colors.grey.shade400,
            ),
          ),
        ),
        Expanded(child: Divider(color: Colors.grey.shade600)),
      ],
    );
  }

  Widget _buildSearchField() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey.shade800,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade600),
      ),
      child: TextField(
        controller: _searchController,
        style: GoogleFonts.inter(
          fontSize: 14.sp,
          color: Colors.white,
        ),
        decoration: InputDecoration(
          hintText: 'Search for your city...',
          hintStyle: GoogleFonts.inter(
            fontSize: 12.sp,
            color: Colors.grey.shade400,
          ),
          prefixIcon: Icon(
            Icons.search,
            color: Colors.grey.shade400,
            size: 5.w,
          ),
          border: InputBorder.none,
          contentPadding: EdgeInsets.all(4.w),
        ),
      ),
    );
  }

  Widget _buildCitiesGrid() {
    return Container(
      constraints: BoxConstraints(maxHeight: 40.h),
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: _filteredCities.length,
        itemBuilder: (context, index) {
          final city = _filteredCities[index];
          final isSelected = widget.selectedCity == city['name'];

          return _buildCityTile(city, isSelected);
        },
      ),
    );
  }

  Widget _buildCityTile(Map<String, dynamic> city, bool isSelected) {
    return GestureDetector(
      onTap: () => widget.onCitySelected(city['name']),
      child: Container(
        margin: EdgeInsets.only(bottom: 2.w),
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: isSelected
              ? Colors.cyan.shade400.withAlpha(26)
              : Colors.grey.shade800,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? Colors.cyan.shade400 : Colors.grey.shade600,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: isSelected
                    ? Colors.cyan.shade400.withAlpha(51)
                    : Colors.grey.shade700,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.location_city,
                color: isSelected ? Colors.cyan.shade400 : Colors.grey.shade400,
                size: 5.w,
              ),
            ),
            SizedBox(width: 3.w),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    city['name'],
                    style: GoogleFonts.inter(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    '${city['population']} people • ${city['traders']} active traders',
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      color: Colors.grey.shade400,
                    ),
                  ),
                ],
              ),
            ),
            if (isSelected)
              Container(
                padding: EdgeInsets.all(1.w),
                decoration: BoxDecoration(
                  color: Colors.cyan.shade400,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  Icons.check,
                  color: Colors.white,
                  size: 3.w,
                ),
              ),
            if (!isSelected)
              Container(
                width: 5.w,
                height: 5.w,
                decoration: BoxDecoration(
                  color: Colors.grey.shade700,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.grey.shade600,
                    width: 1,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}