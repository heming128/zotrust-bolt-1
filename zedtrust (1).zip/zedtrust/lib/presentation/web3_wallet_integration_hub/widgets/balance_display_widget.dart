import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BalanceDisplayWidget extends StatelessWidget {
  final Map<String, double> tokenBalances;
  final String walletAddress;
  final String selectedNetwork;
  final Function(String) onCopyAddress;
  final VoidCallback onGenerateQR;

  const BalanceDisplayWidget({
    Key? key,
    required this.tokenBalances,
    required this.walletAddress,
    required this.selectedNetwork,
    required this.onCopyAddress,
    required this.onGenerateQR,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).shadowColor.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Section
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: CustomIconWidget(
                    iconName: 'account_balance',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 6.w,
                  ),
                ),
                SizedBox(width: 4.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Token Balances',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        'Real-time balance with fiat conversion',
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceVariant,
                            ),
                      ),
                    ],
                  ),
                ),
                // Refresh Button
                IconButton(
                  onPressed: () {
                    // Refresh balances functionality
                  },
                  icon: CustomIconWidget(
                    iconName: 'refresh',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 5.w,
                  ),
                  style: IconButton.styleFrom(
                    backgroundColor: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Wallet Address Section
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Theme.of(context).dividerColor,
                  width: 1,
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'account_circle',
                    color: AppTheme.lightTheme.colorScheme.primary,
                    size: 5.w,
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Wallet Address',
                          style:
                              Theme.of(context).textTheme.labelSmall?.copyWith(
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          '${walletAddress.substring(0, 8)}...${walletAddress.substring(walletAddress.length - 6)}',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    fontFamily: 'monospace',
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => onCopyAddress(walletAddress),
                    icon: CustomIconWidget(
                      iconName: 'copy',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      size: 4.w,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  SizedBox(width: 2.w),
                  IconButton(
                    onPressed: onGenerateQR,
                    icon: CustomIconWidget(
                      iconName: 'qr_code',
                      color: AppTheme.lightTheme.colorScheme.secondary,
                      size: 4.w,
                    ),
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.lightTheme.colorScheme.secondary
                          .withValues(alpha: 0.1),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 3.h),

            // Token Balances List
            Text(
              'Supported Tokens ($selectedNetwork)',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 2.h),

            ...tokenBalances.entries
                .map((entry) => _buildTokenBalanceItem(
                      context,
                      entry.key,
                      entry.value,
                    ))
                .toList(),

            if (tokenBalances.isEmpty) ...[
              Container(
                padding: EdgeInsets.all(4.w),
                decoration: BoxDecoration(
                  color: Theme.of(context)
                      .colorScheme
                      .surface
                      .withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    CustomIconWidget(
                      iconName: 'hourglass_empty',
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      size: 8.w,
                    ),
                    SizedBox(height: 2.h),
                    Text(
                      'Loading Token Balances...',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      'Please wait while we fetch your wallet balances',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildTokenBalanceItem(
      BuildContext context, String token, double balance) {
    final fiatValue = _calculateFiatValue(token, balance);

    return Container(
      margin: EdgeInsets.only(bottom: 2.h),
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).dividerColor.withValues(alpha: 0.5),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          // Token Icon
          Container(
            width: 10.w,
            height: 10.w,
            decoration: BoxDecoration(
              color: _getTokenColor(token).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Center(
              child: Text(
                token.substring(0, 1),
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: _getTokenColor(token),
                      fontWeight: FontWeight.w700,
                    ),
              ),
            ),
          ),
          SizedBox(width: 4.w),

          // Token Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      token,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    SizedBox(width: 2.w),
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: 1.5.w, vertical: 0.2.h),
                      decoration: BoxDecoration(
                        color: _getTokenColor(token).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _getTokenName(token),
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: _getTokenColor(token),
                              fontWeight: FontWeight.w500,
                              fontSize: 10.sp,
                            ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 0.5.h),
                Text(
                  '\$${fiatValue.toStringAsFixed(2)} USD',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w500,
                      ),
                ),
              ],
            ),
          ),

          // Balance Amount
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                balance.toStringAsFixed(balance < 1 ? 6 : 2),
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w700,
                      fontFamily: 'monospace',
                    ),
              ),
              SizedBox(height: 0.5.h),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.2.h),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.secondary
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  selectedNetwork == 'Ethereum Mainnet' ? 'ETH' : 'MATIC',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.secondary,
                        fontWeight: FontWeight.w600,
                        fontSize: 10.sp,
                      ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  double _calculateFiatValue(String token, double balance) {
    // Mock fiat conversion rates
    const Map<String, double> rates = {
      'USDC': 1.0,
      'DAI': 1.0,
      'ETH': 2500.0,
      'MATIC': 0.85,
    };
    return balance * (rates[token] ?? 0.0);
  }

  Color _getTokenColor(String token) {
    const Map<String, Color> colors = {
      'USDC': Color(0xFF2775C9),
      'DAI': Color(0xFFF5AC37),
      'ETH': Color(0xFF627EEA),
      'MATIC': Color(0xFF8247E5),
    };
    return colors[token] ?? Colors.grey;
  }

  String _getTokenName(String token) {
    const Map<String, String> names = {
      'USDC': 'USD Coin',
      'DAI': 'DAI Stablecoin',
      'ETH': 'Ethereum',
      'MATIC': 'Polygon',
    };
    return names[token] ?? token;
  }
}
