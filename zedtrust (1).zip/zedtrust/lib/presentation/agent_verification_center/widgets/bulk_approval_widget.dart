import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class BulkApprovalWidget extends StatelessWidget {
  final int selectedCount;
  final VoidCallback onApproveAll;
  final VoidCallback onClearSelection;

  const BulkApprovalWidget({
    super.key,
    required this.selectedCount,
    required this.onApproveAll,
    required this.onClearSelection,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.sp),
      decoration: BoxDecoration(
        color: AppTheme.primaryLight.withAlpha(26),
        border: Border(
          bottom: BorderSide(
            color: AppTheme.primaryLight.withAlpha(51),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'select_all',
            color: AppTheme.primaryLight,
            size: 20,
          ),
          SizedBox(width: 8.w),
          Expanded(
            child: Text(
              '$selectedCount application${selectedCount == 1 ? '' : 's'} selected',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: AppTheme.primaryLight,
              ),
            ),
          ),
          TextButton.icon(
            onPressed: onClearSelection,
            icon: CustomIconWidget(
              iconName: 'clear',
              color: AppTheme.textSecondaryLight,
              size: 16,
            ),
            label: Text(
              'Clear',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          SizedBox(width: 8.w),
          ElevatedButton.icon(
            onPressed: () => _showBulkApprovalDialog(context),
            icon: CustomIconWidget(
              iconName: 'verified_user',
              color: Colors.white,
              size: 16,
            ),
            label: Text(
              'Approve All',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.successLight,
              padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            ),
          ),
        ],
      ),
    );
  }

  void _showBulkApprovalDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Bulk Approval',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: 'verified_user',
              color: AppTheme.successLight,
              size: 48,
            ),
            SizedBox(height: 16.h),
            Text(
              'Are you sure you want to approve all $selectedCount selected applications?',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            Container(
              padding: EdgeInsets.all(12.sp),
              decoration: BoxDecoration(
                color: AppTheme.warningLight.withAlpha(26),
                borderRadius: BorderRadius.circular(8.sp),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'warning',
                    color: AppTheme.warningLight,
                    size: 16,
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Text(
                      'This action cannot be undone. Make sure all applications have been properly reviewed.',
                      style: GoogleFonts.inter(
                        fontSize: 12.sp,
                        color: AppTheme.warningLight,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: GoogleFonts.inter(
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              onApproveAll();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.successLight,
            ),
            child: Text(
              'Approve All',
              style: GoogleFonts.inter(
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
