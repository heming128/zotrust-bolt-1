import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class VerificationQueueWidget extends StatelessWidget {
  final List<Map<String, dynamic>> applications;
  final Set<String> selectedIds;
  final Function(Map<String, dynamic>) onApplicationTap;
  final Function(String) onLongPress;
  final Function(String) onApprove;
  final Function(String, String) onReject;

  const VerificationQueueWidget({
    super.key,
    required this.applications,
    required this.selectedIds,
    required this.onApplicationTap,
    required this.onLongPress,
    required this.onApprove,
    required this.onReject,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      itemCount: applications.length,
      itemBuilder: (context, index) {
        final application = applications[index];
        final isSelected = selectedIds.contains(application['id']);

        return _buildApplicationCard(context, application, isSelected);
      },
    );
  }

  Widget _buildApplicationCard(
      BuildContext context, Map<String, dynamic> application, bool isSelected) {
    final verificationScore = application['verification_score'] as int;
    final documentsCount = application['documents_count'] as int;
    final identityVerified = application['identity_verified'] as bool;
    final kycComplete = application['kyc_complete'] as bool;

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: isSelected
            ? AppTheme.primaryLight.withAlpha(26)
            : Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12.sp),
        border: Border.all(
          color: isSelected
              ? AppTheme.primaryLight
              : AppTheme.getNeutralColor(true).withAlpha(51),
          width: isSelected ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => onApplicationTap(application),
        onLongPress: () => onLongPress(application['id']),
        borderRadius: BorderRadius.circular(12.sp),
        child: Padding(
          padding: EdgeInsets.all(16.sp),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Row
              Row(
                children: [
                  if (isSelected)
                    Container(
                      margin: EdgeInsets.only(right: 12.w),
                      child: CustomIconWidget(
                        iconName: 'check_circle',
                        color: AppTheme.primaryLight,
                        size: 24,
                      ),
                    ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          application['agent_name'] ?? 'Unknown Agent',
                          style: GoogleFonts.inter(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          'Applied on ${_formatDate(application['application_date'])}',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            color: AppTheme.textSecondaryLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildVerificationScore(verificationScore),
                ],
              ),

              SizedBox(height: 16.h),

              // Status Indicators
              Row(
                children: [
                  _buildStatusChip(
                    'Identity',
                    identityVerified ? 'Verified' : 'Pending',
                    identityVerified
                        ? AppTheme.successLight
                        : AppTheme.warningLight,
                  ),
                  SizedBox(width: 8.w),
                  _buildStatusChip(
                    'KYC',
                    kycComplete ? 'Complete' : 'Incomplete',
                    kycComplete ? AppTheme.successLight : AppTheme.errorLight,
                  ),
                  SizedBox(width: 8.w),
                  _buildStatusChip(
                    'Docs',
                    '$documentsCount uploaded',
                    documentsCount >= 3
                        ? AppTheme.successLight
                        : AppTheme.warningLight,
                  ),
                ],
              ),

              SizedBox(height: 16.h),

              // Document Thumbnails
              Row(
                children: [
                  Text(
                    'Documents:',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textSecondaryLight,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: Row(
                      children: [
                        ...((application['documents'] as List).take(3).map(
                              (doc) => Container(
                                margin: EdgeInsets.only(right: 4.w),
                                width: 32.w,
                                height: 32.w,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(4.sp),
                                  border: Border.all(
                                    color: (doc['verified'] as bool)
                                        ? AppTheme.successLight
                                        : AppTheme.warningLight,
                                    width: 2,
                                  ),
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(2.sp),
                                  child: Image.network(
                                    doc['url'],
                                    fit: BoxFit.cover,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            CustomIconWidget(
                                      iconName: 'document_scanner',
                                      color: AppTheme.textSecondaryLight,
                                      size: 16,
                                    ),
                                  ),
                                ),
                              ),
                            )),
                        if ((application['documents'] as List).length > 3)
                          Container(
                            width: 32.w,
                            height: 32.w,
                            decoration: BoxDecoration(
                              color: AppTheme.getNeutralColor(true),
                              borderRadius: BorderRadius.circular(4.sp),
                            ),
                            child: Center(
                              child: Text(
                                '+${(application['documents'] as List).length - 3}',
                                style: GoogleFonts.inter(
                                  fontSize: 10.sp,
                                  fontWeight: FontWeight.w600,
                                  color: AppTheme.textPrimaryLight,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),

              SizedBox(height: 16.h),

              // Action Buttons
              if (!isSelected)
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () =>
                            _showRejectDialog(context, application['id']),
                        icon: CustomIconWidget(
                          iconName: 'close',
                          color: AppTheme.errorLight,
                          size: 16,
                        ),
                        label: Text(
                          'Reject',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.errorLight,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: AppTheme.errorLight),
                          padding: EdgeInsets.symmetric(vertical: 8.h),
                        ),
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => onApprove(application['id']),
                        icon: CustomIconWidget(
                          iconName: 'check',
                          color: Colors.white,
                          size: 16,
                        ),
                        label: Text(
                          'Approve',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.successLight,
                          padding: EdgeInsets.symmetric(vertical: 8.h),
                        ),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVerificationScore(int score) {
    Color scoreColor;
    if (score >= 90) {
      scoreColor = AppTheme.successLight;
    } else if (score >= 70) {
      scoreColor = AppTheme.warningLight;
    } else {
      scoreColor = AppTheme.errorLight;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: scoreColor.withAlpha(26),
        borderRadius: BorderRadius.circular(12.sp),
      ),
      child: Text(
        '$score%',
        style: GoogleFonts.inter(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
          color: scoreColor,
        ),
      ),
    );
  }

  Widget _buildStatusChip(String label, String status, Color color) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: color.withAlpha(26),
        borderRadius: BorderRadius.circular(8.sp),
      ),
      child: Text(
        '$label: $status',
        style: GoogleFonts.inter(
          fontSize: 10.sp,
          fontWeight: FontWeight.w500,
          color: color,
        ),
      ),
    );
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return '${date.day}/${date.month}/${date.year}';
    } catch (e) {
      return 'Unknown date';
    }
  }

  void _showRejectDialog(BuildContext context, String applicationId) {
    final reasons = [
      'Incomplete documentation',
      'Invalid ID verification',
      'Failed background check',
      'Insufficient business license',
      'Other (specify)',
    ];

    String selectedReason = reasons.first;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text(
            'Reject Application',
            style: GoogleFonts.inter(
              fontWeight: FontWeight.w600,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Select a reason for rejection:',
                style: GoogleFonts.inter(fontSize: 14.sp),
              ),
              SizedBox(height: 16.h),
              ...reasons.map((reason) => RadioListTile<String>(
                    title: Text(
                      reason,
                      style: GoogleFonts.inter(fontSize: 12.sp),
                    ),
                    value: reason,
                    groupValue: selectedReason,
                    onChanged: (value) {
                      setState(() {
                        selectedReason = value!;
                      });
                    },
                  )),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                onReject(applicationId, selectedReason);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.errorLight,
              ),
              child: Text(
                'Reject',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
