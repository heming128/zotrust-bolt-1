import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class DocumentViewerModal extends StatefulWidget {
  final Map<String, dynamic> application;
  final VoidCallback onApprove;
  final Function(String) onReject;
  final VoidCallback onRequestDocuments;

  const DocumentViewerModal({
    super.key,
    required this.application,
    required this.onApprove,
    required this.onReject,
    required this.onRequestDocuments,
  });

  @override
  State<DocumentViewerModal> createState() => _DocumentViewerModalState();
}

class _DocumentViewerModalState extends State<DocumentViewerModal> {
  int _selectedDocumentIndex = 0;
  bool _isZoomed = false;

  @override
  Widget build(BuildContext context) {
    final documents = widget.application['documents'] as List<dynamic>;

    return DraggableScrollableSheet(
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true),
                  borderRadius: BorderRadius.circular(2.sp),
                ),
              ),

              // Header
              Padding(
                padding: EdgeInsets.all(20.sp),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Document Verification',
                            style: GoogleFonts.inter(
                              fontSize: 20.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            widget.application['agent_name'] ?? 'Unknown Agent',
                            style: GoogleFonts.inter(
                              fontSize: 14.sp,
                              color: AppTheme.textSecondaryLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: CustomIconWidget(
                        iconName: 'close',
                        color: AppTheme.textSecondaryLight,
                        size: 24,
                      ),
                    ),
                  ],
                ),
              ),

              // Document Tabs
              Container(
                height: 50.h,
                margin: EdgeInsets.symmetric(horizontal: 20.w),
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: documents.length,
                  itemBuilder: (context, index) {
                    final doc = documents[index];
                    final isSelected = index == _selectedDocumentIndex;
                    final isVerified = doc['verified'] as bool;

                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _selectedDocumentIndex = index;
                          _isZoomed = false;
                        });
                      },
                      child: Container(
                        margin: EdgeInsets.only(right: 8.w),
                        padding: EdgeInsets.symmetric(
                            horizontal: 16.w, vertical: 8.h),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppTheme.primaryLight
                              : Theme.of(context).scaffoldBackgroundColor,
                          borderRadius: BorderRadius.circular(20.sp),
                          border: Border.all(
                            color: isVerified
                                ? AppTheme.successLight
                                : AppTheme.warningLight,
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CustomIconWidget(
                              iconName: _getDocumentIcon(doc['type']),
                              color: isSelected
                                  ? Colors.white
                                  : AppTheme.textPrimaryLight,
                              size: 16,
                            ),
                            SizedBox(width: 4.w),
                            Text(
                              _formatDocumentType(doc['type']),
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                fontWeight: FontWeight.w500,
                                color: isSelected
                                    ? Colors.white
                                    : AppTheme.textPrimaryLight,
                              ),
                            ),
                            if (isVerified) ...[
                              SizedBox(width: 4.w),
                              CustomIconWidget(
                                iconName: 'verified',
                                color: isSelected
                                    ? Colors.white
                                    : AppTheme.successLight,
                                size: 12,
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),

              SizedBox(height: 16.h),

              // Document Viewer
              Expanded(
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 20.w),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(12.sp),
                    boxShadow: [
                      BoxShadow(
                        color: AppTheme.shadowLight,
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Document Image
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isZoomed = !_isZoomed;
                            });
                          },
                          child: Container(
                            width: double.infinity,
                            margin: EdgeInsets.all(16.sp),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.sp),
                              border: Border.all(
                                color: AppTheme.getNeutralColor(true),
                              ),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8.sp),
                              child: _isZoomed
                                  ? InteractiveViewer(
                                      child: Image.network(
                                        documents[_selectedDocumentIndex]
                                            ['url'],
                                        fit: BoxFit.contain,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                _buildErrorPlaceholder(),
                                      ),
                                    )
                                  : Image.network(
                                      documents[_selectedDocumentIndex]['url'],
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) =>
                                              _buildErrorPlaceholder(),
                                    ),
                            ),
                          ),
                        ),
                      ),

                      // Document Info
                      Container(
                        padding: EdgeInsets.all(16.sp),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.vertical(
                            bottom: Radius.circular(12.sp),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    _formatDocumentType(
                                        documents[_selectedDocumentIndex]
                                            ['type']),
                                    style: GoogleFonts.inter(
                                      fontSize: 16.sp,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 8.w, vertical: 4.h),
                                  decoration: BoxDecoration(
                                    color: (documents[_selectedDocumentIndex]
                                            ['verified'] as bool)
                                        ? AppTheme.successLight.withAlpha(26)
                                        : AppTheme.warningLight.withAlpha(26),
                                    borderRadius: BorderRadius.circular(8.sp),
                                  ),
                                  child: Text(
                                    (documents[_selectedDocumentIndex]
                                            ['verified'] as bool)
                                        ? 'Verified'
                                        : 'Pending',
                                    style: GoogleFonts.inter(
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.w500,
                                      color: (documents[_selectedDocumentIndex]
                                              ['verified'] as bool)
                                          ? AppTheme.successLight
                                          : AppTheme.warningLight,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8.h),
                            Text(
                              _isZoomed ? 'Tap to zoom out' : 'Tap to zoom in',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                color: AppTheme.textSecondaryLight,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Action Buttons
              Container(
                padding: EdgeInsets.all(20.sp),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) => _buildRejectDialog(),
                          );
                        },
                        icon: CustomIconWidget(
                          iconName: 'close',
                          color: AppTheme.errorLight,
                          size: 16,
                        ),
                        label: Text(
                          'Reject',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.errorLight,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: AppTheme.errorLight),
                          padding: EdgeInsets.symmetric(vertical: 12.h),
                        ),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: widget.onRequestDocuments,
                        icon: CustomIconWidget(
                          iconName: 'mail',
                          color: AppTheme.primaryLight,
                          size: 16,
                        ),
                        label: Text(
                          'Request Docs',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.primaryLight,
                          ),
                        ),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: AppTheme.primaryLight),
                          padding: EdgeInsets.symmetric(vertical: 12.h),
                        ),
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: widget.onApprove,
                        icon: CustomIconWidget(
                          iconName: 'check',
                          color: Colors.white,
                          size: 16,
                        ),
                        label: Text(
                          'Approve',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.successLight,
                          padding: EdgeInsets.symmetric(vertical: 12.h),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildErrorPlaceholder() {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'error',
              color: AppTheme.errorLight,
              size: 48,
            ),
            SizedBox(height: 8.h),
            Text(
              'Failed to load document',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                color: AppTheme.textSecondaryLight,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRejectDialog() {
    final reasons = [
      'Document quality too poor',
      'Information not clearly visible',
      'Document appears tampered',
      'Expired document',
      'Wrong document type',
      'Other (specify)',
    ];

    String selectedReason = reasons.first;

    return StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        title: Text(
          'Reject Application',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Why are you rejecting this application?',
              style: GoogleFonts.inter(fontSize: 14.sp),
            ),
            SizedBox(height: 16.h),
            ...reasons.map((reason) => RadioListTile<String>(
                  title: Text(
                    reason,
                    style: GoogleFonts.inter(fontSize: 12.sp),
                  ),
                  value: reason,
                  groupValue: selectedReason,
                  onChanged: (value) {
                    setState(() {
                      selectedReason = value!;
                    });
                  },
                )),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              widget.onReject(selectedReason);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.errorLight,
            ),
            child: Text(
              'Reject',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  String _getDocumentIcon(String docType) {
    switch (docType) {
      case 'id_card':
        return 'credit_card';
      case 'business_license':
        return 'business';
      case 'address_proof':
        return 'home';
      case 'bank_statement':
        return 'account_balance';
      default:
        return 'document_scanner';
    }
  }

  String _formatDocumentType(String docType) {
    switch (docType) {
      case 'id_card':
        return 'ID Card';
      case 'business_license':
        return 'Business License';
      case 'address_proof':
        return 'Address Proof';
      case 'bank_statement':
        return 'Bank Statement';
      default:
        return 'Document';
    }
  }
}
