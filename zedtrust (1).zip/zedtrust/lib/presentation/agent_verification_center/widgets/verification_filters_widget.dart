import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';

class VerificationFiltersWidget extends StatelessWidget {
  final String selectedFilter;
  final String selectedRegion;
  final Function(String) onFilterChanged;
  final Function(String) onRegionChanged;

  const VerificationFiltersWidget({
    super.key,
    required this.selectedFilter,
    required this.selectedRegion,
    required this.onFilterChanged,
    required this.onRegionChanged,
  });

  @override
  Widget build(BuildContext context) {
    final filters = [
      {'key': 'all', 'label': 'All'},
      {'key': 'pending_review', 'label': 'Pending Review'},
      {'key': 'high_score', 'label': 'High Score (90%+)'},
      {'key': 'needs_attention', 'label': 'Needs Attention'},
    ];

    final regions = [
      {'key': 'all', 'label': 'All Regions'},
      {'key': 'Mumbai', 'label': 'Mumbai'},
      {'key': 'Delhi', 'label': 'Delhi'},
      {'key': 'Bangalore', 'label': 'Bangalore'},
      {'key': 'Surat', 'label': 'Surat'},
      {'key': 'Pune', 'label': 'Pune'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Status Filter
        Text(
          'Status Filter',
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
            color: AppTheme.textSecondaryLight,
          ),
        ),
        SizedBox(height: 8.h),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: filters.map((filter) {
              final isSelected = selectedFilter == filter['key'];
              return Container(
                margin: EdgeInsets.only(right: 8.w),
                child: FilterChip(
                  label: Text(
                    filter['label']!,
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color:
                          isSelected ? Colors.white : AppTheme.textPrimaryLight,
                    ),
                  ),
                  selected: isSelected,
                  onSelected: (_) => onFilterChanged(filter['key']!),
                  selectedColor: AppTheme.primaryLight,
                  backgroundColor: Theme.of(context).scaffoldBackgroundColor,
                  side: BorderSide(
                    color: isSelected
                        ? AppTheme.primaryLight
                        : AppTheme.getNeutralColor(true),
                  ),
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                ),
              );
            }).toList(),
          ),
        ),

        SizedBox(height: 12.h),

        // Region Filter
        Text(
          'Region Filter',
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
            color: AppTheme.textSecondaryLight,
          ),
        ),
        SizedBox(height: 8.h),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: regions.map((region) {
              final isSelected = selectedRegion == region['key'];
              return Container(
                margin: EdgeInsets.only(right: 8.w),
                child: FilterChip(
                  label: Text(
                    region['label']!,
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w500,
                      color:
                          isSelected ? Colors.white : AppTheme.textPrimaryLight,
                    ),
                  ),
                  selected: isSelected,
                  onSelected: (_) => onRegionChanged(region['key']!),
                  selectedColor: AppTheme.primaryLight,
                  backgroundColor: Theme.of(context).scaffoldBackgroundColor,
                  side: BorderSide(
                    color: isSelected
                        ? AppTheme.primaryLight
                        : AppTheme.getNeutralColor(true),
                  ),
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                ),
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
