import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class LocationTreeWidget extends StatefulWidget {
  final List<Map<String, dynamic>> locations;
  final Function(Map<String, dynamic>) onLocationTap;
  final Function(String, String) onStatusChange;
  final Function(String, String) onAssignAgent;

  const LocationTreeWidget({
    super.key,
    required this.locations,
    required this.onLocationTap,
    required this.onStatusChange,
    required this.onAssignAgent,
  });

  @override
  State<LocationTreeWidget> createState() => _LocationTreeWidgetState();
}

class _LocationTreeWidgetState extends State<LocationTreeWidget> {
  final Set<String> _expandedCities = {};

  @override
  Widget build(BuildContext context) {
    final locationsByCity = <String, List<Map<String, dynamic>>>{};
    
    for (final location in widget.locations) {
      final city = location['city'] as String;
      if (!locationsByCity.containsKey(city)) {
        locationsByCity[city] = [];
      }
      locationsByCity[city]!.add(location);
    }

    return ListView(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      children: locationsByCity.entries.map((entry) {
        final city = entry.key;
        final locations = entry.value;
        final isExpanded = _expandedCities.contains(city);
        
        return _buildCitySection(city, locations, isExpanded);
      }).toList());
  }

  Widget _buildCitySection(String city, List<Map<String, dynamic>> locations, bool isExpanded) {
    final activeCount = locations.where((loc) => loc['status'] == 'active').length;
    final totalAgents = locations.fold(0, (sum, loc) => sum + (loc['agents_count'] as int));
    
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12.sp),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 8,
            offset: const Offset(0, 2)),
        ]),
      child: Column(
        children: [
          // City Header
          InkWell(
            onTap: () {
              setState(() {
                if (isExpanded) {
                  _expandedCities.remove(city);
                } else {
                  _expandedCities.add(city);
                }
              });
            },
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(12.sp),
              bottom: isExpanded ? Radius.zero : Radius.circular(12.sp)),
            child: Container(
              padding: EdgeInsets.all(16.sp),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8.sp),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight.withAlpha(26),
                      borderRadius: BorderRadius.circular(8.sp)),
                    child: CustomIconWidget(
                      iconName: 'location_city',
                      color: AppTheme.primaryLight,
                      size: 24)),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          city,
                          style: GoogleFonts.inter(
                            fontSize: 18.sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimaryLight)),
                        SizedBox(height: 4.h),
                        Row(
                          children: [
                            Text(
                              '${locations.length} locations',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                color: AppTheme.textSecondaryLight)),
                            SizedBox(width: 8.w),
                            Container(
                              width: 4.w,
                              height: 4.w,
                              decoration: BoxDecoration(
                                color: AppTheme.getNeutralColor(true),
                                shape: BoxShape.circle)),
                            SizedBox(width: 8.w),
                            Text(
                              '$activeCount active',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp,
                                color: AppTheme.successLight)),
                            SizedBox(width: 8.w),
                            Container(
                              width: 4.w,
                              height: 4.w,
                              decoration: BoxDecoration(
                                color: AppTheme.getNeutralColor(true),
                                shape: BoxShape.circle)),
                            SizedBox(width: 8.w),
                            Text(
                              '$totalAgents agents',
                              style: GoogleFonts.inter(
                                fontSize: 12.sp)),
                          ]),
                      ])),
                  AnimatedRotation(
                    turns: isExpanded ? 0.5 : 0,
                    duration: const Duration(milliseconds: 300),
                    child: CustomIconWidget(
                      iconName: 'expand_more',
                      color: AppTheme.textSecondaryLight,
                      size: 24)),
                ]))),
          
          // Locations List
          if (isExpanded) ...[
            Container(
              height: 1,
              color: AppTheme.getNeutralColor(true).withAlpha(51)),
            ...locations.map((location) => _buildLocationCard(location)),
          ],
        ]));
  }

  Widget _buildLocationCard(Map<String, dynamic> location) {
    final status = location['status'] as String;
    final agentsCount = location['agents_count'] as int;
    final capacity = location['capacity'] as int;
    final tradeVolume = location['trade_volume'] as int;
    
    final utilizationRate = capacity > 0 ? (agentsCount / capacity) : 0.0;
    
    return InkWell(
      onTap: () => widget.onLocationTap(location),
      child: Container(
        padding: EdgeInsets.all(16.sp),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: AppTheme.getNeutralColor(true).withAlpha(51),
              width: 0.5))),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Location Header
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        location['name'] ?? 'Unknown Location',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight)),
                      SizedBox(height: 4.h),
                      Text(
                        location['address'] ?? '',
                        style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          color: AppTheme.textSecondaryLight),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                    ])),
                SizedBox(width: 12.w),
                _buildStatusBadge(status),
              ]),

            SizedBox(height: 16.h),

            // Location Metrics
            Row(
              children: [
                Expanded(
                  child: _buildMetricItem(
                    'Agents',
                    '$agentsCount/$capacity',
                    utilizationRate >= 0.8 ? AppTheme.warningLight : AppTheme.textSecondaryLight)),
                Expanded(
                  child: _buildMetricItem(
                    'Hours',
                    location['operating_hours'] ?? '--',
                    AppTheme.textSecondaryLight)),
                Expanded(
                  child: _buildMetricItem(
                    'Volume',
                    '₹${_formatVolume(tradeVolume)}',
                    AppTheme.successLight)),
              ]),

            SizedBox(height: 16.h),

            // Utilization Bar
            Row(
              children: [
                Text(
                  'Capacity Utilization',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: AppTheme.textSecondaryLight)),
                SizedBox(width: 8.w),
                Expanded(
                  child: Container(
                    height: 6.h,
                    decoration: BoxDecoration(
                      color: AppTheme.getNeutralColor(true).withAlpha(51),
                      borderRadius: BorderRadius.circular(3.sp)),
                    child: FractionallySizedBox(
                      alignment: Alignment.centerLeft,
                      widthFactor: utilizationRate.clamp(0.0, 1.0),
                      child: Container(
                        decoration: BoxDecoration(
                          color: utilizationRate >= 0.8 
                              ? AppTheme.warningLight 
                              : utilizationRate >= 0.5
                                  ? AppTheme.primaryLight
                                  : AppTheme.successLight,
                          borderRadius: BorderRadius.circular(3.sp)))))),
                SizedBox(width: 8.w),
                Text(
                  '${(utilizationRate * 100).toInt()}%',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.textPrimaryLight)),
              ]),

            SizedBox(height: 16.h),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showStatusChangeDialog(location),
                    icon: CustomIconWidget(
                      iconName: 'edit',
                      color: AppTheme.primaryLight,
                      size: 14),
                    label: Text(
                      'Edit Status',
                      style: GoogleFonts.inter(
                        fontSize: 12.sp,
                        color: AppTheme.primaryLight)),
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppTheme.primaryLight),
                      padding: EdgeInsets.symmetric(vertical: 8.h)))),
                SizedBox(width: 8.w),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _showAssignAgentDialog(location),
                    icon: CustomIconWidget(
                      iconName: 'person_add',
                      color: AppTheme.successLight,
                      size: 14),
                    label: Text(
                      'Assign Agent',
                      style: GoogleFonts.inter(
                        fontSize: 12.sp,
                        color: AppTheme.successLight)),
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: AppTheme.successLight),
                      padding: EdgeInsets.symmetric(vertical: 8.h)))),
              ]),
          ])));
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    String label;
    
    switch (status) {
      case 'active':
        color = AppTheme.successLight;
        label = 'ACTIVE';
        break;
      case 'inactive':
        color = AppTheme.errorLight;
        label = 'INACTIVE';
        break;
      case 'maintenance':
        color = AppTheme.warningLight;
        label = 'MAINTENANCE';
        break;
      default:
        color = AppTheme.textSecondaryLight;
        label = 'UNKNOWN';
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
      decoration: BoxDecoration(
        color: color.withAlpha(26),
        borderRadius: BorderRadius.circular(8.sp)),
      child: Text(
        label,
        style: GoogleFonts.inter(
          fontSize: 11.sp,
          fontWeight: FontWeight.w600,
          color: color)));
  }

  Widget _buildMetricItem(String label, String value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 10.sp,
            color: AppTheme.textSecondaryLight)),
        SizedBox(height: 2.h),
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 12.sp,
            fontWeight: FontWeight.w600,
            color: color)),
      ]);
  }

  String _formatVolume(int volume) {
    if (volume >= 100000) {
      return '${(volume / 100000).toStringAsFixed(1)}L';
    } else if (volume >= 1000) {
      return '${(volume / 1000).toStringAsFixed(1)}K';
    } else {
      return volume.toString();
    }
  }

  void _showStatusChangeDialog(Map<String, dynamic> location) {
    final statuses = ['active', 'inactive', 'maintenance'];
    String selectedStatus = location['status'];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text(
            'Change Location Status',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Update status for ${location['name']}',
                style: GoogleFonts.inter(fontSize: 14.sp)),
              SizedBox(height: 16.h),
              ...statuses.map((status) => RadioListTile<String>(
                title: Text(
                  status.toUpperCase(),
                  style: GoogleFonts.inter(fontSize: 12.sp)),
                value: status,
                groupValue: selectedStatus,
                onChanged: (value) {
                  setState(() {
                    selectedStatus = value!;
                  });
                })),
            ]),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel')),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                widget.onStatusChange(location['id'], selectedStatus);
              },
              child: Text('Update')),
          ])));
  }

  void _showAssignAgentDialog(Map<String, dynamic> location) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Assign Agent',
          style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Assign an agent to ${location['name']}',
              style: GoogleFonts.inter(fontSize: 14.sp)),
            SizedBox(height: 16.h),
            TextField(
              decoration: InputDecoration(
                hintText: 'Enter agent ID or select from list',
                border: OutlineInputBorder())),
          ]),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              widget.onAssignAgent(location['id'], 'AGENT_123');
            },
            child: Text('Assign')),
        ]));
  }
}