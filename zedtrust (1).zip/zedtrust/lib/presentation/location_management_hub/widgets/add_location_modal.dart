import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class AddLocationModal extends StatefulWidget {
  final Function(Map<String, dynamic>) onLocationAdded;

  const AddLocationModal({
    super.key,
    required this.onLocationAdded,
  });

  @override
  State<AddLocationModal> createState() => _AddLocationModalState();
}

class _AddLocationModalState extends State<AddLocationModal> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _capacityController = TextEditingController();

  String _selectedCity = 'Mumbai';
  String _selectedStatus = 'active';
  TimeOfDay _openingTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _closingTime = const TimeOfDay(hour: 21, minute: 0);

  bool _isLoading = false;

  final List<String> _cities = [
    'Mumbai',
    'Delhi',
    'Bangalore',
    'Surat',
    'Pune'
  ];
  final List<String> _statuses = ['active', 'inactive', 'maintenance'];

  @override
  void dispose() {
    _nameController.dispose();
    _addressController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.9,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20.sp)),
          ),
          child: Column(
            children: [
              // Handle bar
              Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true),
                  borderRadius: BorderRadius.circular(2.sp),
                ),
              ),

              // Header
              Padding(
                padding: EdgeInsets.all(20.sp),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Add New Location',
                        style: GoogleFonts.inter(
                          fontSize: 20.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: CustomIconWidget(
                        iconName: 'close',
                        color: AppTheme.textSecondaryLight,
                        size: 24,
                      ),
                    ),
                  ],
                ),
              ),

              // Form
              Expanded(
                child: Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    controller: scrollController,
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Location Name
                        Text(
                          'Location Name',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        TextFormField(
                          controller: _nameController,
                          decoration: InputDecoration(
                            hintText: 'Enter location name',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.sp),
                            ),
                            prefixIcon: CustomIconWidget(
                              iconName: 'location_on',
                              color: AppTheme.textSecondaryLight,
                              size: 20,
                            ),
                          ),
                          validator: (value) {
                            if (value?.isEmpty ?? true) {
                              return 'Please enter location name';
                            }
                            return null;
                          },
                        ),

                        SizedBox(height: 16.h),

                        // City Selection
                        Text(
                          'City',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        DropdownButtonFormField<String>(
                          value: _selectedCity,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.sp),
                            ),
                            prefixIcon: CustomIconWidget(
                              iconName: 'location_city',
                              color: AppTheme.textSecondaryLight,
                              size: 20,
                            ),
                          ),
                          items: _cities
                              .map((city) => DropdownMenuItem(
                                    value: city,
                                    child: Text(
                                      city,
                                      style: GoogleFonts.inter(fontSize: 14.sp),
                                    ),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedCity = value!;
                            });
                          },
                        ),

                        SizedBox(height: 16.h),

                        // Address
                        Text(
                          'Full Address',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        TextFormField(
                          controller: _addressController,
                          maxLines: 3,
                          decoration: InputDecoration(
                            hintText: 'Enter complete address with pincode',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.sp),
                            ),
                            prefixIcon: Padding(
                              padding: EdgeInsets.only(bottom: 36.h),
                              child: CustomIconWidget(
                                iconName: 'home',
                                color: AppTheme.textSecondaryLight,
                                size: 20,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value?.isEmpty ?? true) {
                              return 'Please enter address';
                            }
                            return null;
                          },
                        ),

                        SizedBox(height: 16.h),

                        // Agent Capacity
                        Text(
                          'Agent Capacity',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        TextFormField(
                          controller: _capacityController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            hintText: 'Maximum number of agents',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.sp),
                            ),
                            prefixIcon: CustomIconWidget(
                              iconName: 'people',
                              color: AppTheme.textSecondaryLight,
                              size: 20,
                            ),
                          ),
                          validator: (value) {
                            if (value?.isEmpty ?? true) {
                              return 'Please enter capacity';
                            }
                            if (int.tryParse(value!) == null) {
                              return 'Please enter a valid number';
                            }
                            return null;
                          },
                        ),

                        SizedBox(height: 16.h),

                        // Operating Hours
                        Text(
                          'Operating Hours',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        Row(
                          children: [
                            Expanded(
                              child: InkWell(
                                onTap: () => _selectTime(context, true),
                                child: Container(
                                  padding: EdgeInsets.all(16.sp),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: AppTheme.getNeutralColor(true),
                                    ),
                                    borderRadius: BorderRadius.circular(8.sp),
                                  ),
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'access_time',
                                        color: AppTheme.textSecondaryLight,
                                        size: 20,
                                      ),
                                      SizedBox(width: 8.w),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Opening',
                                            style: GoogleFonts.inter(
                                              fontSize: 12.sp,
                                              color:
                                                  AppTheme.textSecondaryLight,
                                            ),
                                          ),
                                          Text(
                                            _openingTime.format(context),
                                            style: GoogleFonts.inter(
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: InkWell(
                                onTap: () => _selectTime(context, false),
                                child: Container(
                                  padding: EdgeInsets.all(16.sp),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                      color: AppTheme.getNeutralColor(true),
                                    ),
                                    borderRadius: BorderRadius.circular(8.sp),
                                  ),
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'access_time',
                                        color: AppTheme.textSecondaryLight,
                                        size: 20,
                                      ),
                                      SizedBox(width: 8.w),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Closing',
                                            style: GoogleFonts.inter(
                                              fontSize: 12.sp,
                                              color:
                                                  AppTheme.textSecondaryLight,
                                            ),
                                          ),
                                          Text(
                                            _closingTime.format(context),
                                            style: GoogleFonts.inter(
                                              fontSize: 14.sp,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 16.h),

                        // Initial Status
                        Text(
                          'Initial Status',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 8.h),
                        DropdownButtonFormField<String>(
                          value: _selectedStatus,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.sp),
                            ),
                            prefixIcon: CustomIconWidget(
                              iconName: 'toggle_on',
                              color: AppTheme.textSecondaryLight,
                              size: 20,
                            ),
                          ),
                          items: _statuses
                              .map((status) => DropdownMenuItem(
                                    value: status,
                                    child: Text(
                                      status.toUpperCase(),
                                      style: GoogleFonts.inter(fontSize: 14.sp),
                                    ),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(() {
                              _selectedStatus = value!;
                            });
                          },
                        ),

                        SizedBox(height: 32.h),

                        // Action Buttons
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => Navigator.pop(context),
                                child: Text(
                                  'Cancel',
                                  style: GoogleFonts.inter(
                                    fontSize: 14.sp,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: ElevatedButton(
                                onPressed:
                                    _isLoading ? null : _handleAddLocation,
                                child: _isLoading
                                    ? SizedBox(
                                        width: 20.w,
                                        height: 20.h,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: Colors.white,
                                        ),
                                      )
                                    : Text(
                                        'Add Location',
                                        style: GoogleFonts.inter(
                                          fontSize: 14.sp,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 32.h),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _selectTime(BuildContext context, bool isOpening) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: isOpening ? _openingTime : _closingTime,
    );

    if (picked != null) {
      setState(() {
        if (isOpening) {
          _openingTime = picked;
        } else {
          _closingTime = picked;
        }
      });
    }
  }

  Future<void> _handleAddLocation() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 1));

      final newLocation = {
        'id': 'LOC_${DateTime.now().millisecondsSinceEpoch}',
        'name': _nameController.text.trim(),
        'city': _selectedCity,
        'address': _addressController.text.trim(),
        'status': _selectedStatus,
        'agents_count': 0,
        'capacity': int.parse(_capacityController.text),
        'operating_hours':
            '${_openingTime.format(context)}-${_closingTime.format(context)}',
        'trade_volume': 0,
        'coordinates': {
          'lat': 19.0760 + (DateTime.now().millisecond / 10000),
          'lng': 72.8777 + (DateTime.now().millisecond / 10000),
        },
        'created_at': DateTime.now().toIso8601String(),
      };

      widget.onLocationAdded(newLocation);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to add location: $e'),
          backgroundColor: AppTheme.errorLight,
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }
}
