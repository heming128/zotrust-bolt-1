import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class LocationMapWidget extends StatefulWidget {
  final List<Map<String, dynamic>> locations;
  final Function(Map<String, dynamic>) onLocationTap;

  const LocationMapWidget({
    super.key,
    required this.locations,
    required this.onLocationTap,
  });

  @override
  State<LocationMapWidget> createState() => _LocationMapWidgetState();
}

class _LocationMapWidgetState extends State<LocationMapWidget> {
  Map<String, dynamic>? _selectedLocation;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          // Map placeholder (would integrate with Google Maps in production)
          Expanded(
            flex: 3,
            child: Container(
              margin: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: AppTheme.getNeutralColor(true).withAlpha(51),
                borderRadius: BorderRadius.circular(12.sp),
                border: Border.all(
                  color: AppTheme.getNeutralColor(true),
                ),
              ),
              child: Stack(
                children: [
                  // Map background
                  Container(
                    width: double.infinity,
                    height: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12.sp),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          AppTheme.primaryLight.withAlpha(26),
                          AppTheme.successLight.withAlpha(26),
                        ],
                      ),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'map',
                            color: AppTheme.textSecondaryLight,
                            size: 48,
                          ),
                          SizedBox(height: 16.h),
                          Text(
                            'Interactive Map View',
                            style: GoogleFonts.inter(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textPrimaryLight,
                            ),
                          ),
                          SizedBox(height: 8.h),
                          Text(
                            'Google Maps integration would be implemented here',
                            textAlign: TextAlign.center,
                            style: GoogleFonts.inter(
                              fontSize: 12.sp,
                              color: AppTheme.textSecondaryLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // Location markers simulation
                  ...widget.locations.asMap().entries.map((entry) {
                    final index = entry.key;
                    final location = entry.value;

                    // Simulate marker positions
                    final left = (index % 3) * 25.0 + 15.0;
                    final top = (index ~/ 3) * 20.0 + 15.0;

                    return Positioned(
                      left: left.w,
                      top: top.h,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedLocation = location;
                          });
                        },
                        child: _buildMapMarker(
                            location, _selectedLocation == location),
                      ),
                    );
                  }),

                  // Map controls
                  Positioned(
                    top: 16.h,
                    right: 16.w,
                    child: Column(
                      children: [
                        _buildMapControl(Icons.zoom_in, () {}),
                        SizedBox(height: 8.h),
                        _buildMapControl(Icons.zoom_out, () {}),
                        SizedBox(height: 8.h),
                        _buildMapControl(Icons.my_location, () {}),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Location details panel
          if (_selectedLocation != null)
            Container(
              margin: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
              padding: EdgeInsets.all(16.sp),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(12.sp),
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.shadowLight,
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: _buildLocationDetails(_selectedLocation!),
            ),

          // Locations list
          Expanded(
            flex: 1,
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 16.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        'All Locations',
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight,
                        ),
                      ),
                      SizedBox(width: 8.w),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: 8.w, vertical: 2.h),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryLight.withAlpha(26),
                          borderRadius: BorderRadius.circular(8.sp),
                        ),
                        child: Text(
                          '${widget.locations.length}',
                          style: GoogleFonts.inter(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.primaryLight,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 8.h),
                  Expanded(
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: widget.locations.length,
                      itemBuilder: (context, index) {
                        final location = widget.locations[index];
                        final isSelected = _selectedLocation == location;

                        return Container(
                          width: 200.w,
                          margin: EdgeInsets.only(right: 12.w),
                          child: _buildLocationListItem(location, isSelected),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMapMarker(Map<String, dynamic> location, bool isSelected) {
    final status = location['status'] as String;
    Color markerColor;

    switch (status) {
      case 'active':
        markerColor = AppTheme.successLight;
        break;
      case 'inactive':
        markerColor = AppTheme.errorLight;
        break;
      case 'maintenance':
        markerColor = AppTheme.warningLight;
        break;
      default:
        markerColor = AppTheme.textSecondaryLight;
    }

    return Container(
      width: isSelected ? 40.w : 32.w,
      height: isSelected ? 40.w : 32.w,
      decoration: BoxDecoration(
        color: markerColor,
        shape: BoxShape.circle,
        border: Border.all(
          color: Colors.white,
          width: isSelected ? 3 : 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(51),
            blurRadius: isSelected ? 8 : 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: CustomIconWidget(
          iconName: 'location_on',
          color: Colors.white,
          size: isSelected ? 20 : 16,
        ),
      ),
    );
  }

  Widget _buildMapControl(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 40.w,
        height: 40.w,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(8.sp),
          boxShadow: [
            BoxShadow(
              color: AppTheme.shadowLight,
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Icon(
          icon,
          color: AppTheme.textPrimaryLight,
          size: 20.sp,
        ),
      ),
    );
  }

  Widget _buildLocationDetails(Map<String, dynamic> location) {
    final agentsCount = location['agents_count'] as int;
    final capacity = location['capacity'] as int;
    final tradeVolume = location['trade_volume'] as int;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    location['name'] ?? 'Unknown Location',
                    style: GoogleFonts.inter(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimaryLight,
                    ),
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    location['address'] ?? '',
                    style: GoogleFonts.inter(
                      fontSize: 12.sp,
                      color: AppTheme.textSecondaryLight,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            IconButton(
              onPressed: () {
                setState(() {
                  _selectedLocation = null;
                });
              },
              icon: CustomIconWidget(
                iconName: 'close',
                color: AppTheme.textSecondaryLight,
                size: 20,
              ),
            ),
          ],
        ),
        SizedBox(height: 16.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildDetailItem(
                'Agents', '$agentsCount/$capacity', AppTheme.primaryLight),
            _buildDetailItem('Volume', '₹${_formatVolume(tradeVolume)}',
                AppTheme.successLight),
            _buildDetailItem(
                'Status',
                (location['status'] as String).toUpperCase(),
                _getStatusColor(location['status'])),
          ],
        ),
        SizedBox(height: 16.h),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: () => widget.onLocationTap(location),
            icon: CustomIconWidget(
              iconName: 'visibility',
              color: Colors.white,
              size: 16,
            ),
            label: Text(
              'View Details',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w500,
                color: Colors.white,
              ),
            ),
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(vertical: 12.h),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLocationListItem(
      Map<String, dynamic> location, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedLocation = location;
        });
      },
      child: Container(
        padding: EdgeInsets.all(12.sp),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primaryLight.withAlpha(26)
              : Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(8.sp),
          border: Border.all(
            color: isSelected
                ? AppTheme.primaryLight
                : AppTheme.getNeutralColor(true).withAlpha(51),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              location['name'] ?? 'Unknown Location',
              style: GoogleFonts.inter(
                fontSize: 14.sp,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimaryLight,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 4.h),
            Text(
              location['city'] ?? '',
              style: GoogleFonts.inter(
                fontSize: 12.sp,
                color: AppTheme.textSecondaryLight,
              ),
            ),
            SizedBox(height: 8.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                  decoration: BoxDecoration(
                    color: _getStatusColor(location['status']).withAlpha(26),
                    borderRadius: BorderRadius.circular(4.sp),
                  ),
                  child: Text(
                    (location['status'] as String).toUpperCase(),
                    style: GoogleFonts.inter(
                      fontSize: 10.sp,
                      fontWeight: FontWeight.w500,
                      color: _getStatusColor(location['status']),
                    ),
                  ),
                ),
                Text(
                  '${location['agents_count']} agents',
                  style: GoogleFonts.inter(
                    fontSize: 10.sp,
                    color: AppTheme.textSecondaryLight,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        SizedBox(height: 2.h),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 10.sp,
            color: AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'active':
        return AppTheme.successLight;
      case 'inactive':
        return AppTheme.errorLight;
      case 'maintenance':
        return AppTheme.warningLight;
      default:
        return AppTheme.textSecondaryLight;
    }
  }

  String _formatVolume(int volume) {
    if (volume >= 100000) {
      return '${(volume / 100000).toStringAsFixed(1)}L';
    } else if (volume >= 1000) {
      return '${(volume / 1000).toStringAsFixed(1)}K';
    } else {
      return volume.toString();
    }
  }
}