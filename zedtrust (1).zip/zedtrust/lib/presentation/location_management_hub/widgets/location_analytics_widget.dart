import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class LocationAnalyticsWidget extends StatelessWidget {
  final List<Map<String, dynamic>> locations;
  final VoidCallback onExportReport;

  const LocationAnalyticsWidget({
    super.key,
    required this.locations,
    required this.onExportReport,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16.sp),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with export button
          Row(
            children: [
              Expanded(
                child: Text(
                  'Location Analytics',
                  style: GoogleFonts.inter(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimaryLight,
                  ),
                ),
              ),
              ElevatedButton.icon(
                onPressed: onExportReport,
                icon: CustomIconWidget(
                  iconName: 'file_download',
                  color: Colors.white,
                  size: 16,
                ),
                label: Text(
                  'Export',
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  padding:
                      EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
                ),
              ),
            ],
          ),

          SizedBox(height: 16.h),

          // Overview Cards
          _buildOverviewSection(),

          SizedBox(height: 24.h),

          // Performance Metrics
          _buildPerformanceSection(),

          SizedBox(height: 24.h),

          // City Distribution
          _buildCityDistributionSection(),

          SizedBox(height: 24.h),

          // Capacity Analysis
          _buildCapacityAnalysisSection(),

          SizedBox(height: 24.h),

          // Top Performers
          _buildTopPerformersSection(),
        ],
      ),
    );
  }

  Widget _buildOverviewSection() {
    final totalLocations = locations.length;
    final activeLocations =
        locations.where((loc) => loc['status'] == 'active').length;
    final totalAgents =
        locations.fold(0, (sum, loc) => sum + (loc['agents_count'] as int));
    final totalCapacity =
        locations.fold(0, (sum, loc) => sum + (loc['capacity'] as int));
    final totalVolume =
        locations.fold(0, (sum, loc) => sum + (loc['trade_volume'] as int));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Overview',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 12.h),
        Row(
          children: [
            Expanded(
              child: _buildAnalyticsCard(
                'Total Locations',
                '$totalLocations',
                AppTheme.primaryLight,
                'location_on',
              ),
            ),
            SizedBox(width: 8.w),
            Expanded(
              child: _buildAnalyticsCard(
                'Active Locations',
                '$activeLocations',
                AppTheme.successLight,
                'check_circle',
              ),
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Row(
          children: [
            Expanded(
              child: _buildAnalyticsCard(
                'Total Agents',
                '$totalAgents',
                AppTheme.primaryLight,
                'people',
              ),
            ),
            SizedBox(width: 8.w),
            Expanded(
              child: _buildAnalyticsCard(
                'Total Capacity',
                '$totalCapacity',
                AppTheme.warningLight,
                'business',
              ),
            ),
          ],
        ),
        SizedBox(height: 8.h),
        _buildAnalyticsCard(
          'Total Trade Volume',
          '₹${_formatVolume(totalVolume)}',
          AppTheme.successLight,
          'trending_up',
          isFullWidth: true,
        ),
      ],
    );
  }

  Widget _buildPerformanceSection() {
    final averageUtilization = _calculateAverageUtilization();
    final utilizationColor = averageUtilization >= 80
        ? AppTheme.warningLight
        : averageUtilization >= 60
            ? AppTheme.primaryLight
            : AppTheme.successLight;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Performance Metrics',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 12.h),
        Container(
          width: double.infinity,
          padding: EdgeInsets.all(16.sp),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.sp),
            boxShadow: [
              BoxShadow(
                color: AppTheme.shadowLight,
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  CustomIconWidget(
                    iconName: 'analytics',
                    color: utilizationColor,
                    size: 24,
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Average Capacity Utilization',
                          style: GoogleFonts.inter(
                            fontSize: 14.sp,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.textPrimaryLight,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          '${averageUtilization.toStringAsFixed(1)}%',
                          style: GoogleFonts.inter(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.w700,
                            color: utilizationColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              SizedBox(height: 16.h),

              // Utilization bar
              Container(
                height: 8.h,
                decoration: BoxDecoration(
                  color: AppTheme.getNeutralColor(true).withAlpha(51),
                  borderRadius: BorderRadius.circular(4.sp),
                ),
                child: FractionallySizedBox(
                  alignment: Alignment.centerLeft,
                  widthFactor: (averageUtilization / 100).clamp(0.0, 1.0),
                  child: Container(
                    decoration: BoxDecoration(
                      color: utilizationColor,
                      borderRadius: BorderRadius.circular(4.sp),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCityDistributionSection() {
    final cityData = <String, Map<String, dynamic>>{};

    for (final location in locations) {
      final city = location['city'] as String;
      if (!cityData.containsKey(city)) {
        cityData[city] = {
          'count': 0,
          'active': 0,
          'agents': 0,
          'volume': 0,
        };
      }
      cityData[city]!['count']++;
      if (location['status'] == 'active') {
        cityData[city]!['active']++;
      }
      cityData[city]!['agents'] += location['agents_count'] as int;
      cityData[city]!['volume'] += location['trade_volume'] as int;
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Distribution by City',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 12.h),
        ...cityData.entries.map((entry) {
          final city = entry.key;
          final data = entry.value;

          return Container(
            margin: EdgeInsets.only(bottom: 8.h),
            padding: EdgeInsets.all(16.sp),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.sp),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CustomIconWidget(
                      iconName: 'location_city',
                      color: AppTheme.primaryLight,
                      size: 20,
                    ),
                    SizedBox(width: 8.w),
                    Expanded(
                      child: Text(
                        city,
                        style: GoogleFonts.inter(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight,
                        ),
                      ),
                    ),
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 8.w, vertical: 2.h),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryLight.withAlpha(26),
                        borderRadius: BorderRadius.circular(8.sp),
                      ),
                      child: Text(
                        '${data['count']} locations',
                        style: GoogleFonts.inter(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.primaryLight,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 12.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildCityMetric(
                        'Active', '${data['active']}', AppTheme.successLight),
                    _buildCityMetric(
                        'Agents', '${data['agents']}', AppTheme.primaryLight),
                    _buildCityMetric(
                        'Volume',
                        '₹${_formatVolume(data['volume'])}',
                        AppTheme.warningLight),
                  ],
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildCapacityAnalysisSection() {
    final underutilized = locations
        .where((loc) =>
            (loc['agents_count'] as int) / (loc['capacity'] as int) < 0.5)
        .length;
    final optimal = locations.where((loc) {
      final ratio = (loc['agents_count'] as int) / (loc['capacity'] as int);
      return ratio >= 0.5 && ratio < 0.8;
    }).length;
    final overutilized = locations
        .where((loc) =>
            (loc['agents_count'] as int) / (loc['capacity'] as int) >= 0.8)
        .length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Capacity Analysis',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 12.h),
        Row(
          children: [
            Expanded(
              child: _buildCapacityCard(
                'Under-utilized',
                '$underutilized',
                '< 50%',
                AppTheme.successLight,
              ),
            ),
            SizedBox(width: 8.w),
            Expanded(
              child: _buildCapacityCard(
                'Optimal',
                '$optimal',
                '50-80%',
                AppTheme.primaryLight,
              ),
            ),
            SizedBox(width: 8.w),
            Expanded(
              child: _buildCapacityCard(
                'Over-utilized',
                '$overutilized',
                '≥ 80%',
                AppTheme.warningLight,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTopPerformersSection() {
    final sortedLocations = List<Map<String, dynamic>>.from(locations);
    sortedLocations.sort((a, b) =>
        (b['trade_volume'] as int).compareTo(a['trade_volume'] as int));
    final topPerformers = sortedLocations.take(3).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Top Performing Locations',
          style: GoogleFonts.inter(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimaryLight,
          ),
        ),
        SizedBox(height: 12.h),
        ...topPerformers.asMap().entries.map((entry) {
          final index = entry.key;
          final location = entry.value;
          final rank = index + 1;

          return Container(
            margin: EdgeInsets.only(bottom: 8.h),
            padding: EdgeInsets.all(16.sp),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12.sp),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.shadowLight,
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 32.w,
                  height: 32.w,
                  decoration: BoxDecoration(
                    color: rank == 1
                        ? AppTheme.warningLight.withAlpha(26)
                        : rank == 2
                            ? AppTheme.getNeutralColor(true).withAlpha(51)
                            : AppTheme.errorLight.withAlpha(26),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      '#$rank',
                      style: GoogleFonts.inter(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w700,
                        color: rank == 1
                            ? AppTheme.warningLight
                            : rank == 2
                                ? AppTheme.textSecondaryLight
                                : AppTheme.errorLight,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        location['name'] ?? 'Unknown Location',
                        style: GoogleFonts.inter(
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimaryLight,
                        ),
                      ),
                      Text(
                        location['city'] ?? '',
                        style: GoogleFonts.inter(
                          fontSize: 12.sp,
                          color: AppTheme.textSecondaryLight,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '₹${_formatVolume(location['trade_volume'] as int)}',
                      style: GoogleFonts.inter(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.successLight,
                      ),
                    ),
                    Text(
                      '${location['agents_count']} agents',
                      style: GoogleFonts.inter(
                        fontSize: 10.sp,
                        color: AppTheme.textSecondaryLight,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildAnalyticsCard(
      String title, String value, Color color, String iconName,
      {bool isFullWidth = false}) {
    return Container(
      width: isFullWidth ? double.infinity : null,
      padding: EdgeInsets.all(16.sp),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.sp),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8.sp),
            decoration: BoxDecoration(
              color: color.withAlpha(26),
              borderRadius: BorderRadius.circular(8.sp),
            ),
            child: CustomIconWidget(
              iconName: iconName,
              color: color,
              size: 20,
            ),
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: GoogleFonts.inter(
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w700,
                    color: color,
                  ),
                ),
                Text(
                  title,
                  style: GoogleFonts.inter(
                    fontSize: 12.sp,
                    color: AppTheme.textSecondaryLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCityMetric(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.inter(
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        Text(
          label,
          style: GoogleFonts.inter(
            fontSize: 10.sp,
            color: AppTheme.textSecondaryLight,
          ),
        ),
      ],
    );
  }

  Widget _buildCapacityCard(
      String title, String count, String range, Color color) {
    return Container(
      padding: EdgeInsets.all(12.sp),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.sp),
        boxShadow: [
          BoxShadow(
            color: AppTheme.shadowLight,
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            count,
            style: GoogleFonts.inter(
              fontSize: 20.sp,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            title,
            style: GoogleFonts.inter(
              fontSize: 11.sp,
              fontWeight: FontWeight.w500,
              color: AppTheme.textPrimaryLight,
            ),
            textAlign: TextAlign.center,
          ),
          Text(
            range,
            style: GoogleFonts.inter(
              fontSize: 9.sp,
              color: AppTheme.textSecondaryLight,
            ),
          ),
        ],
      ),
    );
  }

  double _calculateAverageUtilization() {
    if (locations.isEmpty) return 0.0;

    double totalUtilization = 0;
    int validLocations = 0;

    for (final location in locations) {
      final capacity = location['capacity'] as int;
      if (capacity > 0) {
        final utilization = (location['agents_count'] as int) / capacity;
        totalUtilization += utilization;
        validLocations++;
      }
    }

    return validLocations > 0 ? (totalUtilization / validLocations) * 100 : 0.0;
  }

  String _formatVolume(int volume) {
    if (volume >= 100000) {
      return '${(volume / 100000).toStringAsFixed(1)}L';
    } else if (volume >= 1000) {
      return '${(volume / 1000).toStringAsFixed(1)}K';
    } else {
      return volume.toString();
    }
  }
}
