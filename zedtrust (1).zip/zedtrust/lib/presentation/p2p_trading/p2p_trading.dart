import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/trade_flow_integration_service.dart';
import './widgets/p2p_amount_input_widget.dart';
import './widgets/p2p_filters_widget.dart';
import './widgets/p2p_market_overview_widget.dart';
import './widgets/p2p_order_book_widget.dart';
import './widgets/p2p_quick_actions_widget.dart';

class P2PTrading extends StatefulWidget {
  const P2PTrading({Key? key}) : super(key: key);

  @override
  State<P2PTrading> createState() => _P2PTradingState();
}

class _P2PTradingState extends State<P2PTrading>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedPaymentMethod = 'Payment';
  String _selectedCurrency = 'USDC';
  bool _isLoading = false;
  String _amountValue = '';

  // Enhanced P2P order data with proper agent branch display
  List<Map<String, dynamic>> _buyOrders = [];
  List<Map<String, dynamic>> _sellOrders = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadP2POrders();
  }

  Future<void> _loadP2POrders() async {
    setState(() => _isLoading = true);

    try {
      final tradeFlowService = TradeFlowIntegrationService.instance;

      // Load buy and sell orders with enhanced agent branch information
      final buyOrdersData = await tradeFlowService.getP2POrdersWithAgentInfo(
        orderType: 'buy',
        limit: 10,
      );

      final sellOrdersData = await tradeFlowService.getP2POrdersWithAgentInfo(
        orderType: 'sell',
        limit: 10,
      );

      setState(() {
        _buyOrders =
            buyOrdersData.isNotEmpty ? buyOrdersData : _getMockBuyOrders();
        _sellOrders =
            sellOrdersData.isNotEmpty ? sellOrdersData : _getMockSellOrders();
        _isLoading = false;
      });
    } catch (e) {
      // Fallback to mock data
      setState(() {
        _buyOrders = _getMockBuyOrders();
        _sellOrders = _getMockSellOrders();
        _isLoading = false;
      });
    }
  }

  List<Map<String, dynamic>> _getMockBuyOrders() {
    return [
      {
        "id": "P2P001",
        "trader": "Rajesh Kumar",
        "rating": 4.8,
        "trades": 245,
        "price": "83.25",
        "available": "500.00",
        "min": "4000.00",
        "max": "5000.00",
        "paymentMethods": ["Cash Exchange"],
        "online": true,
        "agent_branch_display": "CryptoKing — Downtown Mumbai",
        "formatted_agent_info": {
          "name": "CryptoKing",
          "branch": "Downtown",
          "city": "Mumbai",
          "rating": 4.8,
        },
      },
      {
        "id": "P2P002",
        "trader": "Priya Sharma",
        "rating": 4.9,
        "trades": 189,
        "price": "87.06",
        "available": "750.00",
        "min": "3500.00",
        "max": "6000.00",
        "paymentMethods": ["UPI Transfer"],
        "online": true,
        "agent_branch_display": "TrustMaster — Bandra West | Andheri East",
        "formatted_agent_info": {
          "name": "TrustMaster",
          "branch": "Bandra West",
          "city": "Mumbai",
          "rating": 4.9,
        },
      },
      {
        "id": "P2P003",
        "trader": "Amit Patel",
        "rating": 4.6,
        "trades": 156,
        "price": "90.00",
        "available": "300.00",
        "min": "2500.00",
        "max": "4500.00",
        "paymentMethods": ["Bank Transfer"],
        "online": true,
        "agent_branch_display": "SafeTrader — Koramangala Branch",
        "formatted_agent_info": {
          "name": "SafeTrader",
          "branch": "Koramangala",
          "city": "Bangalore",
          "rating": 4.6,
        },
      },
    ];
  }

  List<Map<String, dynamic>> _getMockSellOrders() {
    return [
      {
        "id": "P2P004",
        "trader": "Vikash Singh",
        "rating": 4.7,
        "trades": 298,
        "price": "84.15",
        "available": "650.00",
        "min": "4200.00",
        "max": "7500.00",
        "paymentMethods": ["Cash Exchange"],
        "online": true,
        "agent_branch_display": "QuickVerify — Connaught Place Branch",
        "formatted_agent_info": {
          "name": "QuickVerify",
          "branch": "Connaught Place",
          "city": "Delhi",
          "rating": 4.7,
        },
      },
      {
        "id": "P2P005",
        "trader": "Sunita Gupta",
        "rating": 4.4,
        "trades": 127,
        "price": "85.25",
        "available": "425.00",
        "min": "3800.00",
        "max": "5200.00",
        "paymentMethods": ["Mobile Wallet"],
        "online": false,
        "agent_branch_display": "SecureAgent — Camp Area | Kothrud",
        "formatted_agent_info": {
          "name": "SecureAgent",
          "branch": "Camp Area",
          "city": "Pune",
          "rating": 4.4,
        },
      },
      {
        "id": "P2P006",
        "trader": "Deepika Nair",
        "rating": 4.9,
        "trades": 234,
        "price": "84.80",
        "available": "890.00",
        "min": "5000.00",
        "max": "10000.00",
        "paymentMethods": ["UPI Transfer"],
        "online": true,
        "agent_branch_display": "TechnoTrade — T.Nagar Main Branch",
        "formatted_agent_info": {
          "name": "TechnoTrade",
          "branch": "T.Nagar Main",
          "city": "Chennai",
          "rating": 4.9,
        },
      },
    ];
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      elevation: 0,
      title: Text(
        'P2P Trading',
        style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppTheme.lightTheme.primaryColor,
        ),
      ),
      actions: [
        IconButton(
          onPressed: () => _showP2PHistory(),
          icon: CustomIconWidget(
            iconName: 'history',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
        IconButton(
          onPressed: () => _showP2PSettings(),
          icon: CustomIconWidget(
            iconName: 'settings',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 24,
          ),
        ),
      ],
    );
  }

  Widget _buildBody() {
    return Column(
      children: [
        // Quick Actions
        P2PQuickActionsWidget(
          onBuyPressed: () => _tabController.animateTo(0),
          onSellPressed: () => _tabController.animateTo(1),
        ),

        // Market Overview
        P2PMarketOverviewWidget(
          selectedCurrency: _selectedCurrency,
          onCurrencyChanged: (currency) {
            setState(() {
              _selectedCurrency = currency;
            });
          },
        ),

        // Filters
        P2PFiltersWidget(
          selectedPaymentMethod: _selectedPaymentMethod,
          onPaymentMethodChanged: (method) {
            setState(() {
              _selectedPaymentMethod = method;
            });
          },
        ),

        // Amount Input Widget (shown when Amount is selected)
        if (_selectedPaymentMethod == 'Amount')
          P2PAmountInputWidget(
            initialAmount: _amountValue,
            onAmountChanged: (amount) {
              setState(() {
                _amountValue = amount;
              });
            },
          ),

        // Tab Bar
        Container(
          margin: EdgeInsets.symmetric(horizontal: 4.w),
          decoration: BoxDecoration(
            color: AppTheme.lightTheme.cardColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TabBar(
            controller: _tabController,
            labelColor: Colors.white,
            unselectedLabelColor: AppTheme.lightTheme.primaryColor,
            indicator: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor,
              borderRadius: BorderRadius.circular(12),
            ),
            tabs: const [Tab(text: 'Buy USDC'), Tab(text: 'Sell USDC')],
          ),
        ),

        SizedBox(height: 2.h),

        // Tab Views with enhanced agent branch display
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              P2POrderBookWidget(
                orders: _getFilteredOrders(_buyOrders),
                orderType: 'buy',
                onOrderTap: (order) => _handleOrderTap(order, 'buy'),
                isLoading: _isLoading,
              ),
              P2POrderBookWidget(
                orders: _getFilteredOrders(_sellOrders),
                orderType: 'sell',
                onOrderTap: (order) => _handleOrderTap(order, 'sell'),
                isLoading: _isLoading,
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<Map<String, dynamic>> _getFilteredOrders(
    List<Map<String, dynamic>> orders,
  ) {
    if (_selectedPaymentMethod == 'Payment') {
      return orders;
    }

    return orders.where((order) {
      final paymentMethods = order['paymentMethods'] as List<String>;
      return paymentMethods.contains(_selectedPaymentMethod);
    }).toList();
  }

  void _handleOrderTap(Map<String, dynamic> order, String type) {
    // Enhanced order tap handling with agent branch info
    Navigator.pushNamed(
      context,
      '/p2p-order-details',
      arguments: {
        'order': order,
        'type': type,
        'agent_info': order['formatted_agent_info'],
        'agent_branch_display': order['agent_branch_display'],
      },
    );
  }

  void _showP2PHistory() {
    Navigator.pushNamed(context, '/p2p-history');
  }

  void _showP2PSettings() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder:
          (context) => Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.cardColor,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20),
              ),
            ),
            padding: EdgeInsets.all(6.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 12.w,
                  height: 0.5.h,
                  decoration: BoxDecoration(
                    color: AppTheme.getNeutralColor(true),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                SizedBox(height: 3.h),
                Text(
                  'P2P Settings',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 3.h),
                _buildSettingsItem('Payment Methods', 'payment', () {}),
                _buildSettingsItem('Trading Limits', 'account_balance', () {}),
                _buildSettingsItem('Agent Preferences', 'people', () {}),
                _buildSettingsItem('Notifications', 'notifications', () {}),
                _buildSettingsItem('Security', 'security', () {}),
                SizedBox(height: 2.h),
              ],
            ),
          ),
    );
  }

  Widget _buildSettingsItem(String title, String iconName, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: AppTheme.lightTheme.primaryColor,
        size: 24,
      ),
      title: Text(title, style: AppTheme.lightTheme.textTheme.titleMedium),
      trailing: CustomIconWidget(
        iconName: 'chevron_right',
        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
        size: 20,
      ),
      onTap: onTap,
    );
  }
}
