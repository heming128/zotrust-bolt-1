import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BiometricAuthWidget extends StatefulWidget {
  final VoidCallback onBiometricAuth;
  final bool isEnabled;

  const BiometricAuthWidget({
    Key? key,
    required this.onBiometricAuth,
    required this.isEnabled,
  }) : super(key: key);

  @override
  State<BiometricAuthWidget> createState() => _BiometricAuthWidgetState();
}

class _BiometricAuthWidgetState extends State<BiometricAuthWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _pulseAnimation;
  bool _isScanning = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isEnabled) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.grey[900]?.withAlpha(77),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[700]!),
        ),
        child: Column(
          children: [
            Icon(
              Icons.fingerprint_outlined,
              color: Colors.grey[600],
              size: 48,
            ),
            const SizedBox(height: 12),
            Text(
              'Biometric Authentication',
              style: GoogleFonts.inter(
                color: Colors.grey[500],
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Not available on web platform',
              style: GoogleFonts.inter(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3A),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2D3748)),
      ),
      child: Column(
        children: [
          Text(
            'Quick Access',
            style: GoogleFonts.inter(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _isScanning ? null : _handleBiometricAuth,
            child: AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _isScanning ? _pulseAnimation.value : 1.0,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: _isScanning
                            ? [
                                const Color(0xFF10B981),
                                const Color(0xFF059669),
                              ]
                            : [
                                const Color(0xFF3B82F6),
                                const Color(0xFF1E40AF),
                              ],
                      ),
                      borderRadius: BorderRadius.circular(50),
                      boxShadow: [
                        BoxShadow(
                          color: (_isScanning
                                  ? const Color(0xFF10B981)
                                  : const Color(0xFF3B82F6))
                              .withAlpha(77),
                          blurRadius: 20,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Icon(
                      _isScanning ? Icons.check : Icons.fingerprint,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),
          Text(
            _isScanning ? 'Authenticating...' : 'Tap for biometric login',
            style: GoogleFonts.inter(
              color: _isScanning ? Colors.green[400] : Colors.grey[400],
              fontSize: 14,
              fontWeight: FontWeight.w500,
            ),
          ),
          if (!kIsWeb) ...[
            const SizedBox(height: 12),
            Text(
              'Touch ID / Face ID / Fingerprint',
              style: GoogleFonts.inter(
                color: Colors.grey[500],
                fontSize: 12,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _handleBiometricAuth() async {
    if (_isScanning) return;

    setState(() {
      _isScanning = true;
    });

    _animationController.repeat(reverse: true);

    // Simulate biometric scanning
    await Future.delayed(const Duration(seconds: 2));

    _animationController.stop();
    _animationController.reset();

    setState(() {
      _isScanning = false;
    });

    widget.onBiometricAuth();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
