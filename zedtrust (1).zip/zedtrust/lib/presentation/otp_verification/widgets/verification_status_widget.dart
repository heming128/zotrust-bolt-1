import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

enum VerificationStatus { waiting, verifying, success, failed, timeout }

class VerificationStatusWidget extends StatelessWidget {
  final VerificationStatus status;
  final String? agentName;

  const VerificationStatusWidget({
    Key? key,
    required this.status,
    this.agentName,
  }) : super(key: key);

  Color _getStatusColor(BuildContext context) {
    switch (status) {
      case VerificationStatus.waiting:
        return AppTheme.getWarningColor(
            Theme.of(context).brightness == Brightness.light);
      case VerificationStatus.verifying:
        return Theme.of(context).colorScheme.primary;
      case VerificationStatus.success:
        return AppTheme.getSuccessColor(
            Theme.of(context).brightness == Brightness.light);
      case VerificationStatus.failed:
      case VerificationStatus.timeout:
        return Theme.of(context).colorScheme.error;
    }
  }

  String _getStatusText() {
    switch (status) {
      case VerificationStatus.waiting:
        return 'Waiting for agent verification...';
      case VerificationStatus.verifying:
        return 'Agent is verifying your code...';
      case VerificationStatus.success:
        return 'Verification successful! Trade completed.';
      case VerificationStatus.failed:
        return 'Verification failed. Please try again.';
      case VerificationStatus.timeout:
        return 'Verification timeout. Generate new code.';
    }
  }

  IconData _getStatusIcon() {
    switch (status) {
      case VerificationStatus.waiting:
        return Icons.hourglass_empty;
      case VerificationStatus.verifying:
        return Icons.sync;
      case VerificationStatus.success:
        return Icons.check_circle;
      case VerificationStatus.failed:
        return Icons.error;
      case VerificationStatus.timeout:
        return Icons.timer_off;
    }
  }

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(context);

    return Container(
      width: 90.w,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: statusColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: statusColor.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              status == VerificationStatus.verifying
                  ? SizedBox(
                      width: 6.w,
                      height: 6.w,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(statusColor),
                      ),
                    )
                  : CustomIconWidget(
                      iconName: _getStatusIcon().codePoint.toString(),
                      color: statusColor,
                      size: 24,
                    ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Verification Status',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color:
                                Theme.of(context).colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w500,
                          ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      _getStatusText(),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: statusColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (agentName != null && status != VerificationStatus.waiting) ...[
            SizedBox(height: 2.h),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .surfaceContainerHighest
                    .withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'person',
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 16,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Agent: $agentName',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
