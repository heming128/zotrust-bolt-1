import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/color_swatch_widget.dart';
import './widgets/instructions_widget.dart';
import './widgets/otp_display_widget.dart';
import './widgets/qr_code_widget.dart';
import './widgets/timer_widget.dart';
import './widgets/verification_status_widget.dart';

class OtpVerification extends StatefulWidget {
  const OtpVerification({Key? key}) : super(key: key);

  @override
  State<OtpVerification> createState() => _OtpVerificationState();
}

class _OtpVerificationState extends State<OtpVerification>
    with TickerProviderStateMixin {
  // Mock trade data - will be replaced with actual args
  Map<String, dynamic> tradeData = {
    "tradeId": "TRD-2025-001847",
    "amount": "500.00",
    "currency": "USDC",
    "buyerAddress": "0x742d35Cc6634C0532925a3b8D4C2C4e4C7C5B2A1",
    "sellerAddress": "0x8ba1f109551bD432803012645Hac136c5C2C4e4C",
    "agentName": "CryptoHub Downtown",
    "agentId": "AGT-2025-0089",
    "status": "awaiting_verification",
    "createdAt": "2025-08-18T07:45:00Z",
    "expiresAt": "2025-08-18T08:15:00Z",
  };

  // OTP and verification state
  String _currentOtp = '';
  Color _verificationColor = Colors.blue;
  String _hexValue = '';
  int _remainingSeconds = 7200; // 2 hours in seconds
  VerificationStatus _verificationStatus = VerificationStatus.waiting;

  // Timers and controllers
  Timer? _otpTimer;
  Timer? _countdownTimer;
  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  // WebSocket simulation
  Timer? _webSocketSimulation;
  bool _isConnected = true;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();

    // Get arguments from navigation
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadTradeArguments();
    });

    _startCountdownTimer();
    _simulateWebSocketConnection();
  }

  void _loadTradeArguments() {
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    if (args != null) {
      setState(() {
        tradeData = {
          "tradeId": args['tradeId'] ?? tradeData['tradeId'],
          "amount": args['amount'] ?? tradeData['amount'],
          "currency": "USDC",
          "usdcAmount": args['usdcAmount'] ?? "0.00",
          "traderName": args['traderName'] ?? "Unknown Trader",
          "buyerAddress": "0x742d35Cc6634C0532925a3b8D4C2C4e4C7C5B2A1",
          "sellerAddress": "0x8ba1f109551bD432803012645Hac136c5C2C4e4C",
          "agentName": "CryptoHub Downtown",
          "agentId": "AGT-2025-0089",
          "status": "awaiting_verification",
          "createdAt": DateTime.now().toIso8601String(),
          "expiresAt": args['expiryTime']?.toIso8601String() ??
              DateTime.now().add(const Duration(hours: 2)).toIso8601String(),
        };

        _currentOtp = args['otp'] ?? _currentOtp;
        _verificationColor = args['color'] ?? _verificationColor;
        _hexValue = args['hexValue'] ?? _hexValue;

        // Calculate remaining seconds from expiry time
        if (args['expiryTime'] != null) {
          final expiryTime = args['expiryTime'] as DateTime;
          final now = DateTime.now();
          _remainingSeconds =
              expiryTime.difference(now).inSeconds.clamp(0, 7200);
        }
      });
    }
  }

  void _initializeAnimations() {
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeIn,
    ));

    _slideController.forward();
    _fadeController.forward();
  }

  void _generateNewOtpAndColor() {
    final random = Random();

    // Generate 6-digit OTP
    _currentOtp = (100000 + random.nextInt(900000)).toString();

    // Generate random color
    _verificationColor = Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );

    // Convert to hex
    _hexValue =
        '#${_verificationColor.value.toRadixString(16).substring(2).toUpperCase()}';

    // Reset timer
    _remainingSeconds = 30;
    _verificationStatus = VerificationStatus.waiting;

    setState(() {});
  }

  void _startCountdownTimer() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() {
          _remainingSeconds--;
        });
      } else {
        timer.cancel();
        // Trade expired
        setState(() {
          _verificationStatus = VerificationStatus.failed;
        });
        _showTradeExpiredDialog();
      }
    });
  }

  void _showTradeExpiredDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'timer_off',
              color: AppTheme.lightTheme.colorScheme.error,
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Trade Expired',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.error,
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your trade has expired after 2 hours. The locked USDC has been released back to your wallet.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.error
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Trade ID: ${tradeData["tradeId"]}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Text(
                    'Amount: ₹${tradeData["amount"]}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  Text(
                    'USDC Released: ${tradeData["usdcAmount"]} USDC',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/trade-history');
            },
            child: Text('View History'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/dashboard');
            },
            child: Text('Back to Dashboard'),
          ),
        ],
      ),
    );
  }

  void _simulateWebSocketConnection() {
    // Simulate random agent verification after 10-20 seconds
    _webSocketSimulation = Timer(
      Duration(seconds: 10 + Random().nextInt(10)),
      () {
        if (_verificationStatus == VerificationStatus.waiting) {
          setState(() {
            _verificationStatus = VerificationStatus.verifying;
          });

          // Simulate verification process
          Timer(const Duration(seconds: 3), () {
            if (mounted) {
              final success = Random().nextBool();
              setState(() {
                _verificationStatus = success
                    ? VerificationStatus.success
                    : VerificationStatus.failed;
              });

              if (success) {
                _showSuccessDialog();
              }
            }
          });
        }
      },
    );
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.getSuccessColor(
                  Theme.of(context).brightness == Brightness.light),
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Trade Completed!',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppTheme.getSuccessColor(
                        Theme.of(context).brightness == Brightness.light),
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your trade has been successfully verified and completed.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.getSuccessColor(
                        Theme.of(context).brightness == Brightness.light)
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Trade ID: ${tradeData["tradeId"]}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  Text(
                    'Amount: ₹${tradeData["amount"]}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  Text(
                    'USDC Locked: ${tradeData["usdcAmount"] ?? tradeData["amount"]} USDC',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  Text(
                    'Trader: ${tradeData["traderName"] ?? "Unknown"}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/trade-history');
            },
            child: Text('View History'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/dashboard');
            },
            child: Text('Back to Dashboard'),
          ),
        ],
      ),
    );
  }

  String _generateQrData() {
    return jsonEncode({
      'otp': _currentOtp,
      'color': _hexValue,
      'tradeId': tradeData['tradeId'],
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    });
  }

  void _handleCopyOtp() {
    Fluttertoast.showToast(
      msg: "OTP copied to clipboard",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.getSuccessColor(
          Theme.of(context).brightness == Brightness.light),
      textColor: Colors.white,
    );
  }

  void _handleCopyHex() {
    Fluttertoast.showToast(
      msg: "Color code copied to clipboard",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.getSuccessColor(
          Theme.of(context).brightness == Brightness.light),
      textColor: Colors.white,
    );
  }

  void _handleShareQr() {
    final qrData = _generateQrData();
    Share.share(
      'ZedTrust Verification Code\n\nOTP: $_currentOtp\nColor: $_hexValue\nTrade ID: ${tradeData["tradeId"]}\n\nScan QR or verify manually with your agent.',
      subject: 'ZedTrust Trade Verification',
    );
  }

  void _handleCancelTrade() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Text(
          'Cancel Trade?',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
        ),
        content: Text(
          'Are you sure you want to cancel this trade? This action cannot be undone and the escrow will be released back to the buyer.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Keep Trade'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.pushReplacementNamed(context, '/dashboard');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: Text(
              'Cancel Trade',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _otpTimer?.cancel();
    _countdownTimer?.cancel();
    _webSocketSimulation?.cancel();
    _slideController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          Theme.of(context).colorScheme.surface.withValues(alpha: 0.95),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: double.infinity,
            height: double.infinity,
            color: Colors.black.withValues(alpha: 0.5),
            child: Center(
              child: GestureDetector(
                onTap: () {}, // Prevent dismissal when tapping modal content
                child: SlideTransition(
                  position: _slideAnimation,
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: Container(
                      width: 95.w,
                      constraints: BoxConstraints(maxHeight: 90.h),
                      margin: EdgeInsets.symmetric(horizontal: 2.5.w),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.2),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          // Header
                          Container(
                            width: double.infinity,
                            padding: EdgeInsets.all(4.w),
                            decoration: BoxDecoration(
                              color: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer
                                  .withValues(alpha: 0.1),
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(20),
                                topRight: Radius.circular(20),
                              ),
                            ),
                            child: Row(
                              children: [
                                CustomIconWidget(
                                  iconName: 'security',
                                  color: Theme.of(context).colorScheme.primary,
                                  size: 24,
                                ),
                                SizedBox(width: 3.w),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Agent Verification',
                                        style: Theme.of(context)
                                            .textTheme
                                            .titleLarge
                                            ?.copyWith(
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .primary,
                                              fontWeight: FontWeight.w700,
                                            ),
                                      ),
                                      Text(
                                        'Trade ID: ${tradeData["tradeId"]}',
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodySmall
                                            ?.copyWith(
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .onSurfaceVariant,
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  onPressed: () => Navigator.of(context).pop(),
                                  icon: CustomIconWidget(
                                    iconName: 'close',
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceVariant,
                                    size: 20,
                                  ),
                                ),
                              ],
                            ),
                          ),

                          // Scrollable content
                          Flexible(
                            child: SingleChildScrollView(
                              padding: EdgeInsets.all(4.w),
                              child: Column(
                                children: [
                                  // Network status indicator
                                  if (!_isConnected)
                                    Container(
                                      width: double.infinity,
                                      padding: EdgeInsets.all(2.w),
                                      margin: EdgeInsets.only(bottom: 2.h),
                                      decoration: BoxDecoration(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .error
                                            .withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: Theme.of(context)
                                              .colorScheme
                                              .error
                                              .withValues(alpha: 0.3),
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          CustomIconWidget(
                                            iconName: 'wifi_off',
                                            color: Theme.of(context)
                                                .colorScheme
                                                .error,
                                            size: 16,
                                          ),
                                          SizedBox(width: 2.w),
                                          Text(
                                            'Connection lost. Retrying...',
                                            style: Theme.of(context)
                                                .textTheme
                                                .bodySmall
                                                ?.copyWith(
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .error,
                                                ),
                                          ),
                                        ],
                                      ),
                                    ),

                                  // Timer widget
                                  TimerWidget(
                                    remainingSeconds: _remainingSeconds,
                                    onRefresh: () {
                                      _generateNewOtpAndColor();
                                      _startCountdownTimer();
                                    },
                                  ),
                                  SizedBox(height: 2.h),

                                  // OTP display
                                  OtpDisplayWidget(
                                    otp: _currentOtp,
                                    onCopy: _handleCopyOtp,
                                  ),
                                  SizedBox(height: 2.h),

                                  // Color swatch
                                  ColorSwatchWidget(
                                    verificationColor: _verificationColor,
                                    hexValue: _hexValue,
                                    onCopyHex: _handleCopyHex,
                                  ),
                                  SizedBox(height: 2.h),

                                  // QR code
                                  QrCodeWidget(
                                    qrData: _generateQrData(),
                                    onShare: _handleShareQr,
                                  ),
                                  SizedBox(height: 2.h),

                                  // Verification status
                                  VerificationStatusWidget(
                                    status: _verificationStatus,
                                    agentName: tradeData["agentName"],
                                  ),
                                  SizedBox(height: 2.h),

                                  // Instructions
                                  const InstructionsWidget(),
                                  SizedBox(height: 3.h),

                                  // Action buttons
                                  Row(
                                    children: [
                                      Expanded(
                                        child: OutlinedButton(
                                          onPressed: _handleCancelTrade,
                                          style: OutlinedButton.styleFrom(
                                            padding: EdgeInsets.symmetric(
                                                vertical: 1.5.h),
                                            side: BorderSide(
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .error,
                                              width: 1.5,
                                            ),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          child: Text(
                                            'Cancel Trade',
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelLarge
                                                ?.copyWith(
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .error,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 3.w),
                                      Expanded(
                                        child: ElevatedButton(
                                          onPressed: () => Navigator.pushNamed(
                                              context, '/in-app-chat'),
                                          style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                AppTheme.getAccentColor(
                                                    Theme.of(context)
                                                            .brightness ==
                                                        Brightness.light),
                                            padding: EdgeInsets.symmetric(
                                                vertical: 1.5.h),
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                            ),
                                          ),
                                          child: Text(
                                            'Contact Agent',
                                            style: Theme.of(context)
                                                .textTheme
                                                .labelLarge
                                                ?.copyWith(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
