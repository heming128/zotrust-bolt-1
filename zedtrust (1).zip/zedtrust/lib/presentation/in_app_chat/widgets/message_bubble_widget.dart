import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

enum MessageType { text, otp, tradeStatus, system, document }

class MessageBubbleWidget extends StatelessWidget {
  final String message;
  final bool isSent;
  final DateTime timestamp;
  final MessageType messageType;
  final bool isDelivered;
  final bool isRead;
  final String? senderName;
  final VoidCallback? onCopy;
  final VoidCallback? onForward;
  final VoidCallback? onReport;
  final VoidCallback? onDelete;
  final String? documentUrl;
  final String? documentName;

  const MessageBubbleWidget({
    Key? key,
    required this.message,
    required this.isSent,
    required this.timestamp,
    this.messageType = MessageType.text,
    this.isDelivered = false,
    this.isRead = false,
    this.senderName,
    this.onCopy,
    this.onForward,
    this.onReport,
    this.onDelete,
    this.documentUrl,
    this.documentName,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: Row(
        mainAxisAlignment:
            isSent ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isSent && messageType != MessageType.system) ...[
            _buildAvatar(context),
            SizedBox(width: 2.w),
          ],
          Flexible(
            child: GestureDetector(
              onLongPress: () => _showContextMenu(context),
              child: Container(
                constraints: BoxConstraints(maxWidth: 75.w),
                child: _buildMessageContainer(context),
              ),
            ),
          ),
          if (isSent) ...[
            SizedBox(width: 2.w),
            _buildDeliveryStatus(context),
          ],
        ],
      ),
    );
  }

  Widget _buildAvatar(BuildContext context) {
    if (messageType == MessageType.system) return const SizedBox.shrink();

    return Container(
      width: 8.w,
      height: 8.w,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          senderName?.substring(0, 1).toUpperCase() ?? 'C',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: AppTheme.lightTheme.primaryColor,
                fontWeight: FontWeight.w600,
              ),
        ),
      ),
    );
  }

  Widget _buildMessageContainer(BuildContext context) {
    if (messageType == MessageType.system) {
      return _buildSystemMessage(context);
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: _getMessageDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isSent && senderName != null) ...[
            Text(
              senderName!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 0.5.h),
          ],
          _buildMessageContent(context),
          SizedBox(height: 1.h),
          _buildMessageFooter(context),
        ],
      ),
    );
  }

  BoxDecoration _getMessageDecoration(BuildContext context) {
    final bool isIOS = !kIsWeb && Platform.isIOS;
    final Color backgroundColor =
        isSent ? AppTheme.lightTheme.primaryColor : Theme.of(context).cardColor;

    if (isIOS) {
      // iOS-style rounded rectangles with tail indicators
      return BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(4.w),
          topRight: Radius.circular(4.w),
          bottomLeft: isSent ? Radius.circular(4.w) : Radius.circular(1.w),
          bottomRight: isSent ? Radius.circular(1.w) : Radius.circular(4.w),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      );
    } else {
      // Android Material Design cards with elevation
      return BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(3.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      );
    }
  }

  Widget _buildMessageContent(BuildContext context) {
    switch (messageType) {
      case MessageType.text:
        return _buildTextMessage(context);
      case MessageType.otp:
        return _buildOtpMessage(context);
      case MessageType.tradeStatus:
        return _buildTradeStatusMessage(context);
      case MessageType.document:
        return _buildDocumentMessage(context);
      default:
        return _buildTextMessage(context);
    }
  }

  Widget _buildTextMessage(BuildContext context) {
    return Text(
      message,
      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color:
                isSent ? Colors.white : Theme.of(context).colorScheme.onSurface,
            height: 1.4,
          ),
    );
  }

  Widget _buildOtpMessage(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.getSuccessColor(true).withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'verified_user',
                color: AppTheme.getSuccessColor(true),
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'OTP Shared',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: AppTheme.getSuccessColor(true),
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            message,
            style: AppTheme.dataTextStyle(
              isLight: true,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ).copyWith(
              color: AppTheme.getSuccessColor(true),
            ),
          ),
          SizedBox(height: 1.h),
          Text(
            'Verification code for trade authentication',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.getSuccessColor(true),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradeStatusMessage(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'update',
                color: AppTheme.lightTheme.primaryColor,
                size: 5.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Trade Status Update',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: AppTheme.lightTheme.primaryColor,
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.primaryColor,
                  fontWeight: FontWeight.w500,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildDocumentMessage(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: Theme.of(context).dividerColor,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(1.w),
            ),
            child: CustomIconWidget(
              iconName: 'description',
              color: AppTheme.lightTheme.primaryColor,
              size: 6.w,
            ),
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  documentName ?? 'Trade Document',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  'Tap to download',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.primaryColor,
                      ),
                ),
              ],
            ),
          ),
          CustomIconWidget(
            iconName: 'download',
            color: AppTheme.lightTheme.primaryColor,
            size: 5.w,
          ),
        ],
      ),
    );
  }

  Widget _buildSystemMessage(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 1.h),
      child: Center(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
          decoration: BoxDecoration(
            color: AppTheme.getNeutralColor(true).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(5.w),
          ),
          child: Text(
            message,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTheme.getNeutralColor(true),
                  fontWeight: FontWeight.w500,
                ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  Widget _buildMessageFooter(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          _formatTimestamp(),
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: isSent
                    ? Colors.white.withValues(alpha: 0.7)
                    : Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 10.sp,
              ),
        ),
        if (messageType == MessageType.otp ||
            messageType == MessageType.tradeStatus) ...[
          SizedBox(width: 2.w),
          CustomIconWidget(
            iconName: 'security',
            color: isSent
                ? Colors.white.withValues(alpha: 0.7)
                : AppTheme.getSuccessColor(true),
            size: 3.w,
          ),
        ],
      ],
    );
  }

  Widget _buildDeliveryStatus(BuildContext context) {
    return Column(
      children: [
        if (isRead)
          CustomIconWidget(
            iconName: 'done_all',
            color: AppTheme.getSuccessColor(true),
            size: 4.w,
          )
        else if (isDelivered)
          CustomIconWidget(
            iconName: 'done_all',
            color: AppTheme.getNeutralColor(true),
            size: 4.w,
          )
        else
          CustomIconWidget(
            iconName: 'done',
            color: AppTheme.getNeutralColor(true),
            size: 4.w,
          ),
      ],
    );
  }

  String _formatTimestamp() {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'now';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes}m';
    } else if (difference.inDays < 1) {
      return '${difference.inHours}h';
    } else {
      return '${timestamp.day}/${timestamp.month}';
    }
  }

  void _showContextMenu(BuildContext context) {
    if (messageType == MessageType.system) return;

    HapticFeedback.lightImpact();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.getNeutralColor(true),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Message Actions',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
            ),
            SizedBox(height: 2.h),
            _buildContextMenuItem(context, 'Copy', 'content_copy', onCopy),
            if (messageType == MessageType.text)
              _buildContextMenuItem(context, 'Forward', 'forward', onForward),
            _buildContextMenuItem(context, 'Report', 'flag', onReport),
            if (isSent)
              _buildContextMenuItem(context, 'Delete', 'delete', onDelete),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildContextMenuItem(
    BuildContext context,
    String title,
    String iconName,
    VoidCallback? onTap,
  ) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: title == 'Delete' || title == 'Report'
            ? Theme.of(context).colorScheme.error
            : AppTheme.lightTheme.primaryColor,
        size: 24,
      ),
      title: Text(
        title,
        style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: title == 'Delete' || title == 'Report'
                  ? Theme.of(context).colorScheme.error
                  : null,
            ),
      ),
      onTap: () {
        Navigator.pop(context);
        if (onTap != null) {
          HapticFeedback.lightImpact();
          onTap();
        }
      },
    );
  }
}
