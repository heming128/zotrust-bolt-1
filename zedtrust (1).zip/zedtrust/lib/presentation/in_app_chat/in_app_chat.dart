import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/chat_input_widget.dart';
import './widgets/emergency_report_widget.dart';
import './widgets/message_bubble_widget.dart';
import './widgets/typing_indicator_widget.dart';
import './widgets/voip_call_widget.dart';

class InAppChat extends StatefulWidget {
  const InAppChat({Key? key}) : super(key: key);

  @override
  State<InAppChat> createState() => _InAppChatState();
}

class _InAppChatState extends State<InAppChat> with TickerProviderStateMixin {
  late ScrollController _scrollController;
  late AnimationController _headerAnimationController;
  late Animation<double> _headerAnimation;

  Timer? _typingTimer;
  Timer? _connectionTimer;
  Timer? _callTimer;

  String _counterpartyId = '';
  String _counterpartyName = '';
  String _tradeId = '';
  bool _isTyping = false;
  bool _counterpartyTyping = false;
  bool _isOnline = true;
  bool _isE2EEnabled = true;
  bool _isCallActive = false;
  CallState _callState = CallState.idle;
  Duration _callDuration = Duration.zero;
  bool _isMuted = false;
  bool _isSpeakerOn = false;
  int _unreadCount = 0;

  final List<Map<String, dynamic>> _messages = [
    {
      'id': 'msg001',
      'message':
          'Welcome to secure chat! All messages are end-to-end encrypted.',
      'type': MessageType.system,
      'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
      'isSent': false,
      'isDelivered': true,
      'isRead': true,
    },
    {
      'id': 'msg002',
      'message':
          'Hi! I\'m ready to proceed with our trade. The amount looks correct on my end.',
      'type': MessageType.text,
      'timestamp':
          DateTime.now().subtract(const Duration(hours: 1, minutes: 45)),
      'isSent': false,
      'isDelivered': true,
      'isRead': true,
      'senderName': 'Alex Thompson',
    },
    {
      'id': 'msg003',
      'message':
          'Perfect! I\'ve confirmed the details. Should we proceed with OTP verification?',
      'type': MessageType.text,
      'timestamp':
          DateTime.now().subtract(const Duration(hours: 1, minutes: 30)),
      'isSent': true,
      'isDelivered': true,
      'isRead': true,
    },
    {
      'id': 'msg004',
      'message':
          'Trade status updated to "Payment Pending". Awaiting confirmation from buyer.',
      'type': MessageType.tradeStatus,
      'timestamp':
          DateTime.now().subtract(const Duration(hours: 1, minutes: 15)),
      'isSent': false,
      'isDelivered': true,
      'isRead': true,
    },
    {
      'id': 'msg005',
      'message': '847291',
      'type': MessageType.otp,
      'timestamp': DateTime.now().subtract(const Duration(minutes: 45)),
      'isSent': false,
      'isDelivered': true,
      'isRead': true,
      'senderName': 'Alex Thompson',
    },
    {
      'id': 'msg006',
      'message': 'OTP received and verified successfully. Payment completed!',
      'type': MessageType.text,
      'timestamp': DateTime.now().subtract(const Duration(minutes: 30)),
      'isSent': true,
      'isDelivered': true,
      'isRead': true,
    },
  ];

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _setupAnimations();
    _simulateConnection();

    // Get arguments from navigation
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final args =
          ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>? ??
              {};
      setState(() {
        _counterpartyId =
            args['counterpartyId'] ?? args['agentId'] ?? 'user_001';
        _counterpartyName =
            args['counterpartyName'] ?? args['agentName'] ?? 'Alex Thompson';
        _tradeId = args['tradeId'] ?? 'TXN001';
      });
    });
  }

  void _setupAnimations() {
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _headerAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _headerAnimationController,
      curve: Curves.easeInOut,
    ));

    _headerAnimationController.forward();
  }

  void _simulateConnection() {
    // Simulate WebSocket connection status
    _connectionTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
      if (mounted) {
        setState(() {
          _isOnline =
              DateTime.now().millisecond % 100 > 10; // 90% uptime simulation
        });
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _headerAnimationController.dispose();
    _typingTimer?.cancel();
    _connectionTimer?.cancel();
    _callTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(child: _buildMessagesList()),
              _buildTypingIndicator(),
              _buildChatInput(),
            ],
          ),
          if (!_isCallActive) ...[
            VoipCallWidget(
              counterpartyName: _counterpartyName,
              isCallActive: _isCallActive,
              callState: _callState,
              callDuration: _callDuration,
              isMuted: _isMuted,
              isSpeakerOn: _isSpeakerOn,
              isAvailable: _isOnline,
              onStartCall: _startCall,
              onEndCall: _endCall,
              onToggleMute: _toggleMute,
              onToggleSpeaker: _toggleSpeaker,
            ),
            EmergencyReportWidget(
              tradeId: _tradeId,
              onReport: _handleEmergencyReport,
              onEscalate: _handleEscalateDispute,
            ),
          ],
          if (_isCallActive)
            VoipCallWidget(
              counterpartyName: _counterpartyName,
              isCallActive: _isCallActive,
              callState: _callState,
              callDuration: _callDuration,
              isMuted: _isMuted,
              isSpeakerOn: _isSpeakerOn,
              isAvailable: _isOnline,
              onStartCall: _startCall,
              onEndCall: _endCall,
              onToggleMute: _toggleMute,
              onToggleSpeaker: _toggleSpeaker,
            ),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      elevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle.dark,
      leading: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: CustomIconWidget(
          iconName: 'arrow_back',
          color: Theme.of(context).colorScheme.onSurface,
          size: 24,
        ),
      ),
      title: AnimatedBuilder(
        animation: _headerAnimation,
        builder: (context, child) {
          return Opacity(
            opacity: _headerAnimation.value,
            child: Row(
              children: [
                Container(
                  width: 10.w,
                  height: 10.w,
                  decoration: BoxDecoration(
                    color:
                        AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      _counterpartyName.isNotEmpty
                          ? _counterpartyName.substring(0, 1).toUpperCase()
                          : 'C',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            color: AppTheme.lightTheme.primaryColor,
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  ),
                ),
                SizedBox(width: 3.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _counterpartyName.isNotEmpty
                            ? _counterpartyName
                            : 'Loading...',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                        overflow: TextOverflow.ellipsis,
                      ),
                      Row(
                        children: [
                          Container(
                            width: 2.w,
                            height: 2.w,
                            decoration: BoxDecoration(
                              color: _isOnline
                                  ? AppTheme.getSuccessColor(true)
                                  : AppTheme.getNeutralColor(true),
                              shape: BoxShape.circle,
                            ),
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            _counterpartyTyping
                                ? 'typing...'
                                : _isOnline
                                    ? 'online'
                                    : 'last seen recently',
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: _counterpartyTyping
                                          ? AppTheme.lightTheme.primaryColor
                                          : Theme.of(context)
                                              .colorScheme
                                              .onSurfaceVariant,
                                      fontStyle: _counterpartyTyping
                                          ? FontStyle.italic
                                          : FontStyle.normal,
                                    ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
      actions: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
          margin: EdgeInsets.only(right: 2.w),
          decoration: BoxDecoration(
            color: _isE2EEnabled
                ? AppTheme.getSuccessColor(true).withValues(alpha: 0.1)
                : AppTheme.getWarningColor(true).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(2.w),
            border: Border.all(
              color: _isE2EEnabled
                  ? AppTheme.getSuccessColor(true).withValues(alpha: 0.3)
                  : AppTheme.getWarningColor(true).withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CustomIconWidget(
                iconName: _isE2EEnabled ? 'lock' : 'lock_open',
                color: _isE2EEnabled
                    ? AppTheme.getSuccessColor(true)
                    : AppTheme.getWarningColor(true),
                size: 4.w,
              ),
              SizedBox(width: 1.w),
              Text(
                'E2E',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: _isE2EEnabled
                          ? AppTheme.getSuccessColor(true)
                          : AppTheme.getWarningColor(true),
                      fontWeight: FontWeight.w600,
                    ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMessagesList() {
    return ListView.builder(
      controller: _scrollController,
      reverse: true,
      padding: EdgeInsets.only(top: 2.h, bottom: 1.h),
      itemCount: _messages.length,
      itemBuilder: (context, index) {
        final reversedIndex = _messages.length - 1 - index;
        final message = _messages[reversedIndex];

        return MessageBubbleWidget(
          message: message['message'],
          isSent: message['isSent'],
          timestamp: message['timestamp'],
          messageType: message['type'],
          isDelivered: message['isDelivered'],
          isRead: message['isRead'],
          senderName: message['senderName'],
          onCopy: () => _copyMessage(message['message']),
          onForward: () => _forwardMessage(message['message']),
          onReport: () => _reportMessage(message['id']),
          onDelete: () => _deleteMessage(message['id']),
        );
      },
    );
  }

  Widget _buildTypingIndicator() {
    return TypingIndicatorWidget(
      userName: _counterpartyName,
      isVisible: _counterpartyTyping,
    );
  }

  Widget _buildChatInput() {
    return ChatInputWidget(
      onSendMessage: _sendMessage,
      onSendOtp: _sendOtpMessage,
      onAttachment: _handleAttachment,
      onEmoji: _handleEmojiPicker,
      isTyping: _isTyping,
      isEnabled: _isOnline && !_isCallActive,
    );
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;

    final message = {
      'id': 'msg_${DateTime.now().millisecondsSinceEpoch}',
      'message': text,
      'type': MessageType.text,
      'timestamp': DateTime.now(),
      'isSent': true,
      'isDelivered': false,
      'isRead': false,
    };

    setState(() {
      _messages.add(message);
      _isTyping = false;
    });

    _scrollToBottom();
    _simulateTypingIndicator();
    _simulateMessageDelivery(message['id'] as String);

    // Simulate auto-response
    Future.delayed(const Duration(seconds: 2), () {
      _simulateCounterpartyMessage();
    });
  }

  void _sendOtpMessage(String otp) {
    final message = {
      'id': 'msg_${DateTime.now().millisecondsSinceEpoch}',
      'message': otp,
      'type': MessageType.otp,
      'timestamp': DateTime.now(),
      'isSent': true,
      'isDelivered': false,
      'isRead': false,
    };

    setState(() {
      _messages.add(message);
    });

    _scrollToBottom();
    _simulateMessageDelivery(message['id'] as String);

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('OTP shared securely'),
        backgroundColor: AppTheme.getSuccessColor(true),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _simulateCounterpartyMessage() {
    if (!mounted) return;

    final responses = [
      'Thanks for the update!',
      'Received and confirmed.',
      'Perfect, everything looks good.',
      'Proceeding with the next step.',
      'OTP verified successfully.',
    ];

    final message = {
      'id': 'msg_${DateTime.now().millisecondsSinceEpoch}',
      'message': responses[DateTime.now().millisecond % responses.length],
      'type': MessageType.text,
      'timestamp': DateTime.now(),
      'isSent': false,
      'isDelivered': true,
      'isRead': false,
      'senderName': _counterpartyName,
    };

    setState(() {
      _messages.add(message);
      _counterpartyTyping = false;
      _unreadCount++;
    });

    _scrollToBottom();
  }

  void _simulateTypingIndicator() {
    setState(() {
      _counterpartyTyping = true;
    });

    Timer(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _counterpartyTyping = false;
        });
      }
    });
  }

  void _simulateMessageDelivery(String messageId) {
    Timer(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          final messageIndex =
              _messages.indexWhere((msg) => msg['id'] == messageId);
          if (messageIndex != -1) {
            _messages[messageIndex]['isDelivered'] = true;
          }
        });
      }
    });

    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          final messageIndex =
              _messages.indexWhere((msg) => msg['id'] == messageId);
          if (messageIndex != -1) {
            _messages[messageIndex]['isRead'] = true;
          }
        });
      }
    });
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _startCall() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isCallActive = true;
      _callState = CallState.ringing;
      _callDuration = Duration.zero;
    });

    // Simulate call connection
    Timer(const Duration(seconds: 3), () {
      if (mounted && _isCallActive) {
        setState(() {
          _callState = CallState.connected;
        });
        _startCallTimer();
      }
    });
  }

  void _endCall() {
    setState(() {
      _isCallActive = false;
      _callState = CallState.ended;
    });
    _callTimer?.cancel();

    // Add system message about call
    final callMessage = {
      'id': 'msg_${DateTime.now().millisecondsSinceEpoch}',
      'message': 'Voice call ended. Duration: ${_formatCallDuration()}',
      'type': MessageType.system,
      'timestamp': DateTime.now(),
      'isSent': false,
      'isDelivered': true,
      'isRead': true,
    };

    setState(() {
      _messages.add(callMessage);
      _callDuration = Duration.zero;
      _callState = CallState.idle;
    });

    _scrollToBottom();
  }

  void _startCallTimer() {
    _callTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted && _isCallActive) {
        setState(() {
          _callDuration = Duration(seconds: _callDuration.inSeconds + 1);
        });
      }
    });
  }

  void _toggleMute() {
    setState(() {
      _isMuted = !_isMuted;
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isMuted ? 'Microphone muted' : 'Microphone unmuted'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _toggleSpeaker() {
    setState(() {
      _isSpeakerOn = !_isSpeakerOn;
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isSpeakerOn ? 'Speaker on' : 'Speaker off'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  String _formatCallDuration() {
    final minutes = _callDuration.inMinutes;
    final seconds = _callDuration.inSeconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  void _copyMessage(String message) {
    Clipboard.setData(ClipboardData(text: message));
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Message copied to clipboard'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _forwardMessage(String message) {
    // Implementation for forwarding message
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Forward feature coming soon'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _reportMessage(String messageId) {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Report Message'),
        content: Text('Report this message for inappropriate content?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Message reported successfully'),
                  backgroundColor: AppTheme.getWarningColor(true),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.getWarningColor(true)),
            child: Text('Report', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _deleteMessage(String messageId) {
    setState(() {
      _messages.removeWhere((msg) => msg['id'] == messageId);
    });

    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Message deleted'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleAttachment() {
    // Implementation for document attachment
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Document attachment feature coming soon'),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _handleEmojiPicker() {
    // Implementation for emoji picker (iOS specific)
    if (!kIsWeb && Platform.isIOS) {
      HapticFeedback.lightImpact();
      // Would integrate with emoji picker package
    }
  }

  void _handleEmergencyReport() {
    // Emergency report handled by EmergencyReportWidget
  }

  void _handleEscalateDispute() {
    // Dispute escalation handled by EmergencyReportWidget
  }
}