import 'package:flutter/foundation.dart'; // Add this import for kDebugMode
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../core/services/web3_wallet_service.dart';
import './widgets/activity_timeline_widget.dart';
import './widgets/auth_status_widget.dart';
import './widgets/balance_card_widget.dart';
import './widgets/city_selection_widget.dart';
import './widgets/empty_trades_widget.dart';
import './widgets/nearby_traders_widget.dart';
import './widgets/network_status_widget.dart';
import './widgets/realtime_status_widget.dart';
import './widgets/stats_cards_widget.dart';
import './widgets/trade_card_widget.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardState();
}

class _DashboardState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  int _currentTabIndex = 0;
  String _selectedActivityFilter = 'All';
  bool _isRefreshing = false;
  bool _isNetworkConnected = true;
  String? _selectedCity;

  // Mock data for dashboard - Updated with platform fees considerations
  final Map<String, dynamic> _walletData = {
    "balance": "2,450.00",
    "fiatEquivalent": "2,450.00",
  };

  final List<Map<String, dynamic>> _activeTrades = [
    {
      "id": "TXN001",
      "counterparty": "Alex Thompson",
      "amount": "500.00",
      "status": "Paid",
      "role": "Buyer",
      "agent": "CryptoAgent_01",
      "createdAt": "2025-08-18T05:30:00Z",
      "platformFee": "5.00",
      "totalAmount": "505.00",
    },
    {
      "id": "TXN002",
      "counterparty": "Sarah Chen",
      "amount": "1,200.00",
      "status": "Created",
      "role": "Seller",
      "agent": "TrustAgent_05",
      "createdAt": "2025-08-18T04:15:00Z",
      "platformFee": "12.00",
      "totalAmount": "1,188.00",
    },
    {
      "id": "TXN003",
      "counterparty": "Michael Rodriguez",
      "amount": "750.00",
      "status": "Released",
      "role": "Buyer",
      "agent": "SecureAgent_03",
      "createdAt": "2025-08-18T02:45:00Z",
      "platformFee": "7.50",
      "totalAmount": "757.50",
    },
  ];

  final List<Map<String, dynamic>> _recentActivities = [
    {
      "id": "ACT001",
      "type": "completed",
      "title": "Trade Completed",
      "description":
          "Successfully completed trade with Emma Wilson (incl. 1% fee)",
      "amount": "300.00",
      "platformFee": "3.00",
      "effectiveAmount": "303.00",
      "time": "2 hours ago",
    },
    {
      "id": "ACT002",
      "type": "created",
      "title": "New Trade Created",
      "description":
          "Trade created with David Kim for \$850 (1% platform fee applies)",
      "amount": "850.00",
      "platformFee": "8.50",
      "time": "4 hours ago",
    },
    {
      "id": "ACT003",
      "type": "cancelled",
      "title": "Trade Cancelled",
      "description": "Trade with Lisa Park was cancelled (no fees charged)",
      "amount": null,
      "time": "6 hours ago",
    },
    {
      "id": "ACT004",
      "type": "completed",
      "title": "Trade Completed",
      "description":
          "Successfully completed trade with James Brown (incl. 1% fee)",
      "amount": "1,100.00",
      "platformFee": "11.00",
      "effectiveAmount": "1,089.00",
      "time": "1 day ago",
    },
  ];

  final Map<String, dynamic> _statsData = {
    "totalTrades": 47,
    "successRate": 96,
    "avgTime": 12,
    "volume": "15.2K",
    "totalFeesCollected": "152.00", // Platform fees collected
  };

  @override
  void initState() {
    super.initState();
    _initializeDashboardServices();
  }

  Future<void> _initializeDashboardServices() async {
    try {
      // Initialize Web3 Wallet Service if not already initialized
      if (!Web3WalletService.instance.isConnected) {
        await Web3WalletService.instance.initialize();
      }

      if (kDebugMode) {
        print('✅ Dashboard services initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Dashboard service initialization warning: $e');
        print('🚀 Continuing with mock data in bypass mode');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'ZedTrust P2P',
          style: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: AppTheme.primaryLight,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/trade-history'),
            icon: CustomIconWidget(
              iconName: 'notifications',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
          IconButton(
            onPressed: () => _showProfileMenu(),
            icon: Container(
              width: 8.w,
              height: 8.w,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: 'person',
                color: AppTheme.lightTheme.primaryColor,
                size: 20,
              ),
            ),
          ),
          SizedBox(width: 2.w),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refreshData,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Padding(
              padding: EdgeInsets.all(4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Authentication Status Widget
                  const AuthStatusWidget(),

                  // Real-time Status Widget
                  const RealtimeStatusWidget(),

                  // Network Status
                  NetworkStatusWidget(
                    isConnected: _isNetworkConnected,
                    networkName: 'Polygon',
                    blockNumber: 58742391,
                  ),

                  // Balance Card
                  BalanceCardWidget(
                    usdcBalance: _walletData['balance'],
                    fiatEquivalent: _walletData['fiatEquivalent'],
                    onRefresh: _handleBalanceRefresh,
                  ),

                  // City Selection Widget - Now more prominent as main feature
                  CitySelectionWidget(
                    selectedCity: _selectedCity,
                    onCitySelected: (city) {
                      setState(() {
                        _selectedCity = city;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('City updated to $city'),
                          backgroundColor: AppTheme.getSuccessColor(true),
                          duration: const Duration(seconds: 2),
                        ),
                      );
                    },
                  ),

                  // Show content based on city selection
                  if (_selectedCity != null) ...[
                    // Nearby Traders Widget
                    SizedBox(height: 2.h),
                    NearbyTradersWidget(
                      selectedCity: _selectedCity!,
                      onTraderTap:
                          (traderId) => _navigateToTraderProfile(traderId),
                      onMessageTrader: (traderId) => _messageTrader(traderId),
                    ),

                    // Quick Stats
                    SizedBox(height: 3.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Text(
                        'Quick Stats',
                        style: AppTheme.lightTheme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                    SizedBox(height: 1.h),
                    StatsCardsWidget(stats: _statsData),

                    // Active Trades Section
                    SizedBox(height: 3.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Active Trades',
                            style: AppTheme.lightTheme.textTheme.titleLarge
                                ?.copyWith(fontWeight: FontWeight.w600),
                          ),
                          if (_activeTrades.isNotEmpty)
                            GestureDetector(
                              onTap:
                                  () => Navigator.pushNamed(
                                    context,
                                    '/trade-history',
                                  ),
                              child: Text(
                                'View All',
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                      color: AppTheme.lightTheme.primaryColor,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ),
                        ],
                      ),
                    ),
                    SizedBox(height: 2.h),

                    // Active Trades List or Empty State
                    _activeTrades.isEmpty
                        ? EmptyTradesWidget(
                          onCreateTrade:
                              () =>
                                  Navigator.pushNamed(context, '/create-trade'),
                        )
                        : ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _activeTrades.length,
                          itemBuilder: (context, index) {
                            return TradeCardWidget(
                              trade: _activeTrades[index],
                              onTap:
                                  () => _navigateToTradeDetails(
                                    _activeTrades[index]['id'],
                                  ),
                              onViewDetails:
                                  () => _navigateToTradeDetails(
                                    _activeTrades[index]['id'],
                                  ),
                              onContactAgent:
                                  () => _contactAgent(
                                    _activeTrades[index]['agent'],
                                  ),
                              onCancelTrade:
                                  () =>
                                      _cancelTrade(_activeTrades[index]['id']),
                            );
                          },
                        ),

                    // Recent Activity Timeline
                    if (_activeTrades.isNotEmpty) ...[
                      SizedBox(height: 3.h),
                      ActivityTimelineWidget(
                        activities: _getFilteredActivities(),
                        selectedFilter: _selectedActivityFilter,
                        onFilterChanged: (filter) {
                          setState(() {
                            _selectedActivityFilter = filter;
                          });
                        },
                      ),
                    ],
                  ] else ...[
                    // Show default content when no city is selected
                    SizedBox(height: 3.h),

                    // Welcome Section - Enhanced to encourage city selection
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      padding: EdgeInsets.all(6.w),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            AppTheme.lightTheme.primaryColor.withValues(
                              alpha: 0.1,
                            ),
                            AppTheme.lightTheme.primaryColor.withValues(
                              alpha: 0.05,
                            ),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome to ZoTrust',
                            style: AppTheme.lightTheme.textTheme.headlineSmall
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: AppTheme.lightTheme.primaryColor,
                                ),
                          ),
                          SizedBox(height: 1.h),
                          Text(
                            'Your secure P2P trading platform with escrow protection. Get started by selecting your city above to find nearby traders and begin trading.',
                            style: AppTheme.lightTheme.textTheme.bodyLarge
                                ?.copyWith(
                                  color:
                                      AppTheme
                                          .lightTheme
                                          .colorScheme
                                          .onSurfaceVariant,
                                ),
                          ),
                          SizedBox(height: 2.h),
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(2.w),
                                decoration: BoxDecoration(
                                  color: AppTheme.lightTheme.primaryColor
                                      .withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: CustomIconWidget(
                                  iconName: 'place',
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                              SizedBox(width: 3.w),
                              Text(
                                'Select your city to get started',
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.lightTheme.primaryColor,
                                    ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Quick Actions
                    SizedBox(height: 3.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Text(
                        'Quick Actions',
                        style: AppTheme.lightTheme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                    SizedBox(height: 2.h),

                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Row(
                        children: [
                          Expanded(
                            child: _buildQuickActionCard(
                              'Create Trade',
                              'Start your first trade',
                              'add_circle',
                              () =>
                                  Navigator.pushNamed(context, '/create-trade'),
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: _buildQuickActionCard(
                              'Find Agents',
                              'Browse trusted agents',
                              'people',
                              () => Navigator.pushNamed(
                                context,
                                '/agent-selection',
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Platform Features
                    SizedBox(height: 3.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Text(
                        'Why Choose ZoTrust?',
                        style: AppTheme.lightTheme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                    SizedBox(height: 2.h),

                    _buildFeaturesList(),

                    // Global Stats
                    SizedBox(height: 3.h),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4.w),
                      child: Text(
                        'Platform Statistics',
                        style: AppTheme.lightTheme.textTheme.titleLarge
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    ),
                    SizedBox(height: 1.h),
                    _buildGlobalStats(),
                  ],

                  SizedBox(height: 10.h), // Space for FAB
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
      floatingActionButton: _buildFloatingActionButton(),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }

  Widget _buildQuickActionCard(
    String title,
    String subtitle,
    String iconName,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: AppTheme.lightTheme.colorScheme.outline.withValues(
              alpha: 0.2,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: CustomIconWidget(
                iconName: iconName,
                color: AppTheme.lightTheme.primaryColor,
                size: 24,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 0.5.h),
            Text(
              subtitle,
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturesList() {
    final features = [
      {
        'icon': 'security',
        'title': 'Escrow Protection',
        'description': 'Your funds are secured until trade completion',
      },
      {
        'icon': 'verified',
        'title': 'Trusted Agents',
        'description': 'Pre-verified agents ensure safe transactions',
      },
      {
        'icon': 'speed',
        'title': 'Fast Settlements',
        'description': 'Complete trades in minutes, not hours',
      },
      {
        'icon': 'account_balance', // New feature
        'title': 'Transparent Fees',
        'description': '1% platform fee - clearly displayed before trading',
      },
    ];

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 4.w),
      child: Column(
        children:
            features
                .map(
                  (feature) => Container(
                    margin: EdgeInsets.only(bottom: 2.h),
                    padding: EdgeInsets.all(4.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.cardColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.1),
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: EdgeInsets.all(2.w),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.primaryColor.withValues(
                              alpha: 0.1,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: CustomIconWidget(
                            iconName: feature['icon'] as String,
                            color: AppTheme.lightTheme.primaryColor,
                            size: 24,
                          ),
                        ),
                        SizedBox(width: 3.w),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                feature['title'] as String,
                                style: AppTheme.lightTheme.textTheme.titleMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                              ),
                              SizedBox(height: 0.5.h),
                              Text(
                                feature['description'] as String,
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                      color:
                                          AppTheme
                                              .lightTheme
                                              .colorScheme
                                              .onSurfaceVariant,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                )
                .toList(),
      ),
    );
  }

  Widget _buildGlobalStats() {
    return StatsCardsWidget(
      stats: {
        "totalTrades": 12547,
        "successRate": 98,
        "avgTime": 15,
        "volume": "2.1M",
        "platformFees": "21K", // Total platform fees collected
      },
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentTabIndex,
      onTap: _onTabTapped,
      type: BottomNavigationBarType.fixed,
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      selectedItemColor: AppTheme.lightTheme.primaryColor,
      unselectedItemColor: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
      elevation: 8,
      items: [
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'dashboard',
            color:
                _currentTabIndex == 0
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          label: 'Dashboard',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'swap_horiz',
            color:
                _currentTabIndex == 1
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          label: 'Trades',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'currency_exchange',
            color:
                _currentTabIndex == 2
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          label: 'P2P',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'account_balance_wallet',
            color:
                _currentTabIndex == 3
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          label: 'Wallet',
        ),
        BottomNavigationBarItem(
          icon: CustomIconWidget(
            iconName: 'person',
            color:
                _currentTabIndex == 4
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 24,
          ),
          label: 'Profile',
        ),
      ],
    );
  }

  Widget _buildFloatingActionButton() {
    return FloatingActionButton.extended(
      onPressed: () => _navigateToWalletConnection(),
      backgroundColor: AppTheme.lightTheme.primaryColor,
      foregroundColor: Colors.white,
      elevation: 4,
      icon: CustomIconWidget(
        iconName: 'account_balance_wallet',
        color: Colors.white,
        size: 24,
      ),
      label: Text(
        'Connect Wallet',
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  void _navigateToWalletConnection() {
    Navigator.pushNamed(context, '/wallet-connection');
  }

  Future<void> _refreshData() async {
    setState(() {
      _isRefreshing = true;
    });

    // Simulate network refresh
    await Future.delayed(const Duration(seconds: 2));

    setState(() {
      _isRefreshing = false;
      // Update network status randomly for demo
      _isNetworkConnected = DateTime.now().millisecond % 2 == 0;
    });
  }

  Future<void> _handleBalanceRefresh() async {
    // Simulate balance refresh with haptic feedback
    await Future.delayed(const Duration(milliseconds: 500));

    // Show success feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Balance updated'),
        backgroundColor: AppTheme.getSuccessColor(true),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _onTabTapped(int index) {
    setState(() {
      _currentTabIndex = index;
    });

    // Navigate to different screens based on tab
    switch (index) {
      case 0:
        // Already on dashboard
        break;
      case 1:
        Navigator.pushNamed(context, '/trade-history');
        break;
      case 2:
        Navigator.pushNamed(context, '/p2p-trading');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet-connection');
        break;
      case 4:
        _showProfileMenu();
        break;
    }
  }

  void _navigateToTradeDetails(String tradeId) {
    Navigator.pushNamed(
      context,
      '/trade-details',
      arguments: {'tradeId': tradeId},
    );
  }

  void _navigateToTraderProfile(String traderId) {
    // Navigate to trader profile or show trader details
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Viewing trader profile: $traderId'),
        backgroundColor: AppTheme.lightTheme.primaryColor,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _messageTrader(String traderId) {
    Navigator.pushNamed(
      context,
      '/in-app-chat',
      arguments: {'traderId': traderId, 'type': 'trader'},
    );
  }

  void _contactAgent(String agentId) {
    Navigator.pushNamed(
      context,
      '/in-app-chat',
      arguments: {'agentId': agentId},
    );
  }

  void _cancelTrade(String tradeId) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text(
              'Cancel Trade',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            content: Text(
              'Are you sure you want to cancel this trade? This action cannot be undone.',
              style: AppTheme.lightTheme.textTheme.bodyMedium,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Keep Trade',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  _performCancelTrade(tradeId);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.lightTheme.colorScheme.error,
                ),
                child: Text(
                  'Cancel Trade',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
    );
  }

  void _performCancelTrade(String tradeId) {
    setState(() {
      _activeTrades.removeWhere((trade) => trade['id'] == tradeId);
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Trade cancelled successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showProfileMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder:
          (context) => Container(
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.cardColor,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(20),
              ),
            ),
            padding: EdgeInsets.all(6.w),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 12.w,
                  height: 0.5.h,
                  decoration: BoxDecoration(
                    color: AppTheme.getNeutralColor(true),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                SizedBox(height: 3.h),
                Text(
                  'Profile Menu',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 3.h),

                // Create Profile - Featured option
                _buildProfileMenuItem('Create Profile', 'person_add', () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, AppRoutes.createProfile);
                }, isFeature: true),

                _buildProfileMenuItem(
                  'Settings',
                  'settings',
                  () => Navigator.pop(context),
                ),
                _buildProfileMenuItem(
                  'Security',
                  'security',
                  () => Navigator.pop(context),
                ),
                _buildProfileMenuItem(
                  'Help & Support',
                  'help',
                  () => Navigator.pop(context),
                ),

                // Admin Section - Direct Access
                Container(
                  margin: EdgeInsets.symmetric(vertical: 2.h),
                  padding: EdgeInsets.all(4.w),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                        AppTheme.lightTheme.primaryColor.withValues(
                          alpha: 0.05,
                        ),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.lightTheme.primaryColor.withValues(
                        alpha: 0.3,
                      ),
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.primaryColor,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName: 'admin_panel_settings',
                              color: Colors.white,
                              size: 5.w,
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Admin Panel',
                                  style: AppTheme
                                      .lightTheme
                                      .textTheme
                                      .titleMedium
                                      ?.copyWith(
                                        fontWeight: FontWeight.w600,
                                        color: AppTheme.lightTheme.primaryColor,
                                      ),
                                ),
                                Text(
                                  'Direct access to admin features',
                                  style: AppTheme.lightTheme.textTheme.bodySmall
                                      ?.copyWith(
                                        color:
                                            AppTheme
                                                .lightTheme
                                                .colorScheme
                                                .onSurfaceVariant,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                              horizontal: 2.w,
                              vertical: 1.h,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.green.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Colors.green.withValues(alpha: 0.3),
                              ),
                            ),
                            child: Text(
                              'ACTIVE',
                              style: AppTheme.lightTheme.textTheme.labelSmall
                                  ?.copyWith(
                                    color: Colors.green[700],
                                    fontWeight: FontWeight.w700,
                                    fontSize: 8,
                                  ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 2.h),
                      Row(
                        children: [
                          Expanded(
                            child: _buildAdminQuickAction(
                              'Dashboard',
                              'dashboard',
                              () => _navigateToAdminFeature(
                                AppRoutes.adminDashboard,
                              ),
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Expanded(
                            child: _buildAdminQuickAction(
                              'Agent Mgmt',
                              'people',
                              () => _navigateToAdminFeature(
                                AppRoutes.adminAgentManagement,
                              ),
                            ),
                          ),
                          SizedBox(width: 2.w),
                          Expanded(
                            child: _buildAdminQuickAction(
                              'Control Center',
                              'settings',
                              () => _navigateToAdminFeature(
                                AppRoutes.adminControlCenter,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                _buildProfileMenuItem(
                  'About',
                  'info',
                  () => Navigator.pop(context),
                ),
                SizedBox(height: 2.h),
              ],
            ),
          ),
    );
  }

  Widget _buildAdminQuickAction(
    String title,
    String iconName,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 2.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.cardColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: AppTheme.lightTheme.colorScheme.outline.withValues(
              alpha: 0.2,
            ),
          ),
        ),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: iconName,
              color: AppTheme.lightTheme.primaryColor,
              size: 5.w,
            ),
            SizedBox(height: 1.h),
            Text(
              title,
              style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileMenuItem(
    String title,
    String iconName,
    VoidCallback onTap, {
    bool isFeature = false,
  }) {
    return ListTile(
      leading: Container(
        padding: EdgeInsets.all(2.w),
        decoration: BoxDecoration(
          color:
              isFeature
                  ? AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1)
                  : AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(8),
        ),
        child: CustomIconWidget(
          iconName: iconName,
          color:
              isFeature
                  ? AppTheme.lightTheme.primaryColor
                  : AppTheme.lightTheme.colorScheme.onSurface,
          size: 24,
        ),
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
          fontWeight: isFeature ? FontWeight.w600 : FontWeight.w500,
          color: isFeature ? AppTheme.lightTheme.primaryColor : null,
        ),
      ),
      onTap: onTap,
    );
  }

  void _navigateToAdminFeature(String route) {
    Navigator.pop(context); // Close profile menu first

    // Direct navigation without authentication requirement
    Navigator.pushNamed(context, route);
  }

  void _showAdminLogin() {
    // This method is no longer used but kept for compatibility
  }

  List<Map<String, dynamic>> _getFilteredActivities() {
    switch (_selectedActivityFilter) {
      case 'Today':
        return _recentActivities.where((activity) {
          return (activity['time'] as String).contains('hours ago');
        }).toList();
      case 'This Week':
        return _recentActivities.where((activity) {
          final time = activity['time'] as String;
          return time.contains('hours ago') || time.contains('day ago');
        }).toList();
      case 'This Month':
        return _recentActivities;
      default:
        return _recentActivities;
    }
  }
}