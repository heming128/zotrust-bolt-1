import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class BuyModalWidget extends StatefulWidget {
  final Map<String, dynamic> trader;
  final VoidCallback? onTradeCreated;

  const BuyModalWidget({
    Key? key,
    required this.trader,
    this.onTradeCreated,
  }) : super(key: key);

  @override
  State<BuyModalWidget> createState() => _BuyModalWidgetState();
}

class _BuyModalWidgetState extends State<BuyModalWidget>
    with TickerProviderStateMixin {
  final TextEditingController _amountController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _isProcessing = false;
  bool _showContractLocking = false;
  int _lockingProgress = 0;
  Timer? _lockingTimer;

  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  // Trade data
  String _tradeId = '';
  String _otp = '';
  Color _verificationColor = Colors.blue;
  String _hexValue = '';
  DateTime? _tradeStartTime;
  DateTime? _tradeExpiry;

  // INR limits from trader data
  int get _minLimit {
    final availableAmount = widget.trader['availableAmount'] as String;
    // Extract min from "₹25,000 - ₹2,50,000"
    final match = RegExp(r'₹([\d,]+)').firstMatch(availableAmount);
    if (match != null) {
      return int.parse(match.group(1)!.replaceAll(',', ''));
    }
    return 25000;
  }

  int get _maxLimit {
    final availableAmount = widget.trader['availableAmount'] as String;
    // Extract max from "₹25,000 - ₹2,50,000"
    final matches = RegExp(r'₹([\d,]+)').allMatches(availableAmount);
    if (matches.length >= 2) {
      return int.parse(matches.last.group(1)!.replaceAll(',', ''));
    }
    return 250000;
  }

  double get _usdcRate => 84.5; // INR to USDC conversion rate

  double get _usdcAmount {
    final inrAmount =
        double.tryParse(_amountController.text.replaceAll(',', '')) ?? 0;
    return inrAmount / _usdcRate;
  }

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _generateTradeData();
  }

  void _initializeAnimations() {
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeIn,
    ));

    _slideController.forward();
    _fadeController.forward();
  }

  void _generateTradeData() {
    final random = Random();
    _tradeId =
        'TRD-${DateTime.now().year}-${random.nextInt(999999).toString().padLeft(6, '0')}';
    _otp = (100000 + random.nextInt(900000)).toString();

    _verificationColor = Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );

    _hexValue =
        '#${_verificationColor.value.toRadixString(16).substring(2).toUpperCase()}';

    _tradeStartTime = DateTime.now();
    _tradeExpiry = _tradeStartTime!.add(const Duration(hours: 2));
  }

  String? _validateAmount(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter an amount';
    }

    final amount = double.tryParse(value.replaceAll(',', ''));
    if (amount == null) {
      return 'Please enter a valid amount';
    }

    if (amount < _minLimit) {
      return 'Minimum amount is ₹${_formatCurrency(_minLimit.toDouble())}';
    }

    if (amount > _maxLimit) {
      return 'Maximum amount is ₹${_formatCurrency(_maxLimit.toDouble())}';
    }

    final availableUsdc = widget.trader['availableUSDC'] as int;
    if (_usdcAmount > availableUsdc) {
      return 'Insufficient USDC. Available: ${availableUsdc.toStringAsFixed(2)} USDC';
    }

    return null;
  }

  String _formatCurrency(double amount) {
    return amount.toStringAsFixed(0).replaceAllMapped(
        RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]},');
  }

  void _handleAmountChanged(String value) {
    // Format as currency while typing
    if (value.isNotEmpty) {
      final numericValue = value.replaceAll(',', '');
      if (double.tryParse(numericValue) != null) {
        final formatted = _formatCurrency(double.parse(numericValue));
        if (formatted != value) {
          _amountController.value = TextEditingValue(
            text: formatted,
            selection: TextSelection.collapsed(offset: formatted.length),
          );
        }
      }
    }
    setState(() {});
  }

  Future<void> _handleConfirmBuy() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isProcessing = true;
      _showContractLocking = true;
      _lockingProgress = 0;
    });

    // Show contract locking animation
    _lockingTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      setState(() {
        _lockingProgress += 2;
      });

      if (_lockingProgress >= 100) {
        timer.cancel();
        _completeTradeCreation();
      }
    });
  }

  void _completeTradeCreation() {
    // Show success and navigate to OTP verification
    setState(() {
      _isProcessing = false;
      _showContractLocking = false;
    });

    // Show success message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 2.w),
            Expanded(
              child: Text(
                  'Trade created! ${_usdcAmount.toStringAsFixed(2)} USDC locked in smart contract'),
            ),
          ],
        ),
        backgroundColor: AppTheme.getSuccessColor(true),
        duration: const Duration(seconds: 3),
      ),
    );

    // Close modal and navigate to OTP verification with trade data
    Navigator.of(context).pop();

    Future.delayed(const Duration(milliseconds: 300), () {
      Navigator.pushNamed(
        context,
        '/otp-verification',
        arguments: {
          'tradeId': _tradeId,
          'otp': _otp,
          'color': _verificationColor,
          'hexValue': _hexValue,
          'traderName': widget.trader['name'],
          'amount': _amountController.text,
          'usdcAmount': _usdcAmount.toStringAsFixed(2),
          'startTime': _tradeStartTime,
          'expiryTime': _tradeExpiry,
        },
      );
    });

    widget.onTradeCreated?.call();
  }

  @override
  void dispose() {
    _lockingTimer?.cancel();
    _slideController.dispose();
    _fadeController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        onTap: () => Navigator.of(context).pop(),
        child: Container(
          width: double.infinity,
          height: double.infinity,
          color: Colors.black.withValues(alpha: 0.5),
          child: Center(
            child: GestureDetector(
              onTap: () {}, // Prevent dismissal when tapping modal content
              child: SlideTransition(
                position: _slideAnimation,
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: Container(
                    width: 95.w,
                    constraints: BoxConstraints(maxHeight: 85.h),
                    margin: EdgeInsets.symmetric(horizontal: 2.5.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.cardColor,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.2),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildHeader(),
                        if (_showContractLocking)
                          _buildContractLockingView()
                        else
                          _buildBuyForm(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'shopping_cart',
            color: AppTheme.lightTheme.primaryColor,
            size: 24,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Buy from ${widget.trader['name']}',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    color: AppTheme.lightTheme.primaryColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  'Available: ${widget.trader['availableUSDC']} USDC',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: CustomIconWidget(
              iconName: 'close',
              color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBuyForm() {
    return Flexible(
      child: SingleChildScrollView(
        padding: EdgeInsets.all(4.w),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Trader info card
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surfaceContainerHighest
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    CustomImageWidget(
                      imageUrl: widget.trader['avatar'] as String,
                      width: 12.w,
                      height: 12.w,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(width: 3.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.trader['name'] as String,
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            'INR Limit: ${widget.trader['availableAmount']}',
                            style: AppTheme.lightTheme.textTheme.bodySmall,
                          ),
                          Row(
                            children: List.generate(5, (index) {
                              final rating =
                                  (widget.trader['rating'] as num).toDouble();
                              return CustomIconWidget(
                                iconName: index < rating.floor()
                                    ? 'star'
                                    : 'star_border',
                                color: index < rating.floor()
                                    ? AppTheme.getWarningColor(true)
                                    : AppTheme.getNeutralColor(true),
                                size: 14,
                              );
                            }),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 3.h),

              // Amount input section
              Text(
                'Enter Amount (INR)',
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 1.h),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.allow(RegExp(r'[0-9,]'))
                ],
                validator: _validateAmount,
                onChanged: _handleAmountChanged,
                decoration: InputDecoration(
                  hintText: 'e.g., 30,000',
                  prefixText: '₹ ',
                  suffixIcon: _amountController.text.isNotEmpty
                      ? IconButton(
                          onPressed: () {
                            _amountController.clear();
                            setState(() {});
                          },
                          icon: CustomIconWidget(
                            iconName: 'clear',
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                            size: 20,
                          ),
                        )
                      : null,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: AppTheme.lightTheme.primaryColor,
                      width: 2,
                    ),
                  ),
                  filled: true,
                  fillColor: AppTheme.lightTheme.colorScheme.surface,
                ),
              ),

              SizedBox(height: 2.h),

              // Conversion display
              if (_amountController.text.isNotEmpty &&
                  _validateAmount(_amountController.text) == null) ...[
                Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color:
                        AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.lightTheme.primaryColor
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'You will receive:',
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          Text(
                            '${_usdcAmount.toStringAsFixed(2)} USDC',
                            style: AppTheme.lightTheme.textTheme.titleMedium
                                ?.copyWith(
                              color: AppTheme.lightTheme.primaryColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 1.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Exchange Rate:',
                            style: AppTheme.lightTheme.textTheme.bodySmall,
                          ),
                          Text(
                            '1 USDC = ₹${_usdcRate.toStringAsFixed(2)}',
                            style: AppTheme.lightTheme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 3.h),
              ],

              // Limits info
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.surfaceContainerHighest
                      .withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Trading Limits',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Minimum:',
                          style: AppTheme.lightTheme.textTheme.bodySmall,
                        ),
                        Text(
                          '₹${_formatCurrency(_minLimit.toDouble())}',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 0.5.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Maximum:',
                          style: AppTheme.lightTheme.textTheme.bodySmall,
                        ),
                        Text(
                          '₹${_formatCurrency(_maxLimit.toDouble())}',
                          style:
                              AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              SizedBox(height: 3.h),

              // Action buttons
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _isProcessing
                          ? null
                          : () => Navigator.of(context).pop(),
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 1.8.h),
                        side: BorderSide(
                          color: AppTheme.lightTheme.colorScheme.outline,
                          width: 1.5,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'Cancel',
                        style:
                            AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isProcessing || _amountController.text.isEmpty
                          ? null
                          : _handleConfirmBuy,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.lightTheme.primaryColor,
                        padding: EdgeInsets.symmetric(vertical: 1.8.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isProcessing
                          ? SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            )
                          : Text(
                              'Confirm Buy',
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ),
                ],
              ),

              SizedBox(height: 2.h),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContractLockingView() {
    return Flexible(
      child: Padding(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'lock',
              color: AppTheme.lightTheme.primaryColor,
              size: 64,
            ),
            SizedBox(height: 3.h),
            Text(
              'Locking USDC in Smart Contract',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.primaryColor,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 1.h),
            Text(
              'Securing ${_usdcAmount.toStringAsFixed(2)} USDC for your trade...',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),

            // Progress bar
            Container(
              width: double.infinity,
              height: 8,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Row(
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 100),
                    width: (MediaQuery.of(context).size.width * 0.87) *
                        (_lockingProgress / 100),
                    height: 8,
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.primaryColor,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              '$_lockingProgress%',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: AppTheme.lightTheme.primaryColor,
              ),
            ),

            SizedBox(height: 4.h),

            // Steps
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildLockingStep(
                    'Validating transaction', _lockingProgress > 20),
                _buildLockingStep(
                    'Connecting to blockchain', _lockingProgress > 40),
                _buildLockingStep(
                    'Executing smart contract', _lockingProgress > 60),
                _buildLockingStep(
                    'Confirming USDC lock', _lockingProgress > 80),
                _buildLockingStep(
                    'Starting 2-hour timer', _lockingProgress > 95),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLockingStep(String title, bool completed) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.5.h),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: completed ? 'check_circle' : 'radio_button_unchecked',
            color: completed
                ? AppTheme.getSuccessColor(true)
                : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 20,
          ),
          SizedBox(width: 3.w),
          Text(
            title,
            style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
              color: completed
                  ? AppTheme.lightTheme.colorScheme.onSurface
                  : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
