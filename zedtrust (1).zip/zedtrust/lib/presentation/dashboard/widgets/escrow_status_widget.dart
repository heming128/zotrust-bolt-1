import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/escrow_payment_service.dart';

class EscrowStatusWidget extends StatefulWidget {
  final String? userId;

  const EscrowStatusWidget({
    Key? key,
    this.userId,
  }) : super(key: key);

  @override
  State<EscrowStatusWidget> createState() => _EscrowStatusWidgetState();
}

class _EscrowStatusWidgetState extends State<EscrowStatusWidget> {
  Map<String, dynamic>? _escrowStats;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadEscrowStatistics();
  }

  Future<void> _loadEscrowStatistics() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final stats = await EscrowPaymentService.instance.getEscrowStatistics();

      if (mounted) {
        setState(() {
          _escrowStats = stats;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Failed to load escrow statistics';
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
        child: Column(
          children: [
            CircularProgressIndicator(
              color: Theme.of(context).colorScheme.primary,
              strokeWidth: 2,
            ),
            SizedBox(height: 2.h),
            Text(
              'Loading escrow statistics...',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.error.withValues(alpha: 0.3),
          ),
        ),
        child: Column(
          children: [
            CustomIconWidget(
              iconName: 'error',
              color: Theme.of(context).colorScheme.error,
              size: 24,
            ),
            SizedBox(height: 2.h),
            Text(
              _errorMessage!,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.error,
                  ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),
            ElevatedButton(
              onPressed: _loadEscrowStatistics,
              child: Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_escrowStats == null || _escrowStats!.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'account_balance',
                color: Theme.of(context).colorScheme.primary,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'Escrow System Overview',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.primary,
                    ),
              ),
              Spacer(),
              IconButton(
                onPressed: _loadEscrowStatistics,
                icon: CustomIconWidget(
                  iconName: 'refresh',
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  size: 18,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Main statistics grid
          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Total Locked',
                  '${_escrowStats!['total_locked_usdc']?.toStringAsFixed(2) ?? '0.00'} USDC',
                  'account_balance_wallet',
                  AppTheme.getWarningColor(
                      Theme.of(context).brightness == Brightness.light),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatCard(
                  'Total Released',
                  '${_escrowStats!['total_released_usdc']?.toStringAsFixed(2) ?? '0.00'} USDC',
                  'check_circle',
                  AppTheme.getSuccessColor(
                      Theme.of(context).brightness == Brightness.light),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.w),

          Row(
            children: [
              Expanded(
                child: _buildStatCard(
                  'Platform Fees',
                  '${_escrowStats!['total_platform_fees']?.toStringAsFixed(2) ?? '0.00'} USDC',
                  'trending_up',
                  Theme.of(context).colorScheme.primary,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: _buildStatCard(
                  'Avg Trade Size',
                  '${_escrowStats!['average_trade_amount']?.toStringAsFixed(2) ?? '0.00'} USDC',
                  'analytics',
                  Theme.of(context).colorScheme.secondary,
                ),
              ),
            ],
          ),
          SizedBox(height: 4.h),

          // Trade counts section
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primaryContainer
                  .withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trade Activity',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                ),
                SizedBox(height: 2.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildTradeCountItem(
                      'Active',
                      _escrowStats!['active_trades']?.toString() ?? '0',
                      AppTheme.getWarningColor(
                          Theme.of(context).brightness == Brightness.light),
                    ),
                    _buildTradeCountItem(
                      'Completed',
                      _escrowStats!['completed_trades']?.toString() ?? '0',
                      AppTheme.getSuccessColor(
                          Theme.of(context).brightness == Brightness.light),
                    ),
                    _buildTradeCountItem(
                      'Cancelled',
                      _escrowStats!['cancelled_trades']?.toString() ?? '0',
                      Theme.of(context).colorScheme.error,
                    ),
                  ],
                ),
              ],
            ),
          ),

          SizedBox(height: 3.h),

          // Quick actions
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/create-trade'),
                  icon: CustomIconWidget(
                    iconName: 'add_circle',
                    color: Theme.of(context).colorScheme.primary,
                    size: 16,
                  ),
                  label: Text('New Trade'),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 1.h),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () =>
                      Navigator.pushNamed(context, '/trade-history'),
                  icon: CustomIconWidget(
                    iconName: 'history',
                    color: Theme.of(context).colorScheme.primary,
                    size: 16,
                  ),
                  label: Text('View History'),
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 1.h),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
      String label, String value, String iconName, Color color) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: color.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomIconWidget(
            iconName: iconName,
            color: color,
            size: 18,
          ),
          SizedBox(height: 1.h),
          Text(
            value,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: color,
                ),
          ),
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 10.sp,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradeCountItem(String label, String count, Color color) {
    return Column(
      children: [
        Text(
          count,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                color: color,
              ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
      ],
    );
  }
}
