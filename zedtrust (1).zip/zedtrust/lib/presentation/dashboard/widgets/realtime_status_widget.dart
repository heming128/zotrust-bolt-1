import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../../core/services/realtime_service.dart';
import '../../../core/services/auth_service.dart';

class RealtimeStatusWidget extends StatefulWidget {
  const RealtimeStatusWidget({super.key});

  @override
  State<RealtimeStatusWidget> createState() => _RealtimeStatusWidgetState();
}

class _RealtimeStatusWidgetState extends State<RealtimeStatusWidget>
    with TickerProviderStateMixin {
  final RealtimeService _realtimeService = RealtimeService.instance;
  final AuthService _authService = AuthService.instance;

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  List<Map<String, dynamic>> _onlineUsers = [];
  int _activeChannels = 0;
  List<String> _recentEvents = [];
  bool _isConnected = true;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeRealtimeMonitoring();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _pulseController.repeat(reverse: true);
  }

  void _initializeRealtimeMonitoring() {
    // Update UI periodically with real-time data
    _updateRealtimeStatus();

    // Set up periodic updates
    Stream.periodic(const Duration(seconds: 3)).listen((_) {
      if (mounted) {
        _updateRealtimeStatus();
      }
    });

    // Demo: Subscribe to trades for demonstration
    if (_authService.isAuthenticated) {
      _setupDemoSubscriptions();
    }
  }

  void _updateRealtimeStatus() {
    if (mounted) {
      setState(() {
        _onlineUsers = _realtimeService.getOnlineUsers();
        _activeChannels = _realtimeService.activeChannelsCount;
      });
    }
  }

  void _setupDemoSubscriptions() {
    // Subscribe to trades to demonstrate real-time functionality
    _realtimeService.subscribeToTrades(
      onTradeCreated: (trade) {
        _addRealtimeEvent('Trade Created', 'New trade: ${trade['id']}');
      },
      onTradeUpdated: (trade) {
        _addRealtimeEvent('Trade Updated', 'Status: ${trade['status']}');
      },
      onTradeCompleted: (trade) {
        _addRealtimeEvent('Trade Completed', 'Trade ${trade['id']} completed');
      },
    );

    // Subscribe to agents status
    _realtimeService.subscribeToAgents(
      onAgentOnline: (agent) {
        _addRealtimeEvent('Agent Online', '${agent['name']} is now online');
      },
      onAgentOffline: (agent) {
        _addRealtimeEvent('Agent Offline', '${agent['name']} went offline');
      },
    );
  }

  void _addRealtimeEvent(String type, String message) {
    if (mounted) {
      setState(() {
        _recentEvents.insert(0, '$type: $message');
        if (_recentEvents.length > 5) {
          _recentEvents = _recentEvents.take(5).toList();
        }
      });
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withAlpha(26),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedBuilder(
                animation: _pulseAnimation,
                builder: (context, child) {
                  return Transform.scale(
                    scale: _isConnected ? _pulseAnimation.value : 1.0,
                    child: Icon(
                      Icons.wifi,
                      color: _isConnected ? Colors.green : Colors.red,
                      size: 24,
                    ),
                  );
                },
              ),
              const SizedBox(width: 8),
              Text(
                'Real-time Status',
                style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _isConnected ? Colors.green : Colors.red,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  _isConnected ? 'Connected' : 'Disconnected',
                  style: GoogleFonts.inter(
                    fontSize: 12,
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Connection Statistics
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Active Channels',
                  _activeChannels.toString(),
                  Icons.radio,
                  Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildStatItem(
                  'Online Users',
                  _onlineUsers.length.toString(),
                  Icons.people,
                  Colors.green,
                ),
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Active Channels List
          if (_activeChannels > 0) ...[
            Text(
              'Active Subscriptions',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withAlpha(13),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.withAlpha(51)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children:
                    _realtimeService.activeChannelNames.map((channel) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Colors.green,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                channel,
                                style: GoogleFonts.inter(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Recent Events
          if (_recentEvents.isNotEmpty) ...[
            Text(
              'Recent Events',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              constraints: const BoxConstraints(maxHeight: 120),
              child: SingleChildScrollView(
                child: Column(
                  children:
                      _recentEvents.map((event) {
                        return Container(
                          margin: const EdgeInsets.only(bottom: 4),
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.grey.withAlpha(13),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: Colors.grey.withAlpha(51),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.circle, size: 8, color: Colors.orange),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  event,
                                  style: GoogleFonts.inter(
                                    fontSize: 12,
                                    color: Colors.black87,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Online Users
          if (_onlineUsers.isNotEmpty) ...[
            Text(
              'Online Users',
              style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              height: 60,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _onlineUsers.length,
                itemBuilder: (context, index) {
                  final user = _onlineUsers[index];
                  return Container(
                    margin: const EdgeInsets.only(right: 8),
                    child: Column(
                      children: [
                        Stack(
                          children: [
                            CircleAvatar(
                              radius: 16,
                              backgroundColor: Colors.blue,
                              child: Text(
                                (user['email'] as String?)
                                        ?.substring(0, 1)
                                        .toUpperCase() ??
                                    'U',
                                style: GoogleFonts.inter(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: 0,
                              right: 0,
                              child: Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: Colors.green,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 1,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          (user['email'] as String?)?.split('@')[0] ?? 'User',
                          style: GoogleFonts.inter(
                            fontSize: 10,
                            color: Colors.grey[600],
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],

          // Test Buttons
          if (_authService.isAuthenticated) ...[
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _testRealtimeConnection,
                    icon: const Icon(Icons.help_outline, size: 16),
                    label: const Text('Test Connection'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      textStyle: GoogleFonts.inter(fontSize: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _simulateEvent,
                    icon: const Icon(Icons.send, size: 16),
                    label: const Text('Simulate Event'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      textStyle: GoogleFonts.inter(fontSize: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatItem(
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withAlpha(26),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withAlpha(77)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 8),
          Text(
            value,
            style: GoogleFonts.inter(
              fontSize: 18,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _testRealtimeConnection() {
    _addRealtimeEvent('Test', 'Connection test initiated');

    // Simulate connection test
    Future.delayed(const Duration(seconds: 1), () {
      _addRealtimeEvent('Test', 'Connection test successful ✅');
    });
  }

  void _simulateEvent() {
    final events = [
      'Trade Created: Demo trade #${DateTime.now().millisecondsSinceEpoch}',
      'Agent Status: Agent came online',
      'OTP Generated: New OTP for verification',
      'User Action: Profile updated',
      'System Event: Health check completed',
    ];

    final randomEvent =
        events[DateTime.now().millisecondsSinceEpoch % events.length];
    _addRealtimeEvent('Simulation', randomEvent);
  }
}
