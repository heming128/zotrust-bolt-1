import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';
import '../web_rtc_voice_call_interface.dart';

class ConnectionStatusWidget extends StatelessWidget {
  final CallState state;
  final VoidCallback? onReconnectTap;

  const ConnectionStatusWidget({
    Key? key,
    required this.state,
    this.onReconnectTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (state == CallState.connected) {
      return const SizedBox.shrink();
    }

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8.w),
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
      decoration: BoxDecoration(
        color: _getBackgroundColor().withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: _getBackgroundColor().withValues(alpha: 0.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (state == CallState.connecting ||
              state == CallState.reconnecting) ...[
            SizedBox(
              width: 4.w,
              height: 4.w,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(_getTextColor()),
              ),
            ),
            SizedBox(width: 3.w),
          ],
          CustomIconWidget(
            iconName: _getStatusIcon(),
            color: _getTextColor(),
            size: 5.w,
          ),
          SizedBox(width: 2.w),
          Expanded(
            child: Text(
              _getStatusText(),
              style: TextStyle(
                color: _getTextColor(),
                fontSize: 12.sp,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          if (state == CallState.reconnecting && onReconnectTap != null) ...[
            SizedBox(width: 2.w),
            GestureDetector(
              onTap: onReconnectTap,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(2.w),
                ),
                child: Text(
                  'Retry',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10.sp,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getStatusText() {
    switch (state) {
      case CallState.connecting:
        return 'Connecting to call...';
      case CallState.reconnecting:
        return 'Connection lost, reconnecting...';
      case CallState.ended:
        return 'Call ended';
      case CallState.connected:
        return '';
    }
  }

  String _getStatusIcon() {
    switch (state) {
      case CallState.connecting:
        return 'phone_in_talk';
      case CallState.reconnecting:
        return 'sync_problem';
      case CallState.ended:
        return 'call_end';
      case CallState.connected:
        return 'phone_in_talk';
    }
  }

  Color _getBackgroundColor() {
    switch (state) {
      case CallState.connecting:
        return Colors.blue;
      case CallState.reconnecting:
        return Colors.orange;
      case CallState.ended:
        return Colors.red;
      case CallState.connected:
        return Colors.green;
    }
  }

  Color _getTextColor() {
    switch (state) {
      case CallState.connecting:
        return Colors.blue;
      case CallState.reconnecting:
        return Colors.orange;
      case CallState.ended:
        return Colors.red;
      case CallState.connected:
        return Colors.green;
    }
  }
}
