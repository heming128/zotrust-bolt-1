import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../web_rtc_voice_call_interface.dart';

class CallQualityIndicatorWidget extends StatelessWidget {
  final CallQuality quality;
  final int signalStrength;
  final int latency;

  const CallQualityIndicatorWidget({
    Key? key,
    required this.quality,
    required this.signalStrength,
    required this.latency,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
      child: Column(
        children: [
          // Signal strength bars
          _buildSignalStrengthBars(),

          SizedBox(height: 2.h),

          // Quality metrics
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildQualityMetric(
                'Quality',
                _getQualityText(),
                _getQualityColor(),
              ),
              _buildQualityMetric(
                'Signal',
                '$signalStrength%',
                _getSignalColor(),
              ),
              _buildQualityMetric(
                'Latency',
                '${latency}ms',
                _getLatencyColor(),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSignalStrengthBars() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(5, (index) {
        final isActive = signalStrength > (index * 20);
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 1.w),
          width: 1.5.w,
          height: (2 + index * 0.8).h,
          decoration: BoxDecoration(
            color: isActive
                ? _getSignalColor()
                : Colors.white.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(1.w),
          ),
        );
      }),
    );
  }

  Widget _buildQualityMetric(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: color,
            fontSize: 14.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 0.5.h),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: 0.7),
            fontSize: 10.sp,
          ),
        ),
      ],
    );
  }

  String _getQualityText() {
    switch (quality) {
      case CallQuality.poor:
        return 'Poor';
      case CallQuality.fair:
        return 'Fair';
      case CallQuality.excellent:
        return 'Excellent';
    }
  }

  Color _getQualityColor() {
    switch (quality) {
      case CallQuality.poor:
        return Colors.red;
      case CallQuality.fair:
        return Colors.orange;
      case CallQuality.excellent:
        return Colors.green;
    }
  }

  Color _getSignalColor() {
    if (signalStrength > 70) return Colors.green;
    if (signalStrength > 40) return Colors.orange;
    return Colors.red;
  }

  Color _getLatencyColor() {
    if (latency < 50) return Colors.green;
    if (latency < 150) return Colors.orange;
    return Colors.red;
  }
}
