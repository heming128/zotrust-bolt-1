import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class CallControlsWidget extends StatelessWidget {
  final bool isMuted;
  final bool isSpeakerOn;
  final VoidCallback onMuteToggle;
  final VoidCallback onSpeakerToggle;
  final VoidCallback onEndCall;
  final VoidCallback onReportCall;

  const CallControlsWidget({
    Key? key,
    required this.isMuted,
    required this.isSpeakerOn,
    required this.onMuteToggle,
    required this.onSpeakerToggle,
    required this.onEndCall,
    required this.onReportCall,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Mute button
          _buildControlButton(
            icon: isMuted ? 'mic_off' : 'mic',
            isActive: !isMuted,
            onTap: onMuteToggle,
            backgroundColor: isMuted
                ? Colors.red.withValues(alpha: 0.8)
                : Colors.white.withValues(alpha: 0.2),
          ),

          // Speaker button
          _buildControlButton(
            icon: isSpeakerOn ? 'volume_up' : 'phone',
            isActive: isSpeakerOn,
            onTap: onSpeakerToggle,
            backgroundColor: Colors.white.withValues(alpha: 0.2),
          ),

          // End call button (prominent)
          Container(
            width: 18.w,
            height: 18.w,
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Colors.red,
                  blurRadius: 15,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(9.w),
                onTap: onEndCall,
                child: Center(
                  child: CustomIconWidget(
                    iconName: 'call_end',
                    color: Colors.white,
                    size: 8.w,
                  ),
                ),
              ),
            ),
          ),

          // Report button
          _buildControlButton(
            icon: 'report',
            isActive: false,
            onTap: onReportCall,
            backgroundColor: Colors.orange.withValues(alpha: 0.8),
          ),

          // More options button (placeholder)
          _buildControlButton(
            icon: 'more_horiz',
            isActive: false,
            onTap: () {}, // Could expand to show more options
            backgroundColor: Colors.white.withValues(alpha: 0.2),
          ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required String icon,
    required bool isActive,
    required VoidCallback onTap,
    required Color backgroundColor,
  }) {
    return Container(
      width: 14.w,
      height: 14.w,
      decoration: BoxDecoration(
        color: backgroundColor,
        shape: BoxShape.circle,
        border: isActive
            ? Border.all(color: Colors.white.withValues(alpha: 0.5), width: 2)
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(7.w),
          onTap: onTap,
          child: Center(
            child: CustomIconWidget(
              iconName: icon,
              color: Colors.white,
              size: 6.w,
            ),
          ),
        ),
      ),
    );
  }
}
