import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../../routes/app_routes.dart';
import '../../widgets/custom_image_widget.dart';
import '../../theme/app_theme.dart';
import '../../core/services/web3_wallet_service.dart';

class SplashScreen extends StatefulWidget {
  final List<Map<String, dynamic>>? initializationSteps;

  const SplashScreen({super.key, this.initializationSteps});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _logoAnimationController;
  late AnimationController _textAnimationController;
  late Animation<double> _logoScaleAnimation;
  late Animation<double> _logoOpacityAnimation;
  late Animation<Offset> _textSlideAnimation;
  late Animation<double> _textOpacityAnimation;

  bool _isInitializing = true;
  String _initializationStatus = 'Initializing ZedTrust...';
  bool _bypassMode = false;
  bool _emergencyMode = false;
  List<String> _initializationErrors = [];

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initializeAppServices();
  }

  void _setupAnimations() {
    _logoAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _textAnimationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _logoScaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoAnimationController,
        curve: Curves.elasticOut,
      ),
    );

    _logoOpacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _logoAnimationController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _textSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _textAnimationController,
        curve: Curves.easeOutQuart,
      ),
    );

    _textOpacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _textAnimationController, curve: Curves.easeIn),
    );

    _logoAnimationController.forward();
    _textAnimationController.forward();
  }

  Future<void> _initializeAppServices() async {
    if (kDebugMode) {
      print('🚀 ZedTrust Splash Screen - Service Initialization');
      print('⏰ Timestamp: ${DateTime.now()}');
    }

    try {
      await _performServiceInitialization();
    } catch (e) {
      if (kDebugMode) {
        print('❌ Critical initialization error: $e');
      }
      _activateEmergencyMode();
    }
  }

  Future<void> _performServiceInitialization() async {
    // Step 1: Initialize Web3 Wallet Service
    try {
      setState(() {
        _initializationStatus = 'Initializing Web3 services...';
      });

      await Web3WalletService.instance.initialize();

      if (kDebugMode) {
        print('✅ Web3 Wallet Service initialized successfully');
      }
    } catch (e) {
      if (kDebugMode) {
        print('⚠️ Web3 initialization warning: $e');
      }
      _initializationErrors.add('Web3 service initialization failed');
    }

    await Future.delayed(const Duration(milliseconds: 800));

    // Step 2: Check network connectivity
    try {
      setState(() {
        _initializationStatus = 'Checking network connectivity...';
      });

      // Simulate network check
      await Future.delayed(const Duration(milliseconds: 500));

      if (kDebugMode) {
        print('✅ Network connectivity verified');
      }
    } catch (e) {
      _initializationErrors.add('Network connectivity check failed');
    }

    await Future.delayed(const Duration(milliseconds: 600));

    // Step 3: Finalize initialization
    setState(() {
      _initializationStatus =
          _initializationErrors.isEmpty
              ? 'Ready to trade!'
              : 'Initializing in offline mode...';
      _isInitializing = false;
      _bypassMode = _initializationErrors.isNotEmpty;
    });

    if (kDebugMode) {
      if (_initializationErrors.isEmpty) {
        print('✅ All services initialized successfully');
      } else {
        print('⚠️ Some services failed, continuing in bypass mode');
        for (final error in _initializationErrors) {
          print('   - $error');
        }
      }
    }

    // Step 4: Navigate to dashboard
    await Future.delayed(const Duration(milliseconds: 1500));

    if (mounted) {
      _navigateToNextScreen();
    }
  }

  void _activateEmergencyMode() async {
    setState(() {
      _emergencyMode = true;
      _bypassMode = true;
      _isInitializing = false;
      _initializationStatus = 'Loading in emergency mode...';
    });

    await Future.delayed(const Duration(milliseconds: 1000));

    if (mounted) {
      _navigateToNextScreen();
    }
  }

  void _navigateToNextScreen() {
    try {
      if (kDebugMode) {
        print('🚀 Navigating to dashboard');
        if (_bypassMode) {
          print('📊 Running in bypass mode with mock data');
        }
        if (_emergencyMode) {
          print('🚨 Running in emergency mode');
        }
      }

      Navigator.of(
        context,
      ).pushNamedAndRemoveUntil(AppRoutes.dashboard, (route) => false);
    } catch (e) {
      if (kDebugMode) {
        print('❌ Navigation failed: $e');
      }

      // Fallback navigation
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          try {
            Navigator.of(context).pushReplacementNamed(AppRoutes.dashboard);
          } catch (fallbackError) {
            if (kDebugMode) {
              print('❌ Fallback navigation also failed: $fallbackError');
            }
          }
        }
      });
    }
  }

  @override
  void dispose() {
    _logoAnimationController.dispose();
    _textAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryLight,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.primaryLight,
              AppTheme.primaryLight.withAlpha(204),
              AppTheme.accentLight.withAlpha(153),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Logo section
              Expanded(
                flex: 3,
                child: Center(
                  child: AnimatedBuilder(
                    animation: _logoAnimationController,
                    builder: (context, child) {
                      return Transform.scale(
                        scale: _logoScaleAnimation.value,
                        child: Opacity(
                          opacity: _logoOpacityAnimation.value,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // App Logo
                              Container(
                                width: 120,
                                height: 120,
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(30),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withAlpha(26),
                                      blurRadius: 20,
                                      offset: const Offset(0, 10),
                                    ),
                                  ],
                                ),
                                child: CustomImageWidget(
                                  imageUrl: 'assets/images/img_app_logo.svg',
                                  height: 80,
                                  width: 80,
                                  errorWidget: Icon(
                                    Icons.business,
                                    color: AppTheme.primaryLight,
                                    size: 80,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 24),

                              // App Name
                              Text(
                                'ZedTrust',
                                style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  letterSpacing: 2,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black.withAlpha(77),
                                      blurRadius: 10,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 8),

                              // Tagline
                              Text(
                                'Decentralized P2P Trading',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.white.withAlpha(230),
                                  letterSpacing: 1,
                                ),
                              ),

                              // Status indicators
                              if (kDebugMode ||
                                  _bypassMode ||
                                  _emergencyMode) ...[
                                const SizedBox(height: 16),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    if (_bypassMode && !_emergencyMode)
                                      Container(
                                        margin: const EdgeInsets.only(right: 8),
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: 6,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.orange.withAlpha(178),
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        child: const Text(
                                          'BYPASS MODE',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    if (_emergencyMode)
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 12,
                                          vertical: 6,
                                        ),
                                        decoration: BoxDecoration(
                                          color: Colors.red.withAlpha(178),
                                          borderRadius: BorderRadius.circular(
                                            12,
                                          ),
                                        ),
                                        child: const Text(
                                          'EMERGENCY',
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),

              // Status section
              Expanded(
                flex: 1,
                child: SlideTransition(
                  position: _textSlideAnimation,
                  child: FadeTransition(
                    opacity: _textOpacityAnimation,
                    child: Column(
                      children: [
                        // Loading indicator
                        if (_isInitializing) ...[
                          SizedBox(
                            width: 40,
                            height: 40,
                            child: CircularProgressIndicator(
                              strokeWidth: 3,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                Colors.white.withAlpha(204),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                        ],

                        // Status text
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 40),
                          child: Text(
                            _initializationStatus,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white.withAlpha(230),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),

                        if (!_isInitializing) ...[
                          const SizedBox(height: 16),
                          Icon(
                            _emergencyMode
                                ? Icons.warning_amber
                                : _bypassMode
                                ? Icons.offline_bolt
                                : Icons.check_circle_outline,
                            color:
                                _emergencyMode
                                    ? Colors.orange
                                    : _bypassMode
                                    ? Colors.blue
                                    : Colors.white,
                            size: 32,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),

              // Footer
              Padding(
                padding: const EdgeInsets.all(24),
                child: SlideTransition(
                  position: _textSlideAnimation,
                  child: FadeTransition(
                    opacity: _textOpacityAnimation,
                    child: Column(
                      children: [
                        Text(
                          'Powered by Web3Dart & Flutter',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.white.withAlpha(179),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Version 1.0.0',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.white.withAlpha(128),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom timeout exception for initialization
class TimeoutException implements Exception {
  final String message;
  TimeoutException(this.message);
  @override
  String toString() => 'TimeoutException: $message';
}
