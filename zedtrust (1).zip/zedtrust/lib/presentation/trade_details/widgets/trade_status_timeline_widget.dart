import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TradeStatusTimelineWidget extends StatelessWidget {
  final String currentStatus;
  final Map<String, dynamic> tradeData;

  const TradeStatusTimelineWidget({
    Key? key,
    required this.currentStatus,
    required this.tradeData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(3.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Trade Timeline',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 3.h),
          _buildTimeline(context),
        ],
      ),
    );
  }

  Widget _buildTimeline(BuildContext context) {
    final steps = _getTimelineSteps();

    return Column(
      children: steps.asMap().entries.map((entry) {
        final index = entry.key;
        final step = entry.value;
        final isLast = index == steps.length - 1;

        return _buildTimelineStep(
          context,
          step,
          isLast,
        );
      }).toList(),
    );
  }

  List<Map<String, dynamic>> _getTimelineSteps() {
    final userRole = tradeData['userRole'] as String;

    if (userRole == 'seller') {
      return [
        {
          'title': 'Trade Created',
          'subtitle': 'Waiting for buyer payment',
          'status': 'Created',
          'timestamp': tradeData['createdAt'],
          'icon': 'add_circle',
        },
        {
          'title': 'Payment Confirmed',
          'subtitle': 'Buyer has marked payment as sent',
          'status': 'Paid',
          'timestamp': tradeData['paidAt'],
          'icon': 'payment',
        },
        {
          'title': 'Cash Received', // New step for sellers
          'subtitle': 'Seller confirmed cash receipt',
          'status': 'CashReceived',
          'timestamp': tradeData['cashReceivedAt'],
          'icon': 'attach_money',
        },
        {
          'title': 'USDC Released',
          'subtitle': 'Smart contract released funds',
          'status': 'Released',
          'timestamp': tradeData['releasedAt'],
          'icon': 'check_circle',
        },
        {
          'title': 'Trade Completed',
          'subtitle': 'All parties confirmed',
          'status': 'Completed',
          'timestamp': tradeData['completedAt'],
          'icon': 'done_all',
        },
      ];
    } else {
      // Buyer timeline (original flow)
      return [
        {
          'title': 'Trade Created',
          'subtitle': 'Trade initialized',
          'status': 'Created',
          'timestamp': tradeData['createdAt'],
          'icon': 'add_circle',
        },
        {
          'title': 'Payment Sent',
          'subtitle': 'You marked payment as sent',
          'status': 'Paid',
          'timestamp': tradeData['paidAt'],
          'icon': 'payment',
        },
        {
          'title': 'USDC Released',
          'subtitle': 'Funds transferred to your wallet',
          'status': 'Released',
          'timestamp': tradeData['releasedAt'],
          'icon': 'check_circle',
        },
        {
          'title': 'Trade Completed',
          'subtitle': 'Transaction finalized',
          'status': 'Completed',
          'timestamp': tradeData['completedAt'],
          'icon': 'done_all',
        },
      ];
    }
  }

  Widget _buildTimelineStep(
    BuildContext context,
    Map<String, dynamic> step,
    bool isLast,
  ) {
    final stepStatus = step['status'] as String;
    final isCompleted = _isStepCompleted(stepStatus);
    final isActive = stepStatus == currentStatus;
    final timestamp = step['timestamp'] as DateTime?;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 12.w,
              height: 12.w,
              decoration: BoxDecoration(
                color: isCompleted
                    ? AppTheme.getSuccessColor(true)
                    : isActive
                        ? AppTheme.lightTheme.colorScheme.primary
                        : Theme.of(context).colorScheme.outline,
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: step['icon'],
                color: Colors.white,
                size: 6.w,
              ),
            ),
            if (!isLast)
              Container(
                width: 2,
                height: 8.h,
                margin: EdgeInsets.symmetric(vertical: 1.h),
                color: isCompleted
                    ? AppTheme.getSuccessColor(true)
                    : Theme.of(context)
                        .colorScheme
                        .outline
                        .withValues(alpha: 0.3),
              ),
          ],
        ),
        SizedBox(width: 4.w),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: 2.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  step['title'],
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: isCompleted || isActive
                            ? Theme.of(context).colorScheme.onSurface
                            : Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
                SizedBox(height: 0.5.h),
                Text(
                  step['subtitle'],
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
                if (timestamp != null) ...[
                  SizedBox(height: 0.5.h),
                  Text(
                    _formatTimestamp(timestamp),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.getSuccessColor(true),
                          fontSize: 10.sp,
                        ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  bool _isStepCompleted(String stepStatus) {
    const statusOrder = [
      'Created',
      'Paid',
      'CashReceived',
      'Released',
      'Completed',
    ];

    final currentIndex = statusOrder.indexOf(currentStatus);
    final stepIndex = statusOrder.indexOf(stepStatus);

    return stepIndex <= currentIndex;
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 1) {
      return 'Just now';
    } else if (difference.inHours < 1) {
      return '${difference.inMinutes}m ago';
    } else if (difference.inDays < 1) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inDays}d ago';
    }
  }
}
