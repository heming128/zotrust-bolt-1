import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class ActionButtonsWidget extends StatelessWidget {
  final String userRole;
  final String tradeStatus;
  final VoidCallback? onMarkAsPaid;
  final VoidCallback? onConfirmPayment;
  final VoidCallback? onCashReceived;
  final VoidCallback? onCancelTrade;
  final VoidCallback? onReportIssue;

  const ActionButtonsWidget({
    Key? key,
    required this.userRole,
    required this.tradeStatus,
    this.onMarkAsPaid,
    this.onConfirmPayment,
    this.onCashReceived,
    this.onCancelTrade,
    this.onReportIssue,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(3.w),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Actions',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 3.h),
          ..._buildActionButtons(context),
          SizedBox(height: 2.h),
          _buildEmergencyActions(context),
        ],
      ),
    );
  }

  List<Widget> _buildActionButtons(BuildContext context) {
    final List<Widget> buttons = [];

    if (userRole == 'buyer' && tradeStatus == 'Created') {
      buttons.add(_buildPrimaryButton(
        context,
        'Mark as Paid',
        'payment',
        AppTheme.lightTheme.colorScheme.secondary,
        onMarkAsPaid,
        'Confirm that you have sent the payment',
      ));
    }

    // New seller flow: First confirm cash receipt
    if (userRole == 'seller' && tradeStatus == 'Paid') {
      buttons.add(_buildPrimaryButton(
        context,
        'I have received cash',
        'attach_money',
        AppTheme.getSuccessColor(true),
        onCashReceived,
        'Confirm cash receipt and get OTP code',
      ));
    }

    // Second step: Release USDC after cash confirmation
    if (userRole == 'seller' && tradeStatus == 'CashReceived') {
      buttons.add(_buildPrimaryButton(
        context,
        'Complete Transaction',
        'check_circle',
        AppTheme.lightTheme.colorScheme.secondary,
        onConfirmPayment,
        'Release USDC from escrow to complete trade',
      ));
    }

    if (tradeStatus == 'Completed') {
      buttons.add(_buildCompletedMessage(context));
    }

    return buttons;
  }

  Widget _buildPrimaryButton(
    BuildContext context,
    String text,
    String iconName,
    Color color,
    VoidCallback? onPressed,
    String description,
  ) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: onPressed != null
                ? () {
                    HapticFeedback.mediumImpact();
                    onPressed();
                  }
                : null,
            icon: CustomIconWidget(
              iconName: iconName,
              color: Colors.white,
              size: 6.w,
            ),
            label: Text(
              text,
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w600,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: color,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 4.h),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(3.w),
              ),
              elevation: 2,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          description,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
          textAlign: TextAlign.center,
        ),
        SizedBox(height: 2.h),
      ],
    );
  }

  Widget _buildCompletedMessage(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.getSuccessColor(true).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.getSuccessColor(true).withValues(alpha: 0.3),
        ),
      ),
      child: Row(
        children: [
          CustomIconWidget(
            iconName: 'check_circle',
            color: AppTheme.getSuccessColor(true),
            size: 6.w,
          ),
          SizedBox(width: 3.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Trade Completed Successfully',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: AppTheme.getSuccessColor(true),
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Text(
                  'USDC has been transferred to your wallet',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.getSuccessColor(true),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmergencyActions(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Emergency Actions',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontWeight: FontWeight.w500,
              ),
        ),
        SizedBox(height: 2.h),
        Row(
          children: [
            if (tradeStatus != 'Completed' && tradeStatus != 'Cancelled') ...[
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: onCancelTrade != null
                      ? () {
                          HapticFeedback.lightImpact();
                          _showCancelConfirmation(context);
                        }
                      : null,
                  icon: CustomIconWidget(
                    iconName: 'cancel',
                    color: AppTheme.lightTheme.colorScheme.error,
                    size: 5.w,
                  ),
                  label: Text('Cancel Trade'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.lightTheme.colorScheme.error,
                    side: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.error,
                    ),
                    padding: EdgeInsets.symmetric(vertical: 3.h),
                  ),
                ),
              ),
              SizedBox(width: 3.w),
            ],
            Expanded(
              child: OutlinedButton.icon(
                onPressed: onReportIssue != null
                    ? () {
                        HapticFeedback.lightImpact();
                        onReportIssue!();
                      }
                    : null,
                icon: CustomIconWidget(
                  iconName: 'report',
                  color: AppTheme.getWarningColor(true),
                  size: 5.w,
                ),
                label: Text('Report Issue'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.getWarningColor(true),
                  side: BorderSide(
                    color: AppTheme.getWarningColor(true),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 3.h),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  void _showCancelConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              CustomIconWidget(
                iconName: 'warning',
                color: AppTheme.getWarningColor(true),
                size: 6.w,
              ),
              SizedBox(width: 3.w),
              Text('Cancel Trade'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Are you sure you want to cancel this trade?',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(height: 2.h),
              Container(
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.getWarningColor(true).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(2.w),
                ),
                child: Text(
                  'Warning: Cancelling after payment confirmation may result in disputes.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AppTheme.getWarningColor(true),
                      ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('Keep Trade'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (onCancelTrade != null) {
                  onCancelTrade!();
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.colorScheme.error,
              ),
              child: Text('Cancel Trade'),
            ),
          ],
        );
      },
    );
  }
}
