import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../core/services/escrow_payment_service.dart';

class OtpSectionWidget extends StatefulWidget {
  final String tradeId;
  final Map<String, dynamic> tradeData;
  final Function(Map<String, dynamic>) onTradeUpdate;

  const OtpSectionWidget({
    Key? key,
    required this.tradeId,
    required this.tradeData,
    required this.onTradeUpdate,
  }) : super(key: key);

  @override
  State<OtpSectionWidget> createState() => _OtpSectionWidgetState();
}

class _OtpSectionWidgetState extends State<OtpSectionWidget> {
  final _otpController = TextEditingController();
  final _colorController = TextEditingController();
  bool _isVerifying = false;
  String? _errorMessage;

  @override
  void dispose() {
    _otpController.dispose();
    _colorController.dispose();
    super.dispose();
  }

  Future<void> _verifyOtpAndReleaseFunds() async {
    if (_otpController.text.trim().isEmpty ||
        _colorController.text.trim().isEmpty) {
      setState(() {
        _errorMessage = 'Please enter both OTP code and color code';
      });
      return;
    }

    setState(() {
      _isVerifying = true;
      _errorMessage = null;
    });

    try {
      final result = await EscrowPaymentService.instance.releaseEscrowFunds(
        tradeId: widget.tradeId,
        otpCode: _otpController.text.trim(),
        otpColor: _colorController.text.trim(),
      );

      if (result['success'] == true) {
        // Show success dialog with fee breakdown
        await _showReleaseSuccessDialog(result['distribution']);

        // Update trade data
        widget.onTradeUpdate({
          ...widget.tradeData,
          'status': 'RELEASED',
          'escrow_status': 'RELEASED',
          'seller_receives': result['distribution']['seller_receives'],
          'platform_fee_collected': result['distribution']['platform_fee'],
          'released_at': DateTime.now().toIso8601String(),
        });

        // Clear form
        _otpController.clear();
        _colorController.clear();
      } else {
        setState(() {
          _errorMessage = result['message'] ?? 'Failed to verify OTP';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error verifying OTP: $e';
      });
    } finally {
      if (mounted) {
        setState(() {
          _isVerifying = false;
        });
      }
    }
  }

  Future<void> _showReleaseSuccessDialog(
      Map<String, dynamic> distribution) async {
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'check_circle',
              color: AppTheme.getSuccessColor(
                  Theme.of(context).brightness == Brightness.light),
              size: 24,
            ),
            SizedBox(width: 2.w),
            Text(
              'Funds Released!',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    color: AppTheme.getSuccessColor(
                        Theme.of(context).brightness == Brightness.light),
                    fontWeight: FontWeight.w600,
                  ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'USDC funds have been successfully released with platform fees deducted.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.getSuccessColor(
                        Theme.of(context).brightness == Brightness.light)
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Fund Distribution',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  SizedBox(height: 1.h),
                  _buildDistributionRow('Seller Receives:',
                      '${distribution['seller_receives']} USDC'),
                  _buildDistributionRow('Platform Fee (Total):',
                      '${distribution['platform_fee']} USDC'),
                  _buildDistributionRow('  - Buyer Fee (1%):',
                      '${distribution['buyer_fee']} USDC'),
                  _buildDistributionRow('  - Seller Fee (1%):',
                      '${distribution['seller_fee']} USDC'),
                ],
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Continue'),
          ),
        ],
      ),
    );
  }

  Widget _buildDistributionRow(String label, String amount) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 0.5.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          Text(
            amount,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final canVerifyOtp = widget.tradeData['status'] == 'OTP_PENDING' ||
        widget.tradeData['escrow_status'] == 'LOCKED';

    if (!canVerifyOtp) {
      return const SizedBox.shrink();
    }

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'security',
                color: Theme.of(context).colorScheme.primary,
                size: 20,
              ),
              SizedBox(width: 2.w),
              Text(
                'OTP Verification Required',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: Theme.of(context).colorScheme.primary,
                    ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            'Enter the 6-digit OTP and color code shown by the agent to release escrow funds.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          SizedBox(height: 3.h),

          // OTP Code Input
          TextFormField(
            controller: _otpController,
            decoration: InputDecoration(
              labelText: 'OTP Code',
              hintText: 'Enter 6-digit code',
              prefixIcon: CustomIconWidget(
                iconName: 'pin',
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                size: 20,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            keyboardType: TextInputType.number,
            maxLength: 6,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(6),
            ],
          ),
          SizedBox(height: 2.h),

          // Color Code Input
          TextFormField(
            controller: _colorController,
            decoration: InputDecoration(
              labelText: 'Color Code',
              hintText: 'Enter hex color (e.g., #FF5733)',
              prefixIcon: CustomIconWidget(
                iconName: 'palette',
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                size: 20,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            maxLength: 7,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[#a-fA-F0-9]')),
              LengthLimitingTextInputFormatter(7),
            ],
            onChanged: (value) {
              if (!value.startsWith('#') && value.isNotEmpty) {
                _colorController.text = '#$value';
                _colorController.selection = TextSelection.fromPosition(
                  TextPosition(offset: _colorController.text.length),
                );
              }
            },
          ),
          SizedBox(height: 2.h),

          // Error message
          if (_errorMessage != null) ...[
            Container(
              padding: EdgeInsets.all(2.w),
              decoration: BoxDecoration(
                color:
                    Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: Theme.of(context)
                      .colorScheme
                      .error
                      .withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'error',
                    color: Theme.of(context).colorScheme.error,
                    size: 16,
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Text(
                      _errorMessage!,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.error,
                          ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 2.h),
          ],

          // Verify Button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _isVerifying ? null : _verifyOtpAndReleaseFunds,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.getSuccessColor(
                    Theme.of(context).brightness == Brightness.light),
                padding: EdgeInsets.symmetric(vertical: 1.5.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: _isVerifying
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          width: 4.w,
                          height: 4.w,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor:
                                AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Verifying...',
                          style:
                              Theme.of(context).textTheme.labelLarge?.copyWith(
                                    color: Colors.white,
                                  ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomIconWidget(
                          iconName: 'verified',
                          color: Colors.white,
                          size: 18,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Verify OTP & Release Funds',
                          style:
                              Theme.of(context).textTheme.labelLarge?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                        ),
                      ],
                    ),
            ),
          ),

          SizedBox(height: 2.h),

          // Info section
          Container(
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primaryContainer
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomIconWidget(
                  iconName: 'info',
                  color: Theme.of(context).colorScheme.primary,
                  size: 16,
                ),
                SizedBox(width: 2.w),
                Expanded(
                  child: Text(
                    'Once verified, USDC will be released to the seller minus 1% platform fee. The buyer\'s 1% fee was already deducted during escrow lock.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.primary,
                        ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
