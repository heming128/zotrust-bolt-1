import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class MessageBubbleWidget extends StatelessWidget {
  final Map<String, dynamic> message;
  final VoidCallback? onLongPress;

  const MessageBubbleWidget({
    Key? key,
    required this.message,
    this.onLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isMe = message['isMe'] as bool? ?? false;
    final text = message['text'] as String? ?? '';
    final timestamp = message['timestamp'] as DateTime? ?? DateTime.now();
    final isRead = message['isRead'] as bool? ?? false;
    final messageType = message['type'] as String? ?? 'text';

    return Container(
      margin: EdgeInsets.only(
        bottom: 2.h,
        left: isMe ? 20.w : 0,
        right: isMe ? 0 : 20.w,
      ),
      child: GestureDetector(
        onLongPress: onLongPress,
        child: Column(
          crossAxisAlignment:
              isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: isMe
                    ? AppTheme.lightTheme.primaryColor
                    : AppTheme.lightTheme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(4.w),
                  topRight: Radius.circular(4.w),
                  bottomLeft: Radius.circular(isMe ? 4.w : 1.w),
                  bottomRight: Radius.circular(isMe ? 1.w : 4.w),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: _buildMessageContent(messageType, text, isMe),
            ),
            SizedBox(height: 0.5.h),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  DateFormat('HH:mm').format(timestamp),
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    fontSize: 10.sp,
                  ),
                ),
                if (isMe) ...[
                  SizedBox(width: 1.w),
                  CustomIconWidget(
                    iconName: isRead ? 'done_all' : 'done',
                    color: isRead
                        ? AppTheme.lightTheme.primaryColor
                        : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                    size: 3.w,
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageContent(String type, String text, bool isMe) {
    switch (type) {
      case 'text':
        return _buildTextMessage(text, isMe);
      case 'system':
        return _buildSystemMessage(text);
      case 'trade_proposal':
        return _buildTradeProposalMessage(text, isMe);
      default:
        return _buildTextMessage(text, isMe);
    }
  }

  Widget _buildTextMessage(String text, bool isMe) {
    return Text(
      text,
      style: TextStyle(
        color: isMe ? Colors.white : AppTheme.lightTheme.colorScheme.onSurface,
        fontSize: 14.sp,
        height: 1.4,
      ),
    );
  }

  Widget _buildSystemMessage(String text) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(2.w),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomIconWidget(
            iconName: 'info',
            color: AppTheme.lightTheme.colorScheme.secondary,
            size: 4.w,
          ),
          SizedBox(width: 2.w),
          Flexible(
            child: Text(
              text,
              style: TextStyle(
                color: AppTheme.lightTheme.colorScheme.secondary,
                fontSize: 12.sp,
                fontStyle: FontStyle.italic,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTradeProposalMessage(String text, bool isMe) {
    return Container(
      padding: EdgeInsets.all(3.w),
      decoration: BoxDecoration(
        color: isMe
            ? Colors.white.withValues(alpha: 0.1)
            : AppTheme.lightTheme.primaryColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(2.w),
        border: Border.all(
          color: AppTheme.lightTheme.primaryColor.withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'handshake',
                color: isMe ? Colors.white : AppTheme.lightTheme.primaryColor,
                size: 4.w,
              ),
              SizedBox(width: 2.w),
              Text(
                'Trade Proposal',
                style: TextStyle(
                  color: isMe ? Colors.white : AppTheme.lightTheme.primaryColor,
                  fontWeight: FontWeight.w600,
                  fontSize: 12.sp,
                ),
              ),
            ],
          ),
          SizedBox(height: 1.h),
          Text(
            text,
            style: TextStyle(
              color: isMe
                  ? Colors.white
                  : AppTheme.lightTheme.colorScheme.onSurface,
              fontSize: 14.sp,
            ),
          ),
        ],
      ),
    );
  }
}
